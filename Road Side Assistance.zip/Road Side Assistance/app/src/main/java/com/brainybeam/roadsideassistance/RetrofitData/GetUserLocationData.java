package com.brainybeam.roadsideassistance.RetrofitData;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.List;

public class GetUserLocationData {

    @SerializedName("Status")
    @Expose
    public Boolean status;
    @SerializedName("Message")
    @Expose
    public String message;
    @SerializedName("response")
    @Expose
    public List<GetUserLocationResponse> response = null;

    public class GetUserLocationResponse {

        @SerializedName("UserLocationID")
        @Expose
        public String userLocationID;
        @SerializedName("UserID")
        @Expose
        public String userID;
        @SerializedName("ForemanID")
        @Expose
        public String foremanID;
        @SerializedName("UserLatitude")
        @Expose
        public String userLatitude;
        @SerializedName("UserLongitude")
        @Expose
        public String userLongitude;

    }

}
