package com.brainybeam.roadsideassistance.Foreman.Activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.ProgressDialog;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.MenuItem;

import com.brainybeam.roadsideassistance.Foreman.CustomArrayList.ForemanHistoryList;
import com.brainybeam.roadsideassistance.Foreman.DashBoard.ForemanHistoryAdapter;
import com.brainybeam.roadsideassistance.R;
import com.brainybeam.roadsideassistance.RetrofitData.GetForemanHistoryData;
import com.brainybeam.roadsideassistance.Utils.ApiClient;
import com.brainybeam.roadsideassistance.Utils.ApiInterface;
import com.brainybeam.roadsideassistance.Utils.CommonMethod;
import com.brainybeam.roadsideassistance.Utils.ConnectionDetector;
import com.brainybeam.roadsideassistance.Utils.SharedPreferencesData;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ForemanHomeHistoryActivity extends AppCompatActivity {

    RecyclerView recyclerView;
    ArrayList<ForemanHistoryList> arrayList;

    ApiInterface apiInterface;
    SharedPreferences sp;
    ProgressDialog pd;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_foreman_home_history);
        getSupportActionBar().setTitle("Foreman History");
        ColorDrawable colorDrawable
                = new ColorDrawable(Color.parseColor("#2196F3"));
        getSupportActionBar().setBackgroundDrawable(colorDrawable);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        
        apiInterface = ApiClient.getClient().create(ApiInterface.class);
        sp = getSharedPreferences(SharedPreferencesData.PREF, MODE_PRIVATE);

        recyclerView = findViewById(R.id.foreman_history_recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(ForemanHomeHistoryActivity.this));
        recyclerView.setItemAnimator(new DefaultItemAnimator());

        if(new ConnectionDetector(ForemanHomeHistoryActivity.this).isConnectingToInternet()){
            pd = new ProgressDialog(ForemanHomeHistoryActivity.this);
            pd.setMessage("Please Wait...");
            pd.setCancelable(false);
            pd.show();
            recyclerViewDataSetMethod();

        } else {
            new ConnectionDetector(ForemanHomeHistoryActivity.this).connectiondetect();
        }

    }

    private void recyclerViewDataSetMethod() {

        Call<GetForemanHistoryData> call = apiInterface.GetForemanHistoryData(
                sp.getString(SharedPreferencesData.UserID, "")
        );

        call.enqueue(new Callback<GetForemanHistoryData>() {
            @Override
            public void onResponse(Call<GetForemanHistoryData> call, Response<GetForemanHistoryData> response) {

                pd.dismiss();
                if (response.code()==200) {
                    if (response.body().status == true) {
                        // new CommonMethod(ForemanHomeHistoryActivity.this, response.body().message);

                        arrayList = new ArrayList<>();
                        GetForemanHistoryData data = response.body();

                        for(int i=0; i<data.response.size(); i++){

                            ForemanHistoryList list = new ForemanHistoryList();

                            list.setHistoryID(data.response.get(i).historyID);
                            list.setServiceID(data.response.get(i).serviceID);
                            list.setForemanID(data.response.get(i).foremanID);
                            list.setUserID(data.response.get(i).userID);
                            list.setVehicleID(data.response.get(i).vehicleID);
                            list.setProblemDescriptionMessage(data.response.get(i).problemDescriptionMessage);
                            list.setPaymentID(data.response.get(i).paymentID);
                            list.setSPReqMoney(data.response.get(i).sPReqMoney);
                            list.setPaymentMode(data.response.get(i).paymentMode);
                            list.setPayment(data.response.get(i).payment);
                            list.setUserLocation(data.response.get(i).userLocation);
                            list.setPaymentDate(data.response.get(i).paymentDate);
                            list.setUserFirstName(data.response.get(i).firstName);
                            list.setUserLastName(data.response.get(i).lastName);
                            list.setUserProfileImage(data.response.get(i).profileImage);
                            list.setUserMobileNumber(data.response.get(i).mobileNumber);
                            list.setTypeOfProblem(data.response.get(i).typeOfProblem);
                            list.setProblemSubType(data.response.get(i).problemSubType);
                            list.setServiceFixedCharge(data.response.get(i).serviceFixedCharge);
                            list.setVehicleNumber(data.response.get(i).numberPlateNumber);
                            list.setTypeOfVehicle(data.response.get(i).typeOfVehicle);
                            list.setVehicleModelName(data.response.get(i).vehicleModelName);
                            list.setVehicleColor(data.response.get(i).vehicleColour);

                            arrayList.add(list);
                        }

                        ForemanHistoryAdapter adapter = new ForemanHistoryAdapter(ForemanHomeHistoryActivity.this, arrayList);
                        recyclerView.setAdapter(adapter);
                        adapter.notifyDataSetChanged();

                    } else {
                        new CommonMethod(ForemanHomeHistoryActivity.this, response.body().message);
                    }
                } else {
                    new CommonMethod(ForemanHomeHistoryActivity.this, "Server Error Code : "+response.code());
                }

            }

            @Override
            public void onFailure(Call<GetForemanHistoryData> call, Throwable t) {
                pd.dismiss();
                new CommonMethod(ForemanHomeHistoryActivity.this, t.getMessage());
            }
        });

    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();
        if (id == android.R.id.home) {
            onBackPressed();
        }
        return super.onOptionsItemSelected(item);
    }
    
}