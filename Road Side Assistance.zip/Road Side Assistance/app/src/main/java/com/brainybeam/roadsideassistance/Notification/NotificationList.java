package com.brainybeam.roadsideassistance.Notification;

public class NotificationList {

    String NotificationID;
    String Title;
    String Message;
    String MStatus;
    String NotificationTime;

    public String getNotificationID() {
        return NotificationID;
    }

    public void setNotificationID(String notificationID) {
        NotificationID = notificationID;
    }

    public String getTitle() {
        return Title;
    }

    public void setTitle(String title) {
        Title = title;
    }

    public String getMessage() {
        return Message;
    }

    public void setMessage(String message) {
        Message = message;
    }

    public String getMStatus() {
        return MStatus;
    }

    public void setMStatus(String MStatus) {
        this.MStatus = MStatus;
    }

    public String getNotificationTime() {
        return NotificationTime;
    }

    public void setNotificationTime(String notificationTime) {
        NotificationTime = notificationTime;
    }
}
