package com.brainybeam.roadsideassistance.Admin.DashBoard;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.brainybeam.roadsideassistance.Admin.CustomArrayList.NewForemanRequestList;
import com.brainybeam.roadsideassistance.R;
import com.brainybeam.roadsideassistance.RetrofitData.AdminRequestData;
import com.brainybeam.roadsideassistance.RetrofitData.SendNotificationData;
import com.brainybeam.roadsideassistance.Utils.ApiClient;
import com.brainybeam.roadsideassistance.Utils.ApiInterface;
import com.brainybeam.roadsideassistance.Utils.CommonMethod;
import com.brainybeam.roadsideassistance.Utils.SharedPreferencesData;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

import de.hdodenhof.circleimageview.CircleImageView;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class AdminNewForemanRequestAdapter extends RecyclerView.Adapter<AdminNewForemanRequestAdapter.MyHolder> {

    Context context;
    ArrayList<NewForemanRequestList> arrayList;

    ApiInterface apiInterface;
    SharedPreferences sp;
    ProgressDialog pd;

    int iPosition;

    public AdminNewForemanRequestAdapter(Context context, ArrayList<NewForemanRequestList> arrayList) {
        this.context = context;
        this.arrayList = arrayList;
    }

    @NonNull
    @Override
    public MyHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.custom_admin_new_foreman_request, parent, false);

        return new MyHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyHolder holder, @SuppressLint("RecyclerView") int position) {

        if (arrayList.get(position).getProfileImage().isEmpty() || arrayList.get(position).getProfileImage().equalsIgnoreCase("")){
            holder.circleImageView.setVisibility(View.GONE);
        } else {
            Picasso.with(context).load(arrayList.get(position).getProfileImage()).placeholder(R.drawable.ic_foreman).into(holder.circleImageView);
        }

//        if(sp.getString(SharedPreferencesData.ProfileImage, "").equalsIgnoreCase("https://alpeshpatel-project.000webhostapp.com/RoadSideAssistance/ForemanImages/")){
//
//        } else {
//            Picasso.with(context).load(sp.getString(SharedPreferencesData.ProfileImage, "")).placeholder(R.drawable.ic_foreman).into(holder.circleImageView);
//        }

        holder.callingImageLogo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                AlertDialog.Builder builder = new AlertDialog.Builder(view.getContext());
                builder.setTitle("Call to Foreman "+arrayList.get(position).getFirstName()+"?");
                builder.setPositiveButton("CALL", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        Intent intent = new Intent(Intent.ACTION_CALL);
                        intent.setData(Uri.parse("tel:"+"+91"+arrayList.get(position).getMobileNumber()));
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                            if (context.checkSelfPermission(Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
                                // TODO: Consider calling
                                //    Activity#requestPermissions
                                // here to request the missing permissions, and then overriding
                                //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
                                //                                          int[] grantResults)
                                // to handle the case where the user grants the permission. See the documentation
                                // for Activity#requestPermissions for more details.
                                return;
                            }
                        }
                        context.startActivity(intent);
                    }
                });

                builder.setNegativeButton("CANCEL", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        dialogInterface.dismiss();
                    }
                });

                builder.show();
            }
        });

        holder.Name.setText(arrayList.get(position).getFirstName()+" "+arrayList.get(position).getLastName());
        holder.MobileNumber.setText("+91 "+arrayList.get(position).getMobileNumber());
        holder.Email.setText(arrayList.get(position).getEmail());
        holder.Address.setText(arrayList.get(position).getAddress());
        holder.AreaANDCity.setText(arrayList.get(position).getArea()+", "+arrayList.get(position).getCity());
        holder.State.setText(arrayList.get(position).getState());
        holder.AccountStatus.setText(arrayList.get(position).getAccount_Status());


        holder.AcceptButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                iPosition = position;
                pd = new ProgressDialog(context);
                pd.setTitle("Please Wait...");
                pd.setCancelable(false);
                pd.show();
                SendNotificationToAcceptForeman();
                ForemanAccept();
                notifyDataSetChanged();
            }
        });

        holder.RejectButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                iPosition = position;
                pd = new ProgressDialog(context);
                pd.setTitle("Please Wait...");
                pd.setCancelable(false);
                pd.show();
                ForemanReject();
                notifyDataSetChanged();
            }
        });

    }

    private void ForemanReject() {

        Call<AdminRequestData> call = apiInterface.RejectForemanData(
                arrayList.get(iPosition).getForemanID()
        );

        call.enqueue(new Callback<AdminRequestData>() {
            @Override
            public void onResponse(Call<AdminRequestData> call, Response<AdminRequestData> response) {
                // pd.dismiss();
                if(response.code()==200){

                    if(response.body().status==true){
                        new CommonMethod(context, "Rejected");
                        SendNotificationToRejectForeman();
                        arrayList.remove(iPosition);
                        notifyDataSetChanged();
                    } else {
                        new CommonMethod(context, response.body().message);
                    }

                } else {
                    new CommonMethod(context, "Server Error Code : "+response.code());
                }

            }

            @Override
            public void onFailure(Call<AdminRequestData> call, Throwable t) {
                pd.dismiss();
                new CommonMethod(context, t.getMessage());
            }
        });

    }

    private void ForemanAccept() {

        Call<AdminRequestData> call = apiInterface.AcceptForemanData(
                arrayList.get(iPosition).getForemanID()
        );

        call.enqueue(new Callback<AdminRequestData>() {
            @Override
            public void onResponse(Call<AdminRequestData> call, Response<AdminRequestData> response) {
               // pd.dismiss();
                if(response.code()==200){

                    if(response.body().status==true){
                        new CommonMethod(context, "Accepted");
                        SendNotificationToAcceptForeman();
                        arrayList.remove(iPosition);
                        notifyDataSetChanged();
                    } else {
                        new CommonMethod(context, response.body().message);
                    }

                } else {
                    new CommonMethod(context, "Server Error Code : "+response.code());
                }

            }

            @Override
            public void onFailure(Call<AdminRequestData> call, Throwable t) {
                pd.dismiss();
                new CommonMethod(context, t.getMessage());
            }
        });

    }

    private void SendNotificationToAcceptForeman() {

        String Title = "Foreman "+arrayList.get(iPosition).getFirstName()+" your Account Request Accept";
        String Message = "Your Account (ForemanID-"+arrayList.get(iPosition).getForemanID()+") Request has been SuccessFully Accepted by Admin";

        Call<SendNotificationData> call = apiInterface.SendToForemanNotificationData(
                arrayList.get(iPosition).getForemanID(),
                Title,
                Message
        );

        call.enqueue(new Callback<SendNotificationData>() {
            @Override
            public void onResponse(Call<SendNotificationData> call, Response<SendNotificationData> response) {
                pd.dismiss();
                if(response.code()==200){

                    if(response.body().status==true){
                       // new CommonMethod(context, response.body().message);
                    } else {
                        new CommonMethod(context, response.body().message);
                    }

                } else {
                    new CommonMethod(context, "Server Error Code : "+response.code());
                }

            }

            @Override
            public void onFailure(Call<SendNotificationData> call, Throwable t) {
                pd.dismiss();
                new CommonMethod(context, t.getMessage());
            }
        });

    }

    private void SendNotificationToRejectForeman() {

        String Title = "Foreman "+arrayList.get(iPosition).getFirstName()+" your Account Request Reject";
        String Message = "Your Account (ForemanID-"+arrayList.get(iPosition).getForemanID()+") Request Rejected By Admin For Some Reason, \nPlease Contact Roadside Assistance Center OR Send Request Again?";

        Call<SendNotificationData> call = apiInterface.SendToForemanNotificationData(
                arrayList.get(iPosition).getForemanID(),
                Title,
                Message
        );

        call.enqueue(new Callback<SendNotificationData>() {
            @Override
            public void onResponse(Call<SendNotificationData> call, Response<SendNotificationData> response) {
                pd.dismiss();
                if(response.code()==200){

                    if(response.body().status==true){
                        // new CommonMethod(context, response.body().message);
                    } else {
                        new CommonMethod(context, response.body().message);
                    }

                } else {
                    new CommonMethod(context, "Server Error Code : "+response.code());
                }

            }

            @Override
            public void onFailure(Call<SendNotificationData> call, Throwable t) {
                pd.dismiss();
                new CommonMethod(context, t.getMessage());
            }
        });

    }

    @Override
    public int getItemCount() {
        return arrayList.size();
    }

    public class MyHolder extends RecyclerView.ViewHolder {

        CircleImageView circleImageView;
        ImageView callingImageLogo;

        TextView Name, MobileNumber, Email, Address, AreaANDCity, State, AccountStatus;
        Button AcceptButton, RejectButton;

        public MyHolder(@NonNull View itemView) {
            super(itemView);

            apiInterface = ApiClient.getClient().create(ApiInterface.class);
            sp = context.getSharedPreferences(SharedPreferencesData.PREF, Context.MODE_PRIVATE);

            circleImageView = itemView.findViewById(R.id.custom_admin_new_foreman_request_ProfileImage);
            callingImageLogo = itemView.findViewById(R.id.custom_admin_new_foreman_request_calling_Image_logo);

            Name = itemView.findViewById(R.id.custom_admin_new_foreman_request_FirstANDLastName);
            MobileNumber = itemView.findViewById(R.id.custom_admin_new_foreman_request_MobileNumber);
            Email = itemView.findViewById(R.id.custom_admin_new_foreman_request_Email);
            Address = itemView.findViewById(R.id.custom_admin_new_foreman_request_Address);
            AreaANDCity = itemView.findViewById(R.id.custom_admin_new_foreman_request_AreaANDCity);
            State = itemView.findViewById(R.id.custom_admin_new_foreman_request_state);
            AccountStatus = itemView.findViewById(R.id.custom_admin_new_foreman_request_AccountStatus);

            AcceptButton = itemView.findViewById(R.id.custom_admin_new_foreman_request_AcceptButton);
            RejectButton = itemView.findViewById(R.id.custom_admin_new_foreman_request_RejectButton);

        }
    }
}
