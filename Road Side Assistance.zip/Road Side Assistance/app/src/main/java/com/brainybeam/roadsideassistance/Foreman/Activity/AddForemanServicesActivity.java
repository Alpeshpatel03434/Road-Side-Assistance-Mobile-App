package com.brainybeam.roadsideassistance.Foreman.Activity;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Spinner;

import com.brainybeam.roadsideassistance.Foreman.DashBoard.ForemanServicesFragment;
import com.brainybeam.roadsideassistance.R;
import com.brainybeam.roadsideassistance.RetrofitData.AddForemanServicesData;
import com.brainybeam.roadsideassistance.Utils.ApiClient;
import com.brainybeam.roadsideassistance.Utils.ApiInterface;
import com.brainybeam.roadsideassistance.Utils.CommonMethod;
import com.brainybeam.roadsideassistance.Utils.ConstantData;
import com.brainybeam.roadsideassistance.Utils.SharedPreferencesData;
import com.google.android.material.tabs.TabLayout;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Set;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class AddForemanServicesActivity extends AppCompatActivity {

    Spinner TypeOfProblem, ProblemSubType;
    EditText FixedCharge;
    LinearLayout layout;
    Button AddButton, BackButton;

    ArrayList<String> arrayList_TypeOfProblem, arrayList_ProblemSubType1, arrayList_ProblemSubType2, arrayList_ProblemSubType;
    String sTypeOfProblem, sProblemSubType, sFixedCharge;

    ApiInterface apiInterface;
    SharedPreferences sp;
    ProgressDialog pd;

    int count1, count2, count3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_foreman_services);

        apiInterface = ApiClient.getClient().create(ApiInterface.class);
        sp = getSharedPreferences(SharedPreferencesData.PREF, MODE_PRIVATE);

        TypeOfProblem = findViewById(R.id.add_foreman_services_Spinner_TypeOfProblem);
        ProblemSubType = findViewById(R.id.add_foreman_services_Spinner_ProblemSubType);
        FixedCharge = findViewById(R.id.add_foreman_services_FixedServiceChage);
        layout = findViewById(R.id.add_foreman_services_ProblemSubType_Layout);
        AddButton = findViewById(R.id.add_foreman_services_AddButton);
        BackButton = findViewById(R.id.add_foreman_services_backButton);

       // layout.setVisibility(View.GONE);

        arrayList_TypeOfProblem = new ArrayList<>();
        arrayList_TypeOfProblem.add("Select TypeOfProblem");
        String typeOfSituationalServices[] = ConstantData.TypeOfProblem;
        List<String> list;
        list = Arrays.asList(typeOfSituationalServices);
        arrayList_TypeOfProblem.addAll(list);

        ArrayAdapter arrayAdapter = new ArrayAdapter(getApplicationContext(), android.R.layout.simple_list_item_1, arrayList_TypeOfProblem);
        arrayAdapter.setDropDownViewResource(android.R.layout.simple_list_item_activated_1);
        TypeOfProblem.setAdapter(arrayAdapter);


        sTypeOfProblem = "";
        TypeOfProblem.setSelection(arrayList_TypeOfProblem.indexOf("Select TypeOfProblem"));
        TypeOfProblem.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                TypeOfProblem.setSelection(i);
                sTypeOfProblem = arrayList_TypeOfProblem.get(i);
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });


        arrayList_ProblemSubType1 = new ArrayList<>();
        arrayList_ProblemSubType1.add("Select ProblemSubType");
        String temp1[] = ConstantData.ProblemSubTypeFuel;
        List<String> list1;
        list1 = Arrays.asList(temp1);
        arrayList_ProblemSubType1.addAll(list1);

        ArrayAdapter arrayAdapter1 = new ArrayAdapter(getApplicationContext(), android.R.layout.simple_list_item_1, arrayList_ProblemSubType1);
        arrayAdapter1.setDropDownViewResource(android.R.layout.simple_list_item_activated_1);

        arrayList_ProblemSubType2 = new ArrayList<>();
        arrayList_ProblemSubType2.add("Select ProblemSubType");
        String temp2[] = ConstantData.ProblemSubTypeFuel;
        List<String> list2;
        list2 = Arrays.asList(temp2);
        arrayList_ProblemSubType2.addAll(list2);

        arrayList_ProblemSubType = new ArrayList<>();
        arrayList_ProblemSubType.add("Select ProblemSubType");
        String temp4[] = ConstantData.ProblemSubType;
        List<String> list4;
        list4 = Arrays.asList(temp4);
        arrayList_ProblemSubType.addAll(list4);


        ArrayAdapter arrayAdapter2 = new ArrayAdapter(getApplicationContext(), android.R.layout.simple_list_item_1, arrayList_ProblemSubType2);
        arrayAdapter2.setDropDownViewResource(android.R.layout.simple_list_item_activated_1);
        count1=0;
        count2=0;
        count3=0;

        // Temp
        ArrayList<String> list3 = new ArrayList<>();
        list3.add("-");
        ArrayAdapter arrayAdapter3 = new ArrayAdapter(getApplicationContext(), android.R.layout.simple_list_item_1, list3);
        arrayAdapter3.setDropDownViewResource(android.R.layout.simple_list_item_activated_1);


        ArrayAdapter arrayAdapter4 = new ArrayAdapter(getApplicationContext(), android.R.layout.simple_list_item_1, list4);
        arrayAdapter3.setDropDownViewResource(android.R.layout.simple_list_item_activated_1);


        ProblemSubType.setAdapter(arrayAdapter4);
        ProblemSubType.setSelection(arrayList_ProblemSubType.indexOf("Select ProblemSubType"));

        if(sTypeOfProblem.equals("Fuel Problem")){
            layout.setVisibility(View.VISIBLE);
            ProblemSubType.setAdapter(arrayAdapter1);
            ProblemSubType.setSelection(arrayList_ProblemSubType1.indexOf("Select ProblemSubType"));
            count1 = count1 + 1;

        }
        if (sTypeOfProblem.equals("Tyre Problem")){
            layout.setVisibility(View.VISIBLE);
            ProblemSubType.setAdapter(arrayAdapter2);
            ProblemSubType.setSelection(arrayList_ProblemSubType2.indexOf("Select ProblemSubType"));
            count2 = count2 + 1;

        }
//        else {
//            ProblemSubType.setAdapter(arrayAdapter3);
//            ProblemSubType.setSelection(list3.indexOf("-"));
//            count3 = count3 + 1;
//
//        }


        sProblemSubType = "";

        ProblemSubType.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                ProblemSubType.setSelection(i);
                if(count1!=0){
                    sProblemSubType = arrayList_ProblemSubType.get(i);
                } else if(count2!=0){
                    sProblemSubType = arrayList_ProblemSubType.get(i);
                } else {
                    sProblemSubType = "";
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });


        AddButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                sFixedCharge = FixedCharge.getText().toString();

//                if(sProblemSubType.equalsIgnoreCase("-")){
//                    sProblemSubType = "";
//                }

                if(sTypeOfProblem.equalsIgnoreCase("Select TypeOfProblem") ||
                sTypeOfProblem.equalsIgnoreCase("") || sTypeOfProblem.isEmpty()){
                    new CommonMethod(getApplicationContext(), "Please Select Type Of Problem");
                }
//                else if(sProblemSubType.equalsIgnoreCase("Select ProblemSubType")){
//                    new CommonMethod(getApplicationContext(), "Please Select Problem Sub Type");
//                }
                else if(sFixedCharge.isEmpty() || sFixedCharge.equalsIgnoreCase("")){
                    FixedCharge.setError("FixedCharge is Required");
                } else{

                    pd = new ProgressDialog(AddForemanServicesActivity.this);
                    pd.setMessage("Please Wait...");
                    pd.setCancelable(false);
                    pd.show();
                    AddServicesData();

                }


            }
        });

        BackButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
                // new CommonMethod(AddForemanServicesActivity.this, ForemanServicesFragment.class);
            }
        });


    }

    private void AddServicesData() {

        Call<AddForemanServicesData> call = apiInterface.AddForemanServicesData(
                sp.getString(SharedPreferencesData.UserID, ""),
                sp.getString(SharedPreferencesData.FirstName, ""),
                sp.getString(SharedPreferencesData.LastName, ""),
                sp.getString(SharedPreferencesData.ProfileImage, ""),
                sp.getString(SharedPreferencesData.MobileNumber, ""),
                sp.getString(SharedPreferencesData.ForemanAddress, "")+","+sp.getString(SharedPreferencesData.ForemanArea, "")+","+sp.getString(SharedPreferencesData.ForemanCity, "")+","+sp.getString(SharedPreferencesData.ForemanState, ""),
                sTypeOfProblem,
                sProblemSubType,
                sFixedCharge
        );

        call.enqueue(new Callback<AddForemanServicesData>() {
            @Override
            public void onResponse(Call<AddForemanServicesData> call, Response<AddForemanServicesData> response) {
                pd.dismiss();
                if (response.code()==200){
                    if(response.body().status==true){
                        new CommonMethod(getApplicationContext(), response.body().message);
                        onBackPressed();
                        // new CommonMethod(getApplicationContext(), ForemanServicesFragment.class);
                    } else {
                        new CommonMethod(getApplicationContext(), response.body().message);
                    }

                } else {
                    new CommonMethod(getApplicationContext(), "Server Error Code : "+response.code());
                }

            }

            @Override
            public void onFailure(Call<AddForemanServicesData> call, Throwable t) {
                pd.dismiss();
                new CommonMethod(getApplicationContext(), t.getMessage());
            }
        });

    }

}