package com.brainybeam.roadsideassistance.Utils;

import com.brainybeam.roadsideassistance.RetrofitData.AddUserVehicleData;
import com.brainybeam.roadsideassistance.RetrofitData.AdminActiveSPData;
import com.brainybeam.roadsideassistance.RetrofitData.AdminActiveUsersData;
import com.brainybeam.roadsideassistance.RetrofitData.AdminGetNewForemanRequestData;
import com.brainybeam.roadsideassistance.RetrofitData.AdminRequestData;
import com.brainybeam.roadsideassistance.RetrofitData.CartAddServicesData;
import com.brainybeam.roadsideassistance.RetrofitData.CartGetSPReqMoneyData;
import com.brainybeam.roadsideassistance.RetrofitData.CartPendingPaymentData;
import com.brainybeam.roadsideassistance.RetrofitData.DeleteUserORForemanData;
import com.brainybeam.roadsideassistance.RetrofitData.ForemanLoginData;
import com.brainybeam.roadsideassistance.RetrofitData.GetForemanHistoryData;
import com.brainybeam.roadsideassistance.RetrofitData.GetForemanLocationData;
import com.brainybeam.roadsideassistance.RetrofitData.GetForemanServicesData;
import com.brainybeam.roadsideassistance.RetrofitData.GetForemanUserSelectedServicesData;
import com.brainybeam.roadsideassistance.RetrofitData.GetNotificationData;
import com.brainybeam.roadsideassistance.RetrofitData.GetProfileImageData;
import com.brainybeam.roadsideassistance.RetrofitData.GetUserHistoryData;
import com.brainybeam.roadsideassistance.RetrofitData.GetUserLocationData;
import com.brainybeam.roadsideassistance.RetrofitData.GetUserRequestServicesData;
import com.brainybeam.roadsideassistance.RetrofitData.GetUserVehicleData;
import com.brainybeam.roadsideassistance.RetrofitData.LocationData;
import com.brainybeam.roadsideassistance.RetrofitData.RatingData;
import com.brainybeam.roadsideassistance.RetrofitData.SendNotificationData;
import com.brainybeam.roadsideassistance.RetrofitData.UpdateFCMIDData;
import com.brainybeam.roadsideassistance.RetrofitData.UpdateForemanData;
import com.brainybeam.roadsideassistance.RetrofitData.UpdateUserData;
import com.brainybeam.roadsideassistance.RetrofitData.UserANDForemanLoginData;
import com.brainybeam.roadsideassistance.RetrofitData.UserLoginData;
import com.brainybeam.roadsideassistance.RetrofitData.ForemanSignupData;
import com.brainybeam.roadsideassistance.RetrofitData.SwitchAccountData;
import com.brainybeam.roadsideassistance.RetrofitData.UserSignupData;
import com.brainybeam.roadsideassistance.RetrofitData.AddForemanServicesData;

import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;
import retrofit2.http.Multipart;
import retrofit2.http.POST;
import retrofit2.http.Part;

public interface ApiInterface {

    // TODO User Signup
    @FormUrlEncoded
    @POST("user_signup.php")
    Call<UserSignupData> UserSignupData(
            @Field("UserType") String UserType,
            @Field("FirstName") String FirstName,
            @Field("LastName") String LastName,
            @Field("MobileNumber") String MobileNumber,
            @Field("Email") String Email,
            @Field("Password") String Password,
            @Field("Account_Status") String Account_Status
    );

    // TODO Foreman Signup
    @FormUrlEncoded
    @POST("foreman_signup.php")
    Call<ForemanSignupData> ForemanSignupData(
            @Field("UserType") String UserType,
            @Field("FirstName") String FirstName,
            @Field("LastName") String LastName,
            @Field("MobileNumber") String MobileNumber,
            @Field("Email") String Email,
            @Field("Password") String Password,
            @Field("Address") String Address,
            @Field("Area") String Area,
            @Field("City") String City,
            @Field("State") String State,
            @Field("Account_Status") String Account_Status
    );

    // TODO Switch Account
    @FormUrlEncoded
    @POST("switch.php")
    Call<SwitchAccountData> SwitchAccountData(
            @Field("Email") String Email
    );

    // TODO Both Can Switch Login
    @FormUrlEncoded
    @POST("testLogin.php")
    Call<UserANDForemanLoginData> UserANDForemanLoginData(
            @Field("Email") String Email,
            @Field("Password") String Password
    );

    // TODO Both Can User Login
    @FormUrlEncoded
    @POST("testUserLogin.php")
    Call<UserLoginData> UserLoginData(
            @Field("Email") String Email,
            @Field("Password") String Password
    );

    // TODO Both Can Foreman Login
    @FormUrlEncoded
    @POST("testForemanLogin.php")
    Call<ForemanLoginData> ForemanLoginData(
            @Field("Email") String Email,
            @Field("Password") String Password
    );

    // TODO Update User FCMID
    @FormUrlEncoded
    @POST("updateUserFCMID.php")
    Call<UpdateFCMIDData> UpdateUserFCMIDData(
            @Field("UserID") String UserID,
            @Field("FCMID") String FCMID
    );

    // TODO Update Foreman FCMID
    @FormUrlEncoded
    @POST("updateForemanFCMID.php")
    Call<UpdateFCMIDData> UpdateForemanFCMIDData(
            @Field("ForemanID") String ForemanID,
            @Field("FCMID") String FCMID
    );


    // TODO Update User Data
    @FormUrlEncoded
    @POST("updateUserData.php")
    Call<UpdateUserData> UpdateUserData(
            @Field("UserID") String UserID,
            @Field("FirstName") String FirstName,
            @Field("LastName") String LastName,
            @Field("MobileNumber") String MobileNumber,
            @Field("Email") String Email,
            @Field("Password") String Password
    );

    // TODO Update Foreman Data
    @FormUrlEncoded
    @POST("updateForemanData.php")
    Call<UpdateForemanData> UpdateForemanData(
            @Field("ForemanID") String ForemanID,
            @Field("FirstName") String FirstName,
            @Field("LastName") String LastName,
            @Field("MobileNumber") String MobileNumber,
            @Field("Email") String Email,
            @Field("Password") String Password,
            @Field("Address") String Address,
            @Field("Area") String Area,
            @Field("City") String City,
            @Field("State") String State
    );

    // TODO Delete User Account
    @FormUrlEncoded
    @POST("DeleteUserData.php")
    Call<DeleteUserORForemanData> DeleteUserAccountData(
            @Field("UserID") String UserID
    );

    // TODO Delete Foreman Account
    @FormUrlEncoded
    @POST("DeleteForemanData.php")
    Call<DeleteUserORForemanData> DeleteForemanAccountData(
            @Field("ForemanID") String ForemanID
    );

    // TODO Update User Profile Image
    // @FormUrlEncoded
    @Multipart
    @POST("updateUserProfileImage.php")
    Call<DeleteUserORForemanData> AddUserProfileImage(
            @Part("UserID") String UserID,
            @Part("name") RequestBody name,
            @Part MultipartBody.Part ProfileImage
    );

    // TODO Update User Profile Image
    @FormUrlEncoded
    @Multipart
    @POST("updateForemanProfileImage.php")
    Call<DeleteUserORForemanData> AddForemanProfileImage(
            @Field("ForemanID") String ForemanID,
            @Part("name") RequestBody name,
            @Part MultipartBody.Part image
    );

    // TODO ProfileImage User Account
    @FormUrlEncoded
    @POST("getUserImageProfile.php")
    Call<GetProfileImageData> GetUserProfileImage(
            @Field("UserID") String UserID
    );

    // TODO ProfileImage Foreman Account
    @FormUrlEncoded
    @POST("getForemanImageProfile.php")
    Call<GetProfileImageData> GetForemanProfileImage(
            @Field("ForemanID") String ForemanID
    );

    // TODO Deactivate User Account
    @FormUrlEncoded
    @POST("DeactivateUserAccount.php")
    Call<DeleteUserORForemanData> DeactivateUserAccountData(
            @Field("UserID") String UserID
    );

    // TODO Deactivate Foreman Account
    @FormUrlEncoded
    @POST("DeactivateForemanAccount.php")
    Call<DeleteUserORForemanData> DeactivateForemanAccountData(
            @Field("ForemanID") String ForemanID
    );


    // TODO Send Foreman Request to Admin Account
    @FormUrlEncoded
    @POST("Foreman_AgainSendRequestToAdmin.php")
    Call<DeleteUserORForemanData> ActiveForemanAccountData(
            @Field("ForemanID") String ForemanID
    );

    // TODO Activate User Data
    @FormUrlEncoded
    @POST("User_EnableAccount.php")
    Call<DeleteUserORForemanData> ActivateUserData(
            @Field("UserID") String UserID
    );

    // TODO Deactivate User Data
    @FormUrlEncoded
    @POST("User_DisableAccount.php")
    Call<DeleteUserORForemanData> DeactivateUserData(
            @Field("UserID") String UserID
    );




    // TODO User Forgot Password
    @FormUrlEncoded
    @POST("ForgotPassword_User.php")
    Call<DeleteUserORForemanData> UserForgotPassword(
            @Field("UserID") String UserID,
            @Field("Password") String Password
    );

    // TODO Foreman Forgot Password
    @FormUrlEncoded
    @POST("ForgotPassword_Foreman.php")
    Call<DeleteUserORForemanData> ForemanForgotPassword(
            @Field("ForemanID") String ForemanID,
            @Field("Password") String Password
    );


    // TODO ==============================
    // TODO -------User--------------Start
    // TODO ==============================


    // TODO Add User Vehicle
    @FormUrlEncoded
    @POST("AddUserVehicle.php")
    Call<AddUserVehicleData> AddUserVehicle(
            @Field("UserID") String UserID,
            @Field("NumberPlate_number") String NumberPlate_number,
            @Field("TypeOfVehicle") String TypeOfVehicle,
            @Field("VehicleModelName") String VehicleModelName,
            @Field("Vehicle_Colour") String Vehicle_Colour
    );

    // TODO Get User Vehicle Data
    @FormUrlEncoded
    @POST("getUserVehicleData.php")
    Call<GetUserVehicleData> GetUserVehicleData(
            @Field("UserID") String UserID
    );

    // TODO Update User Vehicle
    @FormUrlEncoded
    @POST("updateUserVehicle.php")
    Call<DeleteUserORForemanData> UpdateUserVehicle(
            @Field("VehicleID") String VehicleID,
            @Field("NumberPlate_number") String NumberPlate_number,
            @Field("TypeOfVehicle") String TypeOfVehicle,
            @Field("VehicleModelName") String VehicleModelName,
            @Field("Vehicle_Colour") String Vehicle_Colour
    );

    // TODO Delete User Vehicle
    @FormUrlEncoded
    @POST("DeleteUserVehicle.php")
    Call<DeleteUserORForemanData> DeleteUserVehicle(
            @Field("UserID") String UserID,
            @Field("VehicleID") String VehicleID
    );



    // TODO ----------------

    // TODO User Request Services
    @FormUrlEncoded
    @POST("getUserRequestServices.php")
    Call<GetUserRequestServicesData> GetUserRequestServicesData(
            @Field("TypeOfProblem") String TypeOfProblem
    );


//    // TODO User Add Ordered Data
//    @FormUrlEncoded
//    @POST("AddOrdered.php")
//    Call<AddForemanServicesData> AddOrderedData(
//            @Field("ServiceID") String ServiceID,
//            @Field("ForemanID") String ForemanID,
//            @Field("UserID") String UserID,
//            @Field("UserLatitude") String UserLatitude,
//            @Field("UserLongitude") String UserLongitude
//    );


    // TODO User to Foreman Send Notification Data
    @FormUrlEncoded
    @POST("SendtoForemanNotification.php")
    Call<SendNotificationData> SendToForemanNotificationData(
            @Field("ForemanID") String ForemanID,
            @Field("Title") String Title,
            @Field("Message") String Message
    );


//    // TODO User Payment
//    @FormUrlEncoded
//    @POST("updateUserPaymentOrdered.php")
//    Call<SendNotificationData> UpdateUserPaymentData(
//            @Field("OrderedID") String OrderedID,
//            @Field("ServiceID") String ServiceID,
//            @Field("PaymentMode") String PaymentMode,
//            @Field("Payment") String Payment
//    );



    // TODO ==============================
    // TODO -------User----------------End
    // TODO ==============================




    // TODO ==============================
    // TODO -------Foreman-----------Start
    // TODO ==============================


    // TODO Add Foreman Services
    @FormUrlEncoded
    @POST("AddForemanServices.php")
    Call<AddForemanServicesData> AddForemanServicesData(
            @Field("ForemanID") String ForemanID,
            @Field("FirstName") String FirstName,
            @Field("LastName") String LastName,
            @Field("ProfileImage") String ProfileImage,
            @Field("MobileNumber") String MobileNumber,
            @Field("Address") String Address,
            @Field("TypeOfProblem") String TypeOfProblem,
            @Field("ProblemSubType") String ProblemSubType,
            @Field("ServiceFixedCharge") String ServiceFixedCharge
    );

    // TODO Get Foreman Services
    @FormUrlEncoded
    @POST("getForemanServices.php")
    Call<GetForemanServicesData> GetForemanServicesData(
            @Field("ForemanID") String ForemanID
    );


    // TODO Get Foreman Accepted Not
    @FormUrlEncoded
    @POST("getForemanNotAccepted.php")
    Call<DeleteUserORForemanData> GetForemanNotAcceptedData(
            @Field("ForemanID") String ForemanID
    );

    // TODO Update Foreman Services
    @FormUrlEncoded
    @POST("updateForemanServices.php")
    Call<AddForemanServicesData> UpdateForemanServicesData(
            @Field("ServiceID") String ServiceID,
            @Field("ForemanID") String ForemanID,
            @Field("MobileNumber") String MobileNumber,
            @Field("TypeOfProblem") String TypeOfProblem,
            @Field("ProblemSubType") String ProblemSubType,
            @Field("ServiceFixedCharge") String ServiceFixedCharge
    );

    // TODO Delete Foreman Services
    @FormUrlEncoded
    @POST("DeleteForemanServices.php")
    Call<AddForemanServicesData> DeleteForemanServicesData(
            @Field("ServiceID") String ServiceID,
            @Field("ForemanID") String ForemanID
    );


    // TODO Add Foreman Location From Profile
    @FormUrlEncoded
    @POST("AddServiceProviderLocation.php")
    Call<LocationData> AddSPProfileLocationData(
            @Field("ForemanID") String ForemanID,
            @Field("Latitude") String Latitude,
            @Field("Longitude") String Longitude
    );

    // TODO Update Foreman Location From Profile
    @FormUrlEncoded
    @POST("UpdateServiceProviderLocation.php")
    Call<LocationData> UpdateSPProfileLocationData(
            @Field("ForemanID") String ForemanID,
            @Field("Latitude") String Latitude,
            @Field("Longitude") String Longitude
    );


//    // TODO Update Foreman Location
//    @FormUrlEncoded
//    @POST("updateServiceProviderLocation.php")
//    Call<AddForemanServicesData> UpdateForemanLocationData(
//            @Field("ForemanID") String ForemanID,
//            @Field("Latitude") String Latitude,
//            @Field("Longitude") String Longitude
//    );


    // TODO Foreman To User Notification Send
    @FormUrlEncoded
    @POST("SendtoUserNotification.php")
    Call<SendNotificationData> SendToUserNotificationData(
            @Field("UserID") String UserID,
            @Field("Title") String Title,
            @Field("Message") String Message
    );



    

    // TODO Get Cart Pending Payment Services Data
    @FormUrlEncoded
    @POST("Cart_GetData_PendingPayment.php")
    Call<CartPendingPaymentData> GetCartPendingPaymentData(
            @Field("ForemanID") String ForemanID
    );





    // TODO ==============================
    // TODO -------Foreman-------------End
    // TODO ==============================


    // TODO ==============================
    // TODO -------User AND Foreman-------Start
    // TODO ==============================

    // TODO Add Cart Services Data
    @FormUrlEncoded
    @POST("Cart_AddService.php")
    Call<CartAddServicesData> AddCartData(
            @Field("ServiceID") String ServiceID,
            @Field("ForemanID") String ForemanID,
            @Field("UserID") String UserID,
            @Field("VehicleID") String VehicleID,
            @Field("SPReqMoney") String SPReqMoney,
            @Field("UserLocation") String UserLocation,
            @Field("PaymentStatus") String PaymentStatus
    );

    // TODO Foreman Get User Selected Services Data
//    @FormUrlEncoded
//    @POST("GetForemanUserRequestForServices.php")
//    Call<GetForemanUserSelectedServicesData> GetForemanUserSelectedServicesData(
//            @Field("ForemanID") String ForemanID
//    );
    // TODO Foreman Get User Selected Services Data
//    @FormUrlEncoded
//    @POST("Foreman_UserRequestForServices.php")
//    Call<GetForemanUserSelectedServicesData> GetForemanUserSelectedServicesData(
//            @Field("ForemanID") String ForemanID
//    );

    // TODO Foreman Get User Selected Services Data
    @FormUrlEncoded
    @POST("Foreman_UserRequesttoServicesData.php")
    Call<GetForemanUserSelectedServicesData> GetForemanUserSelectedServicesData(
            @Field("ForemanID") String ForemanID
    );



    // TODO Foreman Service Provider Request Money Data
    @FormUrlEncoded
    @POST("Cart_Update_SPReqMoney.php")
    Call<CartAddServicesData> UpdateSPReqMoneyData(
            @Field("ServiceID") String ServiceID,
            @Field("ForemanID") String ForemanID,
            @Field("UserID") String UserID,
            @Field("SPReqMoney") String SPReqMoney
    );

    // TODO Get Payment Status
    @FormUrlEncoded
    @POST("Cart_PaymentStatus.php")
    Call<CartAddServicesData> GetPaymentStatusData(
            @Field("CartID") String CartID
    );

    // TODO Get SP Amount
    @FormUrlEncoded
    @POST("Cart_GetSPReqMoneyData.php")
    Call<CartGetSPReqMoneyData> GetSPReqMoneyData(
            @Field("ServiceID") String ServiceID,
            @Field("ForemanID") String ForemanID,
            @Field("UserID") String UserID
    );

    // TODO Update Payment
    // TODO PaymentID Generate
  /*  Random random = new Random();
    String alphabet = "1234567890ABCDabcdXYZxyz";
        for (int i = 0; i < 10; i++) {
        PaymentID = UserID+String.valueOf(alphabet.charAt(random.nextInt(alphabet.length())));
    } */
    @FormUrlEncoded
    @POST("Cart_PaymentStatus.php")
    Call<CartAddServicesData> UpdateCartPaymentData(
            @Field("CartID") String CartID,
            @Field("PaymentMode") String PaymentMode,
            @Field("Payment") String Payment,
            @Field("PaymentStatus") String PaymentStatus,
            @Field("PaymentID") String PaymentID
    );



    // TODO Add Cart Data in to User History Data
    @FormUrlEncoded
    @POST("history_AddData.php")
    Call<CartAddServicesData> AddHistoryData(
            @Field("CartID") String CartID,
            @Field("ServiceID") String ServiceID,
            @Field("ForemanID") String ForemanID,
            @Field("UserID") String UserID,
            @Field("VehicleID") String VehicleID,
            @Field("ProblemDescriptionMessage") String ProblemDescriptionMessage,
            @Field("PaymentID") String PaymentID,
            @Field("SPReqMoney") String SPReqMoney,
            @Field("PaymentMode") String PaymentMode,
            @Field("Payment") String Payment,
            @Field("UserLocation") String UserLocation
    );

    // TODO Delete Cart Data
    @FormUrlEncoded
    @POST("Cart_DeleteData.php")
    Call<CartAddServicesData> DeleteCartData(
            @Field("CartID") String CartID
    );

//    // TODO Update Cart User Location Data
//    @FormUrlEncoded
//    @POST("Cart_Update_UserLocation.php")
//    Call<CartAddServicesData> UpdateCartUserLocatinData(
//            @Field("CartID") String CartID,
//            @Field("UserLocation") String UserLocation
//    );


    // TODO Cart Update ProblemDescriptionMessage from user Data
    @FormUrlEncoded
    @POST("Cart_Update_ProblemMessage.php")
    Call<CartAddServicesData> UpdateCartProblemDescriptionMessageData(
            @Field("ServiceID") String ServiceID,
            @Field("ForemanID") String ForemanID,
            @Field("UserID") String UserID,
            @Field("ProblemDescriptionMessage") String ProblemDescriptionMessage
    );

    // TODO Get User History Data
    @FormUrlEncoded
    @POST("history_GetUserHistoryData.php")
    Call<GetUserHistoryData> GetUserHistoryData(
            @Field("UserID") String UserID
    );

    // TODO Get Foreman History Data
    @FormUrlEncoded
    @POST("history_GetForemanHistoryData.php")
    Call<GetForemanHistoryData> GetForemanHistoryData(
            @Field("ForemanID") String ForemanID
    );




    @FormUrlEncoded
    @POST("Cart_Update_ReqStatus.php")
    Call<CartAddServicesData> UpdateReqStatusData(
            @Field("CartID") String CartID
    );

    @FormUrlEncoded
    @POST("Cart_Update_ReqStatus_Reject.php")
    Call<CartAddServicesData> UpdateReqStatusRejectData(
            @Field("CartID") String CartID
    );


    // TODO ==============================
    // TODO -------User AND Foreman-------Notification
    // TODO ==============================

    // TODO Get User Notification Data
    @FormUrlEncoded
    @POST("GetNotification.php")
    Call<GetNotificationData> GetUserNotificationData(
            @Field("UserType") String UserType,
            @Field("UserID") String UserID
    );

    // TODO Get Foreman Notification Data
    @FormUrlEncoded
    @POST("GetNotification.php")
    Call<GetNotificationData> GetForemanNotificationData(
            @Field("UserType") String UserType,
            @Field("UserID") String UserID
    );

    // TODO Update Notification Data
    @FormUrlEncoded
    @POST("UpdateNotification.php")
    Call<SendNotificationData> UpdateNotificationData(
            @Field("NotificationID") String NotificationID
    );

    // TODO Delete Notification Data
    @FormUrlEncoded
    @POST("DeleteNotification.php")
    Call<SendNotificationData> DeleteNotificationData(
            @Field("NotificationID") String NotificationID
    );


    // TODO -------------Location-----------------
    // TODO --------- User & Foreman ------------Start
    // TODO --------------------------------------

    // TODO Add User Location Data
    @FormUrlEncoded
    @POST("UserLocation_AddUserLocation.php")
    Call<LocationData> AddUserLocationData(
            @Field("UserID") String UserID,
            @Field("ForemanID") String ForemanID,
            @Field("UserLatitude") String UserLatitude,
            @Field("UserLongitude") String UserLongitude
    );

    // TODO Add Foreman Location Data
    @FormUrlEncoded
    @POST("ForemanLocation_AddServiceProviderLocation.php")
    Call<LocationData> AddForemanLocationData(
            @Field("ForemanID") String ForemanID,
            @Field("UserID") String UserID,
            @Field("ForemanLatitude") String ForemanLatitude,
            @Field("ForemanLongitude") String ForemanLongitude
    );

    // TODO Get User Location Data
    @FormUrlEncoded
    @POST("UserLocation_GetData.php")
    Call<GetUserLocationData> GetUserLocationData(
            @Field("UserID") String UserID,
            @Field("ForemanID") String ForemanID
    );

    // TODO Get Foreman Location Data
    @FormUrlEncoded
    @POST("ForemanLocation_GetData.php")
    Call<GetForemanLocationData> GetForemanLocationData(
            @Field("ForemanID") String ForemanID,
            @Field("UserID") String UserID
    );

    // TODO Update User Location Data
    @FormUrlEncoded
    @POST("UserLocation_UpdateData.php")
    Call<LocationData> UpdateUserLocationData(
            @Field("UserLocationID") String UserLocationID,
            @Field("UserLatitude") String UserLatitude,
            @Field("UserLongitude") String UserLongitude
    );

    // TODO Update Foreman Location Data
    @FormUrlEncoded
    @POST("ForemanLocation_UpdateData.php")
    Call<LocationData> UpdateForemanLocationData(
            @Field("ForemanLocationID") String ForemanLocationID,
            @Field("ForemanLatitude") String ForemanLatitude,
            @Field("ForemanLongitude") String ForemanLongitude
    );


    // TODO Delete User Location Data
    @FormUrlEncoded
    @POST("UserLocation_DeleteData.php")
    Call<LocationData> DeleteUserLocationData(
            @Field("UserLocationID") String UserLocationID
    );

    // TODO Delete Foreman Location Data
    @FormUrlEncoded
    @POST("ForemanLocation_DeleteData.php")
    Call<LocationData> DeleteForemanLocationData(
            @Field("ForemanLocationID") String ForemanLocationID
    );





    // TODO --------------------------------------
    // TODO --------- Admin ------------Start
    // TODO --------------------------------------


    // TODO Admin New Foreman Request Data
    @GET("Admin_NewForemanRequest.php")
    Call<AdminGetNewForemanRequestData> GetAdminNewForemanRequestData();

    // TODO Admin Foreman Accept Data
    @FormUrlEncoded
    @POST("Admin_NewForemanAccept.php")
    Call<AdminRequestData> AcceptForemanData(
            @Field("ForemanID") String ForemanID
    );

    // TODO Admin Foreman Reject Data
    @FormUrlEncoded
    @POST("Admin_NewForemanReject.php")
    Call<AdminRequestData> RejectForemanData(
            @Field("ForemanID") String ForemanID
    );

    // TODO Admin Active Users Data
    @GET("Admin_ActiveUser.php")
    Call<AdminActiveUsersData> GetAdminActiveUsersData();

    // TODO Admin Active Service Providers Data
    @GET("Admin_ActiveForeman.php")
    Call<AdminActiveSPData> GetAdminServiceProviderData();



    // TODO --------------------------------------
    // TODO --------- Rating ------------Start
    // TODO --------------------------------------


    // TODO Add User Rating Data
    @FormUrlEncoded
    @POST("Rating_AddData.php")
    Call<AdminRequestData> AddUserRatingData(
            @Field("ForemanID") String ForemanID,
            @Field("Rating") String Rating
    );

    // TODO Get User Rating Data
    @FormUrlEncoded
    @POST("Rating_GetData.php")
    Call<RatingData> GetUserRatingData(
            @Field("ForemanID") String ForemanID
    );


    // TODO -----------------------------------
    // TODO ================================

    // TODO Both Can Switch Login
    @FormUrlEncoded
    @POST("testLogin_EnableDisable.php.php")
    Call<UserANDForemanLoginData> UserANDForemanEnableLoginData(
            @Field("Email") String Email,
            @Field("Password") String Passwor
    );

    // TODO Both Can User Login
    @FormUrlEncoded
    @POST("testUser_LoginEnableDisable.php")
    Call<UserLoginData> UserEnableLoginData(
            @Field("Email") String Email,
            @Field("Password") String Password
    );

    // TODO Both Can Foreman Login
    @FormUrlEncoded
    @POST("testForemanLogin_EnableDisable.php")
    Call<ForemanLoginData> ForemanEnableLoginData(
            @Field("Email") String Email,
            @Field("Password") String Password
    );




    // TODO User
    @FormUrlEncoded
    @POST("ServiceAcceptRequest.php")
    Call<DeleteUserORForemanData> GetRequestStatusData(
            @Field("CartID") String CartID
    );


    // TODO User
    @FormUrlEncoded
    @POST("Request_Status_Update.php")
    Call<DeleteUserORForemanData> UpdateRequestStatusData(
            @Field("CartID") String CartID,
            @Field("Request_Status") String Request_Status
    );


//    @FormUrlEncoded
//    @POST("ValidUserLogin.php")
//    Call<ValidUserLoginData> ValidUserDirectLoginData(
//            @Field("Email") String Email,
//            @Field("Password") String Password
//    );
//
//    @FormUrlEncoded
//    @POST("ValidForemanLogin.php")
//    Call<ValidForemanLoginData> ValidForemanDirectLoginData(
//            @Field("Email") String Email,
//            @Field("Password") String Password
//    );


//    @FormUrlEncoded
//    @POST("login.php")
//    Call<LoginData> LoginData(
//            @Field("Email") String Email,
//            @Field("Password") String Password
//    );

//    // Switch
//    @FormUrlEncoded
//    @POST("login.php")
//    Call<LoginUserData> UserLoginData(
//            @Field("Email") String Email,
//            @Field("Password") String Password,
//            @Field("UserType") String UserType
//    );
//
//    // Switch
//    @FormUrlEncoded
//    @POST("login.php")
//    Call<LoginForemanData> ForemanLoginData(
//            @Field("Email") String Email,
//            @Field("Password") String Password,
//            @Field("UserType") String UserType
//    );



}
