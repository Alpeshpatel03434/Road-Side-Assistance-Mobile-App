package com.brainybeam.roadsideassistance.RetrofitData;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.List;

public class GetNotificationData {

    @SerializedName("Status")
    @Expose
    public Boolean status;
    @SerializedName("Message")
    @Expose
    public String message;
    @SerializedName("response")
    @Expose
    public List<GetNotificationResponse> response = null;

    public class GetNotificationResponse {

        @SerializedName("NotificationID")
        @Expose
        public String notificationID;
        @SerializedName("Title")
        @Expose
        public String title;
        @SerializedName("Message")
        @Expose
        public String message;
        @SerializedName("MStatus")
        @Expose
        public String mStatus;
        @SerializedName("Created_time")
        @Expose
        public String createdTime;

    }

}
