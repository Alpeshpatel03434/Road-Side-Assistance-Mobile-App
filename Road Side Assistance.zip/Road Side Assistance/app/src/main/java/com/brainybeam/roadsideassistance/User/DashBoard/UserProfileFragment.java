package com.brainybeam.roadsideassistance.User.DashBoard;

import static android.app.Activity.RESULT_OK;

import android.Manifest;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;

import android.provider.Settings;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.brainybeam.roadsideassistance.Login.LoginActivity;
import com.brainybeam.roadsideassistance.OTPVerification.OTPVerificationActivity;
import com.brainybeam.roadsideassistance.R;
import com.brainybeam.roadsideassistance.RetrofitData.DeleteUserORForemanData;
import com.brainybeam.roadsideassistance.RetrofitData.GetProfileImageData;
import com.brainybeam.roadsideassistance.RetrofitData.UpdateUserData;
import com.brainybeam.roadsideassistance.Utils.ApiClient;
import com.brainybeam.roadsideassistance.Utils.ApiInterface;
import com.brainybeam.roadsideassistance.Utils.CommonMethod;
import com.brainybeam.roadsideassistance.Utils.FilePath;
import com.brainybeam.roadsideassistance.Utils.SharedPreferencesData;
import com.google.firebase.FirebaseApp;
import com.google.firebase.FirebaseException;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.PhoneAuthCredential;
import com.google.firebase.auth.PhoneAuthOptions;
import com.google.firebase.auth.PhoneAuthProvider;
import com.squareup.picasso.Picasso;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import de.hdodenhof.circleimageview.CircleImageView;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


public class UserProfileFragment extends Fragment {

    LinearLayout layout1, layout2;
    CircleImageView ProfileImage1, ProfileImage2;
    TextView FirstName, LastName, Contact, Email, AccountStatus;
    EditText FirstName_EditText, LastName_EditText, Contact_EditText, Email_EditText, Password_EditText;
    Button EditTextButton, UpdateButton, DeactivateButton1, DeactivateButton2;

    String sFirstName, sLastName, sContact, sEmail, sPassword;

    ApiInterface apiInterface;
    SharedPreferences sp;
    ProgressDialog pd;
    Bundle bundle;

    FirebaseApp firebaseApp;
    private FirebaseAuth mAuth;
    private PhoneAuthProvider.OnVerificationStateChangedCallbacks mCallbacks;
    private String sPhone;

    private String EmailPattern = "[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+";

    String[] appPermission = {Manifest.permission.READ_EXTERNAL_STORAGE};
    private static final int PERMISSION_REQUEST_CODE = 1240;
    private static final int PICK_IMAGE_REQUEST = 12;

    String sImagePath1 = "";
    String sImagePath2 = "";

    String getImageURL = "";

    Bitmap bitmap;

    public UserProfileFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for getActivity() fragment
        View view = inflater.inflate(R.layout.fragment_user_profile, container, false);

        firebaseApp = FirebaseApp.initializeApp(getActivity());
        mAuth = FirebaseAuth.getInstance();

        apiInterface = ApiClient.getClient().create(ApiInterface.class);
        sp = getActivity().getSharedPreferences(SharedPreferencesData.PREF, Context.MODE_PRIVATE);

        layout1 = view.findViewById(R.id.frag_user_profile_layout1);
        layout2 = view.findViewById(R.id.frag_user_profile_layout2);
        ProfileImage1 = view.findViewById(R.id.frag_user_profile_userProfileImage);
        ProfileImage2 = view.findViewById(R.id.frag_user_profile_userProfileImage2);
        FirstName = view.findViewById(R.id.frag_user_profile_FirstName);
        LastName = view.findViewById(R.id.frag_user_profile_LastName);
        Contact = view.findViewById(R.id.frag_user_profile_MobileNumber);
        Email = view.findViewById(R.id.frag_user_profile_Email);
        AccountStatus = view.findViewById(R.id.frag_user_profile_AccountStatus);
        FirstName_EditText = view.findViewById(R.id.frag_user_profile_FirstNameEditText);
        LastName_EditText = view.findViewById(R.id.frag_user_profile_LastNameEditText);
        Contact_EditText = view.findViewById(R.id.frag_user_profile_MobileNumberEditText);
        Email_EditText = view.findViewById(R.id.frag_user_profile_EmailEditText);
        Password_EditText = view.findViewById(R.id.frag_user_profile_PasswordEditText);
        EditTextButton = view.findViewById(R.id.frag_user_profile_EditProfileButton);
        UpdateButton = view.findViewById(R.id.frag_user_profile_UpdateButton);
        DeactivateButton1 = view.findViewById(R.id.frag_user_profile_deactivateButton);
        DeactivateButton2 = view.findViewById(R.id.frag_user_profile_deactivateButton2);

        layout2.setVisibility(View.GONE);

        // TODO Get Profile Image
        getUserImage();
//        if(sp.getString(SharedPreferencesData.ProfileImage, "").isEmpty() ||
//                sp.getString(SharedPreferencesData.ProfileImage, "").equalsIgnoreCase("") ||
//        sp.getString(SharedPreferencesData.ProfileImage, "").equalsIgnoreCase("ProfileImage")){
//
//        } else {

        if(sp.getString(SharedPreferencesData.ProfileImage, "").equalsIgnoreCase("https://alpeshpatel-project.000webhostapp.com/RoadSideAssistance/UsersImages/")){

        } else {
            Picasso.with(getActivity()).load(sp.getString(SharedPreferencesData.ProfileImage, "")).placeholder(R.drawable.ic_profile).into(ProfileImage1);
        }

//        }
        FirstName.setText(sp.getString(SharedPreferencesData.FirstName, ""));
        LastName.setText(sp.getString(SharedPreferencesData.LastName, ""));
        Contact.setText(sp.getString(SharedPreferencesData.MobileNumber, ""));
        Email.setText(sp.getString(SharedPreferencesData.Email, ""));
        AccountStatus.setText(sp.getString(SharedPreferencesData.Account_Status, ""));

        EditTextButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                layout2.setVisibility(View.VISIBLE);
                layout1.setVisibility(View.GONE);
            }
        });

        UpdateButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                sFirstName = FirstName_EditText.getText().toString();
                sLastName = LastName_EditText.getText().toString();
                sContact = Contact_EditText.getText().toString();
                sEmail = Email_EditText.getText().toString();
                sPassword = Password_EditText.getText().toString();

                if(sFirstName.isEmpty() || sFirstName.equalsIgnoreCase("")){
                    FirstName_EditText.setError("FirstName is Required");
                } else if(sLastName.isEmpty() || sLastName.equalsIgnoreCase("")){
                    LastName_EditText.setError("LastName is Required");
                } else if(sContact.isEmpty() || sContact.equalsIgnoreCase("")){
                    Contact_EditText.setError("Mobile number is Required");
                }
//                else if(sContact.length()>10 || sContact.length()<9){
//                    Contact_EditText.setError("Mobile number is Not valid");
//                }
                else if(sEmail.isEmpty() || sEmail.equalsIgnoreCase("")){
                    Email_EditText.setError("Email is Required");
                } else if(!sEmail.matches(EmailPattern)){
                    Email_EditText.setError("Valid Email is Required");
                } else if(sPassword.isEmpty() || sPassword.equalsIgnoreCase("")){
                    Password_EditText.setError("Password is Required");
                } else if(sPassword.length()<8){
                    Password_EditText.setError("Password must be 8 char long");
                } else {

                    pd = new ProgressDialog(getActivity());
                    pd.setMessage("Please Wait...");
                    pd.setCancelable(false);
                    pd.show();

                    UpdateUserProfileImageData();
                    sp.edit().putString(SharedPreferencesData.ProfileImage, sImagePath2).commit();
                    UpdateUserProfileData();
                }

            }
        });

        ProfileImage1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (checkAndRequestPermission()) {
                    selectImageMethod();
                }
                // selectImageMethod();
            }
        });

        ProfileImage2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (checkAndRequestPermission()) {
                    selectImageMethod();
                }
            }
        });

        DeactivateButton1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                pd = new ProgressDialog(getActivity());
                pd.setMessage("Please Wait...");
                pd.setCancelable(false);
                pd.show();

                DeactivateUserAccount();
            }
        });

        DeactivateButton2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                pd = new ProgressDialog(getActivity());
                pd.setMessage("Please Wait...");
                pd.setCancelable(false);
                pd.show();

                DeactivateUserAccount();
            }
        });

      //  getActivity().onBackPressed()

      //  Picasso.with(getActivity()).load(sp.getString(SharedPreferencesData.ProfileImage, "")).placeholder(R.drawable.ic_profile).into(ProfileImage1);
        return view;
    }


    private void getUserImage() {

        Call<GetProfileImageData> call = apiInterface.GetUserProfileImage(
                sp.getString(SharedPreferencesData.UserID, "")
        );

        call.enqueue(new Callback<GetProfileImageData>() {
            @Override
            public void onResponse(Call<GetProfileImageData> call, Response<GetProfileImageData> response) {
                if(response.code()==200){
                    if(response.body().status==true){
                      //  new CommonMethod(getActivity(),response.body().message);

                        GetProfileImageData data = response.body();
                        for(int i=0; i<data.response.size(); i++){
                            getImageURL = data.response.get(i).profileImage;
                        }
                        sp.edit().putString(SharedPreferencesData.ProfileImage, getImageURL).commit();

                    }
                    else{
                        new CommonMethod(getActivity(),response.body().message);
                    }
                }
                else{
                    new CommonMethod(getActivity(),"Server Error Code : "+response.code());
                }
            }

            @Override
            public void onFailure(Call<GetProfileImageData> call, Throwable t) {
                new CommonMethod(getActivity(),t.getMessage());
            }
        });

    }

    private void UpdateUserProfileImageData() {

        RequestBody namePart = RequestBody.create(MultipartBody.FORM, sp.getString(SharedPreferencesData.FirstName, ""));

        File imageFile = new File(sImagePath2);
        RequestBody imageBody = RequestBody.create(MediaType.parse("image/*"), imageFile);
        MultipartBody.Part imagesParts = MultipartBody.Part.createFormData("ProfileImage", imageFile.getName(), imageBody);

        Call<DeleteUserORForemanData> call = apiInterface.AddUserProfileImage(
                sp.getString(SharedPreferencesData.UserID, ""), namePart, imagesParts
        );
        call.enqueue(new Callback<DeleteUserORForemanData>() {
            @Override
            public void onResponse(Call<DeleteUserORForemanData> call, Response<DeleteUserORForemanData> response) {
                pd.dismiss();
                if(response.code()==200){
                    if(response.body().status==true){
                        new CommonMethod(getActivity(),response.body().message);
                    }
                    else{
                        new CommonMethod(getActivity(),response.body().message);
                    }
                }
                else{
                    new CommonMethod(getActivity(),"Server Error Code : "+response.code());
                }
            }

            @Override
            public void onFailure(Call<DeleteUserORForemanData> call, Throwable t) {
                pd.dismiss();
                new CommonMethod(getActivity(),t.getMessage());
            }
        });

    }


    private void DeactivateUserAccount() {

        Call<DeleteUserORForemanData> call = apiInterface.DeactivateUserAccountData(
                sp.getString(SharedPreferencesData.UserID, "")
        );

        call.enqueue(new Callback<DeleteUserORForemanData>() {
            @Override
            public void onResponse(Call<DeleteUserORForemanData> call, Response<DeleteUserORForemanData> response) {
                pd.dismiss();
                if(response.code()==200){

                    if (response.body().status==true){
                        new CommonMethod(getActivity(), "Your Account SuccessFully Deactivate");
                        new CommonMethod(getActivity(), LoginActivity.class);
                    } else {
                        new CommonMethod(getActivity(), response.body().message);
                    }

                } else {
                    new CommonMethod(getActivity(), "Server Error Code "+response.code());
                }

            }

            @Override
            public void onFailure(Call<DeleteUserORForemanData> call, Throwable t) {
                pd.dismiss();
                new CommonMethod(getActivity(), t.getMessage());
            }
        });

    }

    private void UpdateUserProfileData() {

        Call<UpdateUserData> call = apiInterface.UpdateUserData(
                sp.getString(SharedPreferencesData.UserID, ""),
                sFirstName, sLastName, sContact, sEmail, sPassword
        );

        call.enqueue(new Callback<UpdateUserData>() {
            @Override
            public void onResponse(Call<UpdateUserData> call, Response<UpdateUserData> response) {
                pd.dismiss();
                if(response.code()==200){

                    if(response.body().status.equalsIgnoreCase("True")){

                        new CommonMethod(getActivity(), response.body().message);

                        sp.edit().putString(SharedPreferencesData.FirstName, sFirstName).commit();
                        sp.edit().putString(SharedPreferencesData.LastName, sLastName).commit();
                        sp.edit().putString(SharedPreferencesData.MobileNumber, sContact).commit();
                        sp.edit().putString(SharedPreferencesData.Email, sEmail).commit();
                        sp.edit().putString(SharedPreferencesData.Password, sPassword).commit();

                        FirstName.setText(sp.getString(SharedPreferencesData.FirstName, ""));
                        LastName.setText(sp.getString(SharedPreferencesData.LastName, ""));
                        Contact.setText(sp.getString(SharedPreferencesData.MobileNumber, ""));
                        Email.setText(sp.getString(SharedPreferencesData.Email, ""));
                        AccountStatus.setText(sp.getString(SharedPreferencesData.Account_Status, ""));

                        layout1.setVisibility(View.VISIBLE);
                        layout2.setVisibility(View.GONE);


                    } else if(response.body().status.equalsIgnoreCase("Pending")){

                        new CommonMethod(getActivity(), response.body().message);

                        sp.edit().putString(SharedPreferencesData.FirstName, sFirstName).commit();
                        sp.edit().putString(SharedPreferencesData.LastName, sLastName).commit();
                        sp.edit().putString(SharedPreferencesData.MobileNumber, sContact).commit();
                        sp.edit().putString(SharedPreferencesData.Email, sEmail).commit();
                        sp.edit().putString(SharedPreferencesData.Password, sPassword).commit();

                        sPhone = sContact;
                        otpSendToMobile(sPhone);

                    } else {
                        new CommonMethod(getActivity(), response.body().message);
                    }

                } else {
                    new CommonMethod(getActivity(), "Server Error Code "+response.code());
                }

            }

            @Override
            public void onFailure(Call<UpdateUserData> call, Throwable t) {
                pd.dismiss();
                new CommonMethod(getActivity(), t.getMessage());
            }
        });

    }


    private void otpSendToMobile(String sPhone) {

        mCallbacks = new PhoneAuthProvider.OnVerificationStateChangedCallbacks() {

            @Override
            public void onVerificationCompleted(PhoneAuthCredential credential) {

            }

            @Override
            public void onVerificationFailed(FirebaseException e) {
                pd.dismiss();
                new CommonMethod(getActivity(), e.getLocalizedMessage());
            }

            @Override
            public void onCodeSent(@NonNull String VerificationId,
                                   @NonNull PhoneAuthProvider.ForceResendingToken token) {
                pd.dismiss();

                new CommonMethod(getActivity(), "OTP is successFully Send");


                bundle.putString("PhoneNumber", sPhone.trim());
                bundle.putString("Mobile_VerificationID", VerificationId);
                Intent intent = new Intent(getActivity(), OTPVerificationActivity.class);
                intent.putExtras(bundle);
                startActivity(intent);
            }
        };

        PhoneAuthOptions options =
                PhoneAuthOptions.newBuilder(mAuth)
                        .setPhoneNumber("+91" + sPhone.trim())
                        .setTimeout(60L, TimeUnit.SECONDS)
                        .setActivity(getActivity())
                        .setCallbacks(mCallbacks)
                        .build();
        PhoneAuthProvider.verifyPhoneNumber(options);

    }

//    private void selectImageMethod() {
//        Intent intent = new Intent();
//        intent.setType("image/*");
//        intent.setAction(Intent.ACTION_GET_CONTENT);
//        startActivityForResult(Intent.createChooser(intent, "Select Picture"), PICK_IMAGE_REQUEST);
//    }
//
//    @Override
//    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
//        super.onActivityResult(requestCode, resultCode, data);
//        if(requestCode==PICK_IMAGE_REQUEST && resultCode==RESULT_OK && data !=null){
//            Uri uri = data.getData();
//            Log.d("RESPONSE_URI", String.valueOf(uri));
//            ProfileImage1.setImageURI(uri);
//            ProfileImage2.setImageURI(uri);
//
//            sImagePath1 = convertMediaUriToPath(uri);
//            sImagePath2 = convertMediaUriToPath(uri);
////            File file = new File(uri.getPath());//create path from uri
////            final String[] split = file.getPath().split(":");//split the path.
////            sImagePath1 = split[1];//assign it to a string(your choice).
////            sImagePath2 = split[1];
//           // sImagePath1 = getRealPathFromUri(getActivity(), uri);
//           // sImagePath2 = getRealPathFromUri(getActivity(), uri);
////            List<Uri> mSelected = Matisse.obtainResult(data);
////            Log.d("RESPONSE_MATISSE", String.valueOf(mSelected));
////            imageView.setImageURI(mSelected.get(0));
////            sImagePath = getRealPathFromUri(ImageUploadActivity.getActivity(),mSelected.get(0));
////            Log.d("RESPONSE_IMAGE_PATH",sImagePath);
////            imageView.setVisibility(View.VISIBLE);
////            uploadButton.setVisibility(View.VISIBLE);
//        }
//    }
//
//
//    public String convertMediaUriToPath(Uri uri) {
//        String [] proj={MediaStore.Images.Media.DATA};
//        Cursor cursor = getActivity().getContentResolver().query(uri, proj,  null, null, null);
//        int column_index = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA);
//        cursor.moveToFirst();
//        String path = cursor.getString(column_index);
//        cursor.close();
//        return path;
//    }
//    public static String getRealPathFromUri(Context context, Uri contentUri) {
//        Cursor cursor = null;
//        try {
//            String[] proj = {MediaStore.Images.Media.DATA};
//            cursor = context.getContentResolver().query(contentUri, proj, null, null, null);
//            int column_index = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA);
//            cursor.moveToFirst();
//            return cursor.getString(column_index);
//        } finally {
//            if (cursor != null) {
//                cursor.close();
//            }
//        }
//    }
//
//    public boolean checkAndRequestPermission() {
//        List<String> listPermission = new ArrayList<>();
//        for (String perm : appPermission) {
//            if (ContextCompat.checkSelfPermission(getActivity(), perm) != PackageManager.PERMISSION_GRANTED) {
//                listPermission.add(perm);
//            }
//        }
//        if (!listPermission.isEmpty()) {
//            ActivityCompat.requestPermissions(getActivity(), listPermission.toArray(new String[listPermission.size()]), PERMISSION_REQUEST_CODE);
//            return false;
//        }
//        return true;
//    }
//
//    @Override
//    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
//        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
//        if (requestCode == PERMISSION_REQUEST_CODE) {
//            HashMap<String, Integer> permissionResult = new HashMap<>();
//            int deniedCount = 0;
//            for (int i = 0; i < grantResults.length; i++) {
//                if (grantResults[i] == PackageManager.PERMISSION_DENIED) {
//                    permissionResult.put(permissions[i], grantResults[i]);
//                    deniedCount++;
//                }
//            }
//            if (deniedCount == 0) {
//                selectImageMethod();
//            } else {
//                for (Map.Entry<String, Integer> entry : permissionResult.entrySet()) {
//                    String permName = entry.getKey();
//                    int permResult = entry.getValue();
//                    if (ActivityCompat.shouldShowRequestPermissionRationale(getActivity(), permName)) {
//                        showDialogPermission("", "getActivity() App needs Read External Storage permissions to work whithout and problems.",
//                                "Yes, Grant permissions", new DialogInterface.OnClickListener() {
//                                    @Override
//                                    public void onClick(DialogInterface dialogInterface, int i) {
//                                        dialogInterface.dismiss();
//                                        checkAndRequestPermission();
//                                    }
//                                },
//                                "No, Exit app", new DialogInterface.OnClickListener() {
//                                    @Override
//                                    public void onClick(DialogInterface dialogInterface, int i) {
//                                        dialogInterface.dismiss();
//                                        getActivity().finishAffinity();
//                                    }
//                                }, false);
//                    } else {
//                        showDialogPermission("", "You have denied some permissions. Allow all permissions at [Setting] > [Permissions]",
//                                "Go to Settings", new DialogInterface.OnClickListener() {
//                                    @Override
//                                    public void onClick(DialogInterface dialogInterface, int i) {
//                                        dialogInterface.dismiss();
//                                        Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
//                                                Uri.fromParts("package", getActivity().getPackageName(), null));
//                                        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
//                                        startActivity(intent);
//                                        getActivity().finish();
//                                    }
//                                }, "No, Exit app", new DialogInterface.OnClickListener() {
//                                    @Override
//                                    public void onClick(DialogInterface dialogInterface, int i) {
//                                        dialogInterface.dismiss();
//                                        getActivity().finish();
//                                    }
//                                }, false);
//                        break;
//                    }
//                }
//            }
//        }
//    }
//
//    public AlertDialog showDialogPermission(String title, String msg, String positiveLable, DialogInterface.OnClickListener positiveOnClickListener, String negativeLable, DialogInterface.OnClickListener negativeOnClickListener, boolean isCancelable) {
//        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
//        builder.setTitle(title);
//        builder.setCancelable(isCancelable);
//        builder.setMessage(msg);
//        builder.setPositiveButton(positiveLable, positiveOnClickListener);
//        builder.setNegativeButton(negativeLable, negativeOnClickListener);
//        AlertDialog alertDialog = builder.create();
//        alertDialog.show();
//        return alertDialog;
//    }


    private void selectImageMethod() {
        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(Intent.createChooser(intent, "Select Pdf"), PICK_IMAGE_REQUEST);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode==PICK_IMAGE_REQUEST && resultCode==RESULT_OK && data !=null){
            /*Uri uri = data.getData();
            Log.d("RESPONSE_URI", String.valueOf(uri));
            imageView.setImageURI(uri);*/
            sImagePath1 = FilePath.getPath(getActivity(), data.getData());
            sImagePath2 = FilePath.getPath(getActivity(), data.getData());
          //  Log.d("RESPONSE_IMAGE_PATH",sImagePath);
           // fileText.setVisibility(View.VISIBLE);
//            uploadButton.setVisibility(View.VISIBLE);
        }
    }

    public boolean checkAndRequestPermission() {
        List<String> listPermission = new ArrayList<>();
        for (String perm : appPermission) {
            if (ContextCompat.checkSelfPermission( getActivity(), perm) != PackageManager.PERMISSION_GRANTED) {
                listPermission.add(perm);
            }
        }
        if (!listPermission.isEmpty()) {
            ActivityCompat.requestPermissions( getActivity(), listPermission.toArray(new String[listPermission.size()]), PERMISSION_REQUEST_CODE);
            return false;
        }
        return true;
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == PERMISSION_REQUEST_CODE) {
            HashMap<String, Integer> permissionResult = new HashMap<>();
            int deniedCount = 0;
            for (int i = 0; i < grantResults.length; i++) {
                if (grantResults[i] == PackageManager.PERMISSION_DENIED) {
                    permissionResult.put(permissions[i], grantResults[i]);
                    deniedCount++;
                }
            }
            if (deniedCount == 0) {
                selectImageMethod();
            } else {
                for (Map.Entry<String, Integer> entry : permissionResult.entrySet()) {
                    String permName = entry.getKey();
                    int permResult = entry.getValue();
                    if (ActivityCompat.shouldShowRequestPermissionRationale( getActivity(), permName)) {
                        showDialogPermission("", "This App needs Read External Storage permissions to work whithout and problems.",
                                "Yes, Grant permissions", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialogInterface, int i) {
                                        dialogInterface.dismiss();
                                        checkAndRequestPermission();
                                    }
                                },
                                "No, Exit app", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialogInterface, int i) {
                                        dialogInterface.dismiss();
                                        getActivity().finishAffinity();
                                    }
                                }, false);
                    } else {
                        showDialogPermission("", "You have denied some permissions. Allow all permissions at [Setting] > [Permissions]",
                                "Go to Settings", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialogInterface, int i) {
                                        dialogInterface.dismiss();
                                        Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                                                Uri.fromParts("package", getActivity().getPackageName(), null));
                                        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                                        startActivity(intent);
                                        getActivity().finish();
                                    }
                                }, "No, Exit app", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialogInterface, int i) {
                                        dialogInterface.dismiss();
                                        getActivity().finish();
                                    }
                                }, false);
                        break;
                    }
                }
            }
        }
    }

    public AlertDialog showDialogPermission(String title, String msg, String positiveLable, DialogInterface.OnClickListener positiveOnClickListener, String negativeLable, DialogInterface.OnClickListener negativeOnClickListener, boolean isCancelable) {
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        builder.setTitle(title);
        builder.setCancelable(isCancelable);
        builder.setMessage(msg);
        builder.setPositiveButton(positiveLable, positiveOnClickListener);
        builder.setNegativeButton(negativeLable, negativeOnClickListener);
        AlertDialog alertDialog = builder.create();
        alertDialog.show();
        return alertDialog;
    }



}