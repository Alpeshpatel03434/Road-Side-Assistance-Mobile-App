package com.brainybeam.roadsideassistance.RetrofitData;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.List;

public class UserLoginData {

    @SerializedName("Status")
    @Expose
    public String status;
    @SerializedName("Message")
    @Expose
    public String message;
    @SerializedName("response")
    @Expose
    public List<UserLoginResponse> response = null;

    public class UserLoginResponse {

        @SerializedName("UserID")
        @Expose
        public String userID;
        @SerializedName("UserType")
        @Expose
        public String userType;
        @SerializedName("FirstName")
        @Expose
        public String firstName;
        @SerializedName("LastName")
        @Expose
        public String lastName;
        @SerializedName("ProfileImage")
        @Expose
        public String profileImage;
        @SerializedName("MobileNumber")
        @Expose
        public String mobileNumber;
        @SerializedName("Email")
        @Expose
        public String email;
        @SerializedName("Password")
        @Expose
        public String password;
        @SerializedName("Account_Status")
        @Expose
        public String accountStatus;
        @SerializedName("FCMID")
        @Expose
        public String fcmid;
        @SerializedName("Created_time")
        @Expose
        public String createdTime;

    }

}
