package com.brainybeam.roadsideassistance.User.Activity;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.brainybeam.roadsideassistance.Login.LoginActivity;
import com.brainybeam.roadsideassistance.R;
import com.brainybeam.roadsideassistance.RetrofitData.DeleteUserORForemanData;
import com.brainybeam.roadsideassistance.User.DashBoard.UserDashboardActivity;
import com.brainybeam.roadsideassistance.Utils.ApiClient;
import com.brainybeam.roadsideassistance.Utils.ApiInterface;
import com.brainybeam.roadsideassistance.Utils.CommonMethod;
import com.brainybeam.roadsideassistance.Utils.SharedPreferencesData;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class UserEnableActivity extends AppCompatActivity {

    Button ActivateButton, LogoutButton;

    ApiInterface apiInterface;
    SharedPreferences sp;
    ProgressDialog pd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_enable);

        apiInterface = ApiClient.getClient().create(ApiInterface.class);
        sp = getSharedPreferences(SharedPreferencesData.PREF, MODE_PRIVATE);

        ActivateButton = findViewById(R.id.user_enable_activateButton);
        LogoutButton = findViewById(R.id.user_enable_LogoutButton);

        ActivateButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                pd = new ProgressDialog(UserEnableActivity.this);
                pd.setTitle("Processing...");
                pd.setCancelable(false);
                pd.show();
                Activate();
            }
        });

        LogoutButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                sp.edit().clear().commit();
                startActivity(new Intent(UserEnableActivity.this, LoginActivity.class).setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP));
            }
        });

    }

    private void Activate() {

        Call<DeleteUserORForemanData> call = apiInterface.ActivateUserData(
                sp.getString(SharedPreferencesData.UserID, "")
        );

        call.enqueue(new Callback<DeleteUserORForemanData>() {
            @Override
            public void onResponse(Call<DeleteUserORForemanData> call, Response<DeleteUserORForemanData> response) {

                pd.dismiss();
                if(response.code()==200){

                    if(response.body().status==true){
                        new CommonMethod(UserEnableActivity.this, "Your Account has been Activated");
                        new CommonMethod(UserEnableActivity.this, LoginActivity.class);
                        finish();
                    } else {
                        new CommonMethod(UserEnableActivity.this, "UnSuccessFull");
                        new CommonMethod(UserEnableActivity.this, "Please Try Again");
                    }

                } else {
                    new CommonMethod(UserEnableActivity.this, "Server Error Code : "+response.code());
                }

            }

            @Override
            public void onFailure(Call<DeleteUserORForemanData> call, Throwable t) {
                pd.dismiss();
                new CommonMethod(UserEnableActivity.this, t.getMessage());
            }
        });

    }

}