package com.brainybeam.roadsideassistance.OTPVerification;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.location.Address;
import android.location.Geocoder;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.brainybeam.roadsideassistance.Login.LoginActivity;
import com.brainybeam.roadsideassistance.R;
import com.brainybeam.roadsideassistance.RetrofitData.AddForemanServicesData;
import com.brainybeam.roadsideassistance.RetrofitData.ForemanSignupData;
import com.brainybeam.roadsideassistance.RetrofitData.LocationData;
import com.brainybeam.roadsideassistance.RetrofitData.UserSignupData;
import com.brainybeam.roadsideassistance.Utils.ApiClient;
import com.brainybeam.roadsideassistance.Utils.ApiInterface;
import com.brainybeam.roadsideassistance.Utils.CommonMethod;
import com.brainybeam.roadsideassistance.Utils.ConnectionDetector;
import com.brainybeam.roadsideassistance.Utils.SharedPreferencesData;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseApp;
import com.google.firebase.FirebaseException;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.PhoneAuthCredential;
import com.google.firebase.auth.PhoneAuthOptions;
import com.google.firebase.auth.PhoneAuthProvider;

import org.jetbrains.annotations.NotNull;

import java.io.IOException;
import java.util.List;
import java.util.concurrent.TimeUnit;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class OTPVerificationActivity extends AppCompatActivity {

    //Mobile
    LinearLayout Mobile_linearlayout;
    TextView MobileNumberView;
    EditText Mobile_OTP1, Mobile_OTP2, Mobile_OTP3, Mobile_OTP4, Mobile_OTP5, Mobile_OTP6;
    TextView Mobile_OTP_ResendButton;
    Button Mobile_OTP_Verify;

    //Email
    LinearLayout Email_linearlayout;
    TextView EmailView;
    EditText Email_OTP1, Email_OTP2, Email_OTP3, Email_OTP4, Email_OTP5, Email_OTP6;
    TextView Email_OTP_ResendButton;
    Button Email_OTP_Verify;

    ProgressDialog pd;

    FirebaseAuth mAuth;
    FirebaseApp firebaseApp;
    private PhoneAuthProvider.OnVerificationStateChangedCallbacks mCallbacks;
    private String MobileNumber, Mobile_VerificationID;
    private SharedPreferences sp;
    ApiInterface apiInterface;
    
    String sMail, sPassword;
    int count=0;

    double DriverLatitude, DriverLongitude;
    String sFullAddress, sForemanLatitude, sForemanLongitude;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_otpverification);

        firebaseApp = FirebaseApp.initializeApp(getApplicationContext());
        mAuth = FirebaseAuth.getInstance();
        sp = getSharedPreferences(SharedPreferencesData.PREF, MODE_PRIVATE);
        apiInterface = ApiClient.getClient().create(ApiInterface.class);


        Bundle bundle = getIntent().getExtras();

        // TODO Mobile Number
        Mobile_linearlayout = findViewById(R.id.MobileOTP_linearlayout);
        MobileNumberView = findViewById(R.id.MobileNumberView);
        Mobile_OTP1 = findViewById(R.id.Mobile_otp1);
        Mobile_OTP2 = findViewById(R.id.Mobile_otp2);
        Mobile_OTP3 = findViewById(R.id.Mobile_otp3);
        Mobile_OTP4 = findViewById(R.id.Mobile_otp4);
        Mobile_OTP5 = findViewById(R.id.Mobile_otp5);
        Mobile_OTP6 = findViewById(R.id.Mobile_otp6);
        Mobile_OTP_ResendButton = findViewById(R.id.Mobile_Resend_OTP_TextButton);
        Mobile_OTP_Verify = findViewById(R.id.Mobile_OTP_Verify_VerifyButton);

        String sMobileNumber = "+91"+bundle.getString("PhoneNumber");
        MobileNumberView.setText(sMobileNumber);
        Mobile_VerificationID = bundle.getString("Mobile_VerificationID");

        // TODO Email
        Email_linearlayout = findViewById(R.id.EmailOTP_linearlayout);
        EmailView = findViewById(R.id.EmailView);

        Email_OTP_ResendButton = findViewById(R.id.Email_Resend_OTP_TextButton);
        Email_OTP_Verify = findViewById(R.id.Email_OTP_Verify_VerifyButton);

        // TODO To Sending OTP in Mobile Number
        Mobile_InputOTPInEditTextField();

        Mobile_OTP_ResendButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                new CommonMethod(OTPVerificationActivity.this, "OTP Send SuccessFully");
                otpSendToMobile(bundle.getString("PhoneNumber"));
            }
        });

        Mobile_OTP_Verify.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if(new ConnectionDetector(OTPVerificationActivity.this).isConnectingToInternet()){


                    pd = new ProgressDialog(OTPVerificationActivity.this);
                    pd.setMessage("Please Wait...");
                    pd.setCancelable(false);
                    pd.show();

                    count = count+1;
                    Mobile_linearlayout.setVisibility(View.GONE);

                    // TODO Mobile OTP Verify
                    MobileOTP_Velidity_Check();

                    if(count==2){
                        FullyVerify();
                    }


                } else {
                    new ConnectionDetector(OTPVerificationActivity.this).connectiondetect();
                }

            }
        });



        // TODO To Sending OTP in Email
        sMail = sp.getString(SharedPreferencesData.Email, "");
        EmailView.setText(sMail);
        sPassword = sp.getString(SharedPreferencesData.Password, "");

        // TODO Email OTP Send
         otpSendToEmail(sMail);


        Email_OTP_Verify.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if(new ConnectionDetector(OTPVerificationActivity.this).isConnectingToInternet()){

                    count = count+1;

                    EmailVerify();

                   if(count==2){
                       FullyVerify();
                   }

                } else {
                    new ConnectionDetector(OTPVerificationActivity.this).connectiondetect();
                }
            }
        });



    }

    private void FullyVerify() {

        pd = new ProgressDialog(OTPVerificationActivity.this);
        pd.setTitle("Please Wait...");
        pd.setCancelable(false);
        pd.show();

        if(sp.getString(SharedPreferencesData.UserType, "").equalsIgnoreCase("User")){

            Call<UserSignupData> call = apiInterface.UserSignupData(

                    sp.getString(SharedPreferencesData.UserType, ""),
                    sp.getString(SharedPreferencesData.FirstName, ""),
                    sp.getString(SharedPreferencesData.LastName, ""),
                    sp.getString(SharedPreferencesData.MobileNumber, ""),
                    sp.getString(SharedPreferencesData.Email, ""),
                    sp.getString(SharedPreferencesData.Password, ""),
                    sp.getString(SharedPreferencesData.Account_Status, "Verified")

            );

            call.enqueue(new Callback<UserSignupData>() {
                @Override
                public void onResponse(Call<UserSignupData> call, Response<UserSignupData> response) {
                    pd.dismiss();
                    if (response.code()==200){

                        if(response.body().status==true){

                            new CommonMethod(OTPVerificationActivity.this, response.body().message);
                            new CommonMethod(OTPVerificationActivity.this, LoginActivity.class);
                            finish();

                        } else {
                            new CommonMethod(OTPVerificationActivity.this, response.body().message);
                        }

                    } else {
                        new CommonMethod(OTPVerificationActivity.this, "Server Error Code : "+response.code());
                    }

                }

                @Override
                public void onFailure(Call<UserSignupData> call, Throwable t) {
                    pd.dismiss();
                    new CommonMethod(OTPVerificationActivity.this, t.getMessage());
                }
            });

        } else if(sp.getString(SharedPreferencesData.UserType, "").equalsIgnoreCase("Foreman")){

            Call<ForemanSignupData> call = apiInterface.ForemanSignupData(

                    sp.getString(SharedPreferencesData.UserType, ""),
                    sp.getString(SharedPreferencesData.FirstName, ""),
                    sp.getString(SharedPreferencesData.LastName, ""),
                    sp.getString(SharedPreferencesData.MobileNumber, ""),
                    sp.getString(SharedPreferencesData.Email, ""),
                    sp.getString(SharedPreferencesData.Password, ""),
                    sp.getString(SharedPreferencesData.ForemanAddress, ""),
                    sp.getString(SharedPreferencesData.ForemanArea, ""),
                    sp.getString(SharedPreferencesData.ForemanCity, ""),
                    sp.getString(SharedPreferencesData.ForemanState, ""),
                    sp.getString(SharedPreferencesData.Account_Status, "Verified")
                    
            );

            call.enqueue(new Callback<ForemanSignupData>() {
                @Override
                public void onResponse(Call<ForemanSignupData> call, Response<ForemanSignupData> response) {
                    pd.dismiss();
                    if (response.code()==200){

                        if(response.body().status==true){

                            new CommonMethod(OTPVerificationActivity.this, response.body().message);
                            AddSPProfileLocationData();
                            new CommonMethod(OTPVerificationActivity.this, LoginActivity.class);
                            finish();

                        } else {
                            new CommonMethod(OTPVerificationActivity.this, response.body().message);
                        }

                    } else {
                        new CommonMethod(OTPVerificationActivity.this, "Server Error Code : "+response.code());
                    }

                }

                @Override
                public void onFailure(Call<ForemanSignupData> call, Throwable t) {
                    pd.dismiss();
                    new CommonMethod(OTPVerificationActivity.this, t.getMessage());
                }
            });

        } else {
            pd.dismiss();
            new CommonMethod(OTPVerificationActivity.this, "Not Valid Try Again");
        }

    }


    private void AddSPProfileLocationData() {

        String FullAddress = sp.getString(SharedPreferencesData.ForemanAddress, "")+","+sp.getString(SharedPreferencesData.ForemanArea, "")+","+sp.getString(SharedPreferencesData.ForemanCity, "")+","+sp.getString(SharedPreferencesData.ForemanState, "");
        Geocoder coder = new Geocoder(OTPVerificationActivity.this);
        List<Address> address;
        try {
            // May throw an IOException
            address = coder.getFromLocationName(FullAddress, 5);
            if (address == null) {
                DriverLatitude = 0.00;
                DriverLongitude = 0.00;
            }
            Address location = address.get(0);

            DriverLatitude = location.getLatitude();
            DriverLongitude = location.getLongitude();
            //p1 = new LatLng(location.getLatitude(), location.getLongitude() );

        } catch (IOException ex) {

            ex.printStackTrace();
        }


        sForemanLatitude = String.valueOf(DriverLatitude);
        sForemanLongitude = String.valueOf(DriverLongitude);

        Call<LocationData> call = apiInterface.AddSPProfileLocationData(
                sp.getString(SharedPreferencesData.UserID, ""),
                sForemanLatitude,
                sForemanLongitude
        );

        call.enqueue(new Callback<LocationData>() {
            @Override
            public void onResponse(Call<LocationData> call, Response<LocationData> response) {

                if(response.code()==200){

                    if(response.body().status==true){

                    } else {
                        new CommonMethod(OTPVerificationActivity.this, response.body().message);
                    }

                } else {
                    new CommonMethod(OTPVerificationActivity.this, "Server Error Code "+response.code());
                }

            }

            @Override
            public void onFailure(Call<LocationData> call, Throwable t) {
                new CommonMethod(OTPVerificationActivity.this, t.getMessage());
            }
        });

    }


    private void Mobile_InputOTPInEditTextField() {
        Mobile_OTP1.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                Mobile_OTP2.requestFocus();
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
        Mobile_OTP2.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                Mobile_OTP3.requestFocus();
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
        Mobile_OTP3.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                Mobile_OTP4.requestFocus();
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
        Mobile_OTP4.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                Mobile_OTP5.requestFocus();
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
        Mobile_OTP5.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                Mobile_OTP6.requestFocus();
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
    }

    private void MobileOTP_Velidity_Check() {

        if (Mobile_OTP1.getText().toString().trim().isEmpty() ||
                Mobile_OTP2.getText().toString().trim().isEmpty() ||
                Mobile_OTP3.getText().toString().trim().isEmpty() ||
                Mobile_OTP4.getText().toString().trim().isEmpty() ||
                Mobile_OTP5.getText().toString().trim().isEmpty() ||
                Mobile_OTP6.getText().toString().trim().isEmpty()) {

            pd.dismiss();
            new CommonMethod(OTPVerificationActivity.this, "Mobile_OTP is not Valid!");

        } else {
            pd.dismiss();
            if (Mobile_VerificationID != null) {
                String code = Mobile_OTP1.getText().toString().trim() +
                        Mobile_OTP2.getText().toString().trim() +
                        Mobile_OTP3.getText().toString().trim() +
                        Mobile_OTP4.getText().toString().trim() +
                        Mobile_OTP5.getText().toString().trim() +
                        Mobile_OTP6.getText().toString().trim();

                PhoneAuthCredential credential = PhoneAuthProvider.getCredential(Mobile_VerificationID, code);
                FirebaseAuth
                        .getInstance()
                        .signInWithCredential(credential)
                        .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                            @Override
                            public void onComplete(@NonNull @NotNull Task<AuthResult> task) {
                                if (task.isSuccessful()) {

                                    new CommonMethod(OTPVerificationActivity.this, "Congratulation SuccessFully Partially Verify");
                                    new CommonMethod(OTPVerificationActivity.this, "Mobile Number Verified");

                                    Mobile_linearlayout.setVisibility(View.GONE);

                                } else {
                                    new CommonMethod(OTPVerificationActivity.this, "OTP is not Valid!");
                                }
                            }
                        });
            }
        }

    }


    private void otpSendToEmail(String sMail) {

        mAuth.createUserWithEmailAndPassword(sMail, sPassword).addOnCompleteListener(OTPVerificationActivity.this, new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {

                if (task.isSuccessful()) {
                    // TODO Sign in success, update UI with the signed-in user's information
                    FirebaseUser user = mAuth.getCurrentUser();

                    try {
                        if (user != null)
                            user.sendEmailVerification()
                                    .addOnCompleteListener(new OnCompleteListener<Void>() {
                                        @Override
                                        public void onComplete(@NonNull Task<Void> task) {
                                            if (task.isSuccessful()) {

                                                AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(
                                                        OTPVerificationActivity.this);

                                                // set title
                                                alertDialogBuilder.setTitle("Please Verify Your EmailID");

                                                // set dialog message
                                                alertDialogBuilder
                                                        .setMessage("A verification Email Is Sent To Your Registered EmailID, please click on the link and Sign in again!")
                                                        .setCancelable(false)
                                                        .setPositiveButton("Sign In", new DialogInterface.OnClickListener() {
                                                            public void onClick(DialogInterface dialog, int id) {

                                                            }
                                                        });

                                                // create alert dialog
                                                AlertDialog alertDialog = alertDialogBuilder.create();

                                                // show it
                                                alertDialog.show();

                                            }
                                        }
                                    });


                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                } else {
                    // TODO If sign in fails, display a message to the user.
                    new CommonMethod(OTPVerificationActivity.this, "Authentication failed");

                    if (task.getException() != null) {
                        new CommonMethod(OTPVerificationActivity.this, task.getException().getMessage());
                    }

                }

            }
        });



    }

    public void EmailVerify(){
        FirebaseUser user = mAuth.getCurrentUser();

        if (user != null) {
            // TODO User is signed in
            new CommonMethod(OTPVerificationActivity.this, "Email is Verified");
            Email_linearlayout.setVisibility(View.GONE);
        } else {
            // TODO No user is signed in
            new CommonMethod(OTPVerificationActivity.this, "Email is Not Verified");
        }

    }


    private void otpSendToMobile(String sPhone) {

        mCallbacks = new PhoneAuthProvider.OnVerificationStateChangedCallbacks() {

            @Override
            public void onVerificationCompleted(PhoneAuthCredential credential) {

            }

            @Override
            public void onVerificationFailed(FirebaseException e) {
                pd.dismiss();
                new CommonMethod(OTPVerificationActivity.this, e.getLocalizedMessage());
            }

            @Override
            public void onCodeSent(@NonNull String VerificationId,
                                   @NonNull PhoneAuthProvider.ForceResendingToken token) {
                pd.dismiss();

                new CommonMethod(OTPVerificationActivity.this, "OTP is successFully Send");

            }
        };

        PhoneAuthOptions options =
                PhoneAuthOptions.newBuilder(mAuth)
                        .setPhoneNumber("+91" + sPhone.trim())
                        .setTimeout(60L, TimeUnit.SECONDS)
                        .setActivity(this)
                        .setCallbacks(mCallbacks)
                        .build();
        PhoneAuthProvider.verifyPhoneNumber(options);

    }



}