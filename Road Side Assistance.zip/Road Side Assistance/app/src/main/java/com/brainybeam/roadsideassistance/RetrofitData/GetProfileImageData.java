package com.brainybeam.roadsideassistance.RetrofitData;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.List;

public class GetProfileImageData {

    @SerializedName("Status")
    @Expose
    public Boolean status;
    @SerializedName("Message")
    @Expose
    public String message;
    @SerializedName("response")
    @Expose
    public List<GetProfileImageResponse> response = null;

    public class GetProfileImageResponse {
        @SerializedName("ProfileImage")
        @Expose
        public String profileImage;
    }

}
