package com.brainybeam.roadsideassistance.Foreman.DashBoard;

import android.Manifest;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationManager;
import android.os.Bundle;

import androidx.core.app.ActivityCompat;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.provider.Settings;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.brainybeam.roadsideassistance.Foreman.CustomArrayList.ForemanUserSelectedServicesList;
import com.brainybeam.roadsideassistance.GPS.GPSTracker;
import com.brainybeam.roadsideassistance.R;
import com.brainybeam.roadsideassistance.RetrofitData.GetForemanUserSelectedServicesData;
import com.brainybeam.roadsideassistance.User.Activity.UserForemanServicesActivity;
import com.brainybeam.roadsideassistance.User.Activity.UserVehicleSelectionActivity;
import com.brainybeam.roadsideassistance.User.CustomArrayList.UserForemanServiceList;
import com.brainybeam.roadsideassistance.User.DashBoard.UserVehicleDetailAdapter;
import com.brainybeam.roadsideassistance.Utils.ApiClient;
import com.brainybeam.roadsideassistance.Utils.ApiInterface;
import com.brainybeam.roadsideassistance.Utils.CommonMethod;
import com.brainybeam.roadsideassistance.Utils.ConnectionDetector;
import com.brainybeam.roadsideassistance.Utils.SharedPreferencesData;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


public class NewUserRequestReceiveFragment extends Fragment {

    RecyclerView recyclerView;

    ArrayList<ForemanUserSelectedServicesList> arrayList;

    ApiInterface apiInterface;
    SharedPreferences sp;
    ProgressDialog pd;

    GPSTracker gpsTracker;
    double CurrentLatitude, CurrentLongitude;

    String sForemanAddress, sForemanLatitude, sForemanLongitude;

    private static final int REQUEST_LOCATION = 1;
    LocationManager locationManager;

    public NewUserRequestReceiveFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_new_user_request_receive, container, false);

        apiInterface = ApiClient.getClient().create(ApiInterface.class);
        sp = getActivity().getSharedPreferences(SharedPreferencesData.PREF, Context.MODE_PRIVATE);

        recyclerView = view.findViewById(R.id.frag_foreman_newUser_requestReceive_recyclerview);

        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        recyclerView.setItemAnimator(new DefaultItemAnimator());

        locationManager = (LocationManager) getActivity().getSystemService(Context.LOCATION_SERVICE);
        if (!locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
            OnGPS();
        } else {
            getLocation();
        }
//        GPSTracker gpsTracker = new GPSTracker(getActivity());
//
        Geocoder geocoder = new Geocoder(getActivity(), Locale.getDefault());
        List<Address> addresses = null;
        try {
            addresses = geocoder.getFromLocation(CurrentLatitude, CurrentLongitude, 1);
            String add = addresses.toString();
//            String city = addresses.get(0).getLocality();
//            String state = addresses.get(0).getAdminArea();
//            String zip = addresses.get(0).getPostalCode();
//            String country = addresses.get(0).getCountryName();

//            CurrentLatitude = gpsTracker.getLatitude();
//            CurrentLongitude = gpsTracker.getLongitude();
            sForemanAddress = add;
        } catch (IOException e) {
            e.printStackTrace();
        }

        sp.edit().putString(SharedPreferencesData.Foreman_ForemanCurrLocation, sForemanAddress).commit();

        if(new ConnectionDetector(getActivity()).isConnectingToInternet()){

            pd = new ProgressDialog(getActivity());
            pd.setMessage("Please Wait...");
            pd.setCancelable(false);
            pd.show();

            recyclerViewDataSetMethod();

        } else {
            new ConnectionDetector(getActivity()).connectiondetect();
        }

        return view;
    }

    private void OnGPS() {
        final AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        builder.setMessage("Enable GPS").setCancelable(false).setPositiveButton("Yes", new  DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                startActivity(new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS));
            }
        }).setNegativeButton("No", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });
        final AlertDialog alertDialog = builder.create();
        alertDialog.show();
    }

    private void getLocation() {
        if (ActivityCompat.checkSelfPermission(
                getActivity(), Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(
                getActivity(), Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(getActivity(), new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, REQUEST_LOCATION);
        } else {
            Location locationGPS = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
            if (locationGPS != null) {
                double lat = locationGPS.getLatitude();
                double longi = locationGPS.getLongitude();
                CurrentLatitude = lat;
                CurrentLongitude = longi;
            } else {
                new CommonMethod(getActivity(), "Not Found");
            }
        }
    }

    private void recyclerViewDataSetMethod() {

        Call<GetForemanUserSelectedServicesData> call = apiInterface.GetForemanUserSelectedServicesData(
                sp.getString(SharedPreferencesData.UserID, "")
        );

        call.enqueue(new Callback<GetForemanUserSelectedServicesData>() {
            @Override
            public void onResponse(Call<GetForemanUserSelectedServicesData> call, Response<GetForemanUserSelectedServicesData> response) {

                pd.dismiss();
                if(response.code()==200){

                    if(response.body().status==true){

                        new CommonMethod(getActivity(), response.body().message);

                        arrayList = new ArrayList<>();
                        GetForemanUserSelectedServicesData data = response.body();

                        for(int i=0; i<data.response.size(); i++){
                            ForemanUserSelectedServicesList list = new ForemanUserSelectedServicesList();

                            list.setCartID(data.response.get(i).cartID);
                            list.setServiceID(data.response.get(i).serviceID);
                            list.setForemanID(data.response.get(i).foremanID);
                            list.setUserID(data.response.get(i).userID);
                            list.setVehicleID(data.response.get(i).vehicleID);
                            list.setProblemDescriptionMessage(data.response.get(i).problemDescriptionMessage+"");
                            list.setSPReqMoney(data.response.get(i).sPReqMoney);
                            list.setUserLocation(data.response.get(i).userLocation);
                            list.setPaymentStatus(data.response.get(i).paymentStatus);
                            list.setTypeOfProblem(data.response.get(i).typeOfProblem);
                            list.setProblemSubType(data.response.get(i).problemSubType);
                            list.setServiceFixedCharge(data.response.get(i).serviceFixedCharge);
                            list.setUserFirstName(data.response.get(i).firstName);
                            list.setUserLastName(data.response.get(i).lastName);
                            list.setUserProfileImage(data.response.get(i).profileImage);
                            list.setUserMobileNumber(data.response.get(i).mobileNumber);
                            list.setNumberPlate_number(data.response.get(i).numberPlateNumber);
                            list.setTypeOfVehicle(data.response.get(i).typeOfVehicle);
                            list.setVehicleModelName(data.response.get(i).vehicleModelName);
                            list.setVehicle_Colour(data.response.get(i).vehicleColour);

                            arrayList.add(list);
                        }

                        ForemanUserSelectedServicesAdapter adapter = new ForemanUserSelectedServicesAdapter(getActivity(), arrayList);
                        recyclerView.setAdapter(adapter);
                        adapter.notifyDataSetChanged();

                    } else {
                        new CommonMethod(getActivity(), response.body().message);
                    }

                } else {
                    new CommonMethod(getActivity(), "Server Error Code : "+response.code());
                }

            }

            @Override
            public void onFailure(Call<GetForemanUserSelectedServicesData> call, Throwable t) {

                pd.dismiss();
                new CommonMethod(getActivity(), t.getMessage());

            }
        });

    }
}