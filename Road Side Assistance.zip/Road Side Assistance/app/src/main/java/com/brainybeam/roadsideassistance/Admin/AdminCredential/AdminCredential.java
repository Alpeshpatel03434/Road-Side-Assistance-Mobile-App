package com.brainybeam.roadsideassistance.Admin.AdminCredential;

public class AdminCredential {

    public static final String AdminEmail[] = {

            "Admin@gmail.com",
            "Admin123@gmail.com",
            "alpesh@gmail.com",
            "alpeshpatel@gmail.com",
            "Admin",
            "roadside@assistan",

            "admin@gmail.com",
            "admin123@gmail.com",
            "Alpesh@gmail.com",
            "Alpeshpatel@gmail.com",
            "admin",
            "Roadside@assistan"

    };

    public static final String AdminPassword[] = {
            "alpesh@gmail.com",
            "alpeshpatel@gmail.com",
            "roadside@assistan",
            "01011010",
            "00001111",
            "11110000"
    };

}
