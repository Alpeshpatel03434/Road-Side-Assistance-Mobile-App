package com.brainybeam.roadsideassistance.User.Activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.MenuItem;

import com.brainybeam.roadsideassistance.R;
import com.brainybeam.roadsideassistance.RetrofitData.GetUserVehicleData;
import com.brainybeam.roadsideassistance.User.CustomArrayList.UserVehicleList;
import com.brainybeam.roadsideassistance.User.DashBoard.UserVehicleDetailAdapter;
import com.brainybeam.roadsideassistance.Utils.ApiClient;
import com.brainybeam.roadsideassistance.Utils.ApiInterface;
import com.brainybeam.roadsideassistance.Utils.CommonMethod;
import com.brainybeam.roadsideassistance.Utils.ConnectionDetector;
import com.brainybeam.roadsideassistance.Utils.SharedPreferencesData;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class UserVehicleSelectionActivity extends AppCompatActivity {

    RecyclerView recyclerView;
    
    ArrayList<UserVehicleList> arrayList;
    
    ApiInterface apiInterface;
    SharedPreferences sp;
    ProgressDialog pd;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_vehicle_selection);
        getSupportActionBar().setTitle("Select Vehicle");
        ColorDrawable colorDrawable
                = new ColorDrawable(Color.parseColor("#2196F3"));
        getSupportActionBar().setBackgroundDrawable(colorDrawable);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);


        apiInterface = ApiClient.getClient().create(ApiInterface.class);
        sp = getSharedPreferences(SharedPreferencesData.PREF, Context.MODE_PRIVATE);

        recyclerView = findViewById(R.id.user_vehicle_selection_recyclerview);

        recyclerView.setLayoutManager(new LinearLayoutManager(UserVehicleSelectionActivity.this));
        recyclerView.setItemAnimator(new DefaultItemAnimator());

        if(new ConnectionDetector(UserVehicleSelectionActivity.this).isConnectingToInternet()){
            
            pd = new ProgressDialog(UserVehicleSelectionActivity.this);
            pd.setMessage("Please Wait...");
            pd.setCancelable(false);
            pd.show();
            
            recyclerViewDataSetMethod();

        } else {
            new ConnectionDetector(UserVehicleSelectionActivity.this).connectiondetect();
        }
        
    }

    private void recyclerViewDataSetMethod() {

        Call<GetUserVehicleData> call = apiInterface.GetUserVehicleData(
                sp.getString(SharedPreferencesData.UserID, "")
        );

        call.enqueue(new Callback<GetUserVehicleData>() {
            @Override
            public void onResponse(Call<GetUserVehicleData> call, Response<GetUserVehicleData> response) {
                pd.dismiss();
                if(response.code()==200){

                    if(response.body().status==true){
                        new CommonMethod(UserVehicleSelectionActivity.this, response.body().message);

                        arrayList = new ArrayList<>();
                        GetUserVehicleData data = response.body();
                        for(int i=0; i<data.response.size(); i++){
                            UserVehicleList list = new UserVehicleList();

                            list.setVehicleID(data.response.get(i).vehicleID);
                            list.setUserID(data.response.get(i).userID);
                            list.setNumberPlate_number(data.response.get(i).numberPlateNumber);
                            list.setTypeOfVehicle(data.response.get(i).typeOfVehicle);
                            list.setVehicleModelName(data.response.get(i).vehicleModelName);
                            list.setVehicle_Colour(data.response.get(i).vehicleColour);

                            arrayList.add(list);
                        }

                        UserVehicleSelectionAdapter adapter = new UserVehicleSelectionAdapter(UserVehicleSelectionActivity.this, arrayList, apiInterface, sp);
                        recyclerView.setAdapter(adapter);

                    } else {
                        new CommonMethod(UserVehicleSelectionActivity.this, response.body().message);
                    }

                } else {
                    new CommonMethod(UserVehicleSelectionActivity.this, "Server Error Code "+response.code());
                }

            }

            @Override
            public void onFailure(Call<GetUserVehicleData> call, Throwable t) {
                pd.dismiss();
                new CommonMethod(UserVehicleSelectionActivity.this, t.getMessage());
            }
        });


    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();
        if (id == android.R.id.home) {
            onBackPressed();
        }
        return super.onOptionsItemSelected(item);
    }

}