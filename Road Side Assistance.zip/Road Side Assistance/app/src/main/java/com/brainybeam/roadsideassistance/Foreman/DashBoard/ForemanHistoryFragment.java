package com.brainybeam.roadsideassistance.Foreman.DashBoard;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.brainybeam.roadsideassistance.Foreman.CustomArrayList.ForemanHistoryList;
import com.brainybeam.roadsideassistance.Foreman.CustomArrayList.ServiceListData;
import com.brainybeam.roadsideassistance.R;
import com.brainybeam.roadsideassistance.RetrofitData.GetForemanHistoryData;
import com.brainybeam.roadsideassistance.RetrofitData.GetForemanServicesData;
import com.brainybeam.roadsideassistance.RetrofitData.GetHistoryData;
import com.brainybeam.roadsideassistance.Utils.ApiClient;
import com.brainybeam.roadsideassistance.Utils.ApiInterface;
import com.brainybeam.roadsideassistance.Utils.CommonMethod;
import com.brainybeam.roadsideassistance.Utils.ConnectionDetector;
import com.brainybeam.roadsideassistance.Utils.SharedPreferencesData;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


public class ForemanHistoryFragment extends Fragment {

    RecyclerView recyclerView;
    ArrayList<ForemanHistoryList> arrayList;

    ApiInterface apiInterface;
    SharedPreferences sp;
    ProgressDialog pd;

    public ForemanHistoryFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_foreman_history, container, false);

        apiInterface = ApiClient.getClient().create(ApiInterface.class);
        sp = getActivity().getSharedPreferences(SharedPreferencesData.PREF, Context.MODE_PRIVATE);


        recyclerView = view.findViewById(R.id.frag_foreman_history_recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        recyclerView.setItemAnimator(new DefaultItemAnimator());

        if(new ConnectionDetector(getActivity()).isConnectingToInternet()){
            pd = new ProgressDialog(getActivity());
            pd.setMessage("Please Wait...");
            pd.setCancelable(false);
            pd.show();
            recyclerViewDataSetMethod();

        } else {
            new ConnectionDetector(getActivity()).connectiondetect();
        }

        return view;
    }

    private void recyclerViewDataSetMethod() {

        Call<GetForemanHistoryData> call = apiInterface.GetForemanHistoryData(
                sp.getString(SharedPreferencesData.UserID, "")
        );

        call.enqueue(new Callback<GetForemanHistoryData>() {
            @Override
            public void onResponse(Call<GetForemanHistoryData> call, Response<GetForemanHistoryData> response) {

                pd.dismiss();
                if (response.code()==200) {
                    if (response.body().status == true) {
                        // new CommonMethod(getActivity(), response.body().message);

                        arrayList = new ArrayList<>();
                        GetForemanHistoryData data = response.body();

                        for(int i=0; i<data.response.size(); i++){

                            ForemanHistoryList list = new ForemanHistoryList();

                            list.setHistoryID(data.response.get(i).historyID);
                            list.setServiceID(data.response.get(i).serviceID);
                            list.setForemanID(data.response.get(i).foremanID);
                            list.setUserID(data.response.get(i).userID);
                            list.setVehicleID(data.response.get(i).vehicleID);
                            list.setProblemDescriptionMessage(data.response.get(i).problemDescriptionMessage);
                            list.setPaymentID(data.response.get(i).paymentID);
                            list.setSPReqMoney(data.response.get(i).sPReqMoney);
                            list.setPaymentMode(data.response.get(i).paymentMode);
                            list.setPayment(data.response.get(i).payment);
                            list.setUserLocation(data.response.get(i).userLocation);
                            list.setPaymentDate(data.response.get(i).paymentDate);
                            list.setUserFirstName(data.response.get(i).firstName);
                            list.setUserLastName(data.response.get(i).lastName);
                            list.setUserProfileImage(data.response.get(i).profileImage);
                            list.setUserMobileNumber(data.response.get(i).mobileNumber);
                            list.setTypeOfProblem(data.response.get(i).typeOfProblem);
                            list.setProblemSubType(data.response.get(i).problemSubType);
                            list.setServiceFixedCharge(data.response.get(i).serviceFixedCharge);
                            list.setVehicleNumber(data.response.get(i).numberPlateNumber);
                            list.setTypeOfVehicle(data.response.get(i).typeOfVehicle);
                            list.setVehicleModelName(data.response.get(i).vehicleModelName);
                            list.setVehicleColor(data.response.get(i).vehicleColour);

                            arrayList.add(list);
                        }

                        ForemanHistoryAdapter adapter = new ForemanHistoryAdapter(getActivity(), arrayList);
                        recyclerView.setAdapter(adapter);
                        adapter.notifyDataSetChanged();

                    } else {
                        new CommonMethod(getActivity(), response.body().message);
                        new CommonMethod(getActivity(), "You don't have History");
                    }
                } else {
                    new CommonMethod(getActivity(), "Server Error Code : "+response.code());
                }

            }

            @Override
            public void onFailure(Call<GetForemanHistoryData> call, Throwable t) {
                pd.dismiss();
                new CommonMethod(getActivity(), t.getMessage());
            }
        });

    }
}