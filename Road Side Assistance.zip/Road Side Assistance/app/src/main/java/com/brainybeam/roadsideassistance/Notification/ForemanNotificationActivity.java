package com.brainybeam.roadsideassistance.Notification;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.ProgressDialog;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;

import com.brainybeam.roadsideassistance.R;
import com.brainybeam.roadsideassistance.RetrofitData.GetNotificationData;
import com.brainybeam.roadsideassistance.Utils.ApiClient;
import com.brainybeam.roadsideassistance.Utils.ApiInterface;
import com.brainybeam.roadsideassistance.Utils.CommonMethod;
import com.brainybeam.roadsideassistance.Utils.ConnectionDetector;
import com.brainybeam.roadsideassistance.Utils.SharedPreferencesData;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ForemanNotificationActivity extends AppCompatActivity {

    SharedPreferences sp;
    ApiInterface apiInterface;

    RecyclerView recyclerView;
    ArrayList<NotificationList> arrayList;

    ProgressDialog pd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_foreman_notification);
        getSupportActionBar().setTitle("Notification");
        ColorDrawable colorDrawable
                = new ColorDrawable(Color.parseColor("#2196F3"));
        getSupportActionBar().setBackgroundDrawable(colorDrawable);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        apiInterface = ApiClient.getClient().create(ApiInterface.class);
        sp = getSharedPreferences(SharedPreferencesData.PREF, MODE_PRIVATE);


        recyclerView = findViewById(R.id.foreman_notification_recyclerview);
        recyclerView.setLayoutManager(new LinearLayoutManager(ForemanNotificationActivity.this));
        recyclerView.setItemAnimator(new DefaultItemAnimator());

        if(new ConnectionDetector(ForemanNotificationActivity.this).isConnectingToInternet()){
            pd = new ProgressDialog(ForemanNotificationActivity.this);
            pd.setMessage("Please Wait...");
            pd.setCancelable(false);
            pd.show();
            getNotification();
        }
        else{
            new ConnectionDetector(ForemanNotificationActivity.this).connectiondetect();
        }

    }

    private void getNotification() {

        Call<GetNotificationData> call = apiInterface.GetForemanNotificationData(
                "Foreman",
                sp.getString(SharedPreferencesData.UserID, "")
        );

        call.enqueue(new Callback<GetNotificationData>() {
            @Override
            public void onResponse(Call<GetNotificationData> call, Response<GetNotificationData> response) {

                pd.dismiss();
                if(response.code()==200){
                    if(response.body().status==true){
                        // new CommonMethod(ForemanNotificationActivity.this, response.body().message);

                        GetNotificationData data = response.body();
                        arrayList = new ArrayList<>();
                        for(int i=0; i<data.response.size(); i++){

                            NotificationList list = new NotificationList();

                            list.setNotificationID(data.response.get(i).notificationID);
                            list.setTitle(data.response.get(i).title);
                            list.setMessage(data.response.get(i).message);
                            list.setMStatus(data.response.get(i).mStatus);
                            list.setNotificationTime(data.response.get(i).createdTime);

                            arrayList.add(list);
                        }

                        NotificationAdapter adapter = new NotificationAdapter(ForemanNotificationActivity.this, arrayList, apiInterface, sp);
                        recyclerView.setAdapter(adapter);

                    } else {
                        new CommonMethod(ForemanNotificationActivity.this, response.body().message);
                    }

                } else {
                    new CommonMethod(ForemanNotificationActivity.this, "Server Error Code : "+response.code());
                }

            }

            @Override
            public void onFailure(Call<GetNotificationData> call, Throwable t) {
                pd.dismiss();
                new CommonMethod(ForemanNotificationActivity.this, t.getMessage());
            }
        });

    }


}