package com.brainybeam.roadsideassistance.User.Activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.brainybeam.roadsideassistance.R;
import com.brainybeam.roadsideassistance.RetrofitData.CartAddServicesData;
import com.brainybeam.roadsideassistance.RetrofitData.CartGetSPReqMoneyData;
import com.brainybeam.roadsideassistance.RetrofitData.SendNotificationData;
import com.brainybeam.roadsideassistance.User.DashBoard.UserDashboardActivity;
import com.brainybeam.roadsideassistance.Utils.ApiClient;
import com.brainybeam.roadsideassistance.Utils.ApiInterface;
import com.brainybeam.roadsideassistance.Utils.CommonMethod;
import com.brainybeam.roadsideassistance.Utils.ConstantData;
import com.brainybeam.roadsideassistance.Utils.SharedPreferencesData;
import com.razorpay.Checkout;
import com.razorpay.PaymentResultListener;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class UserEndActivity extends AppCompatActivity implements PaymentResultListener {

    CardView cardView1, cardView2;

    Spinner PaymentMode;
    ArrayList<String> arrayList;
    Button PayButton, DoneButton;
    TextView moneyTextView;

    String sPaymentMode;

    ApiInterface apiInterface;
    SharedPreferences sp;
    ProgressDialog pd;
    String paymentStatus = "";

    int tsum = 0;
    String PaymentAmount = "";
    String PaymentID = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_end);
        // getSupportActionBar().hide();
        getSupportActionBar().setTitle("Payment Activity");
        ColorDrawable colorDrawable
                = new ColorDrawable(Color.parseColor("#2196F3"));
        getSupportActionBar().setBackgroundDrawable(colorDrawable);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);


        apiInterface = ApiClient.getClient().create(ApiInterface.class);
        sp = getSharedPreferences(SharedPreferencesData.PREF, MODE_PRIVATE);

        cardView1 = findViewById(R.id.user_endActivity_MainCardView);
        cardView2 = findViewById(R.id.user_endActivity_CardViewNoPaymentRequest);

        PaymentMode = findViewById(R.id.user_endActivity_Spinner_PaymentMode);
        PayButton = findViewById(R.id.user_endActivity_PayButton);
        DoneButton = findViewById(R.id.user_endActivity_DoneButton);

        moneyTextView = findViewById(R.id.user_endActivity_MoneyTextView);

        PayButton.setVisibility(View.VISIBLE);
        DoneButton.setVisibility(View.GONE);

        moneyTextView.setText(sp.getString(SharedPreferencesData.User_FixCharge, ""));

        cardView1.setVisibility(View.VISIBLE);
        cardView2.setVisibility(View.GONE);

        if(sp.getString(SharedPreferencesData.User_ForemanFirstName, "")==""|| sp.getString(SharedPreferencesData.User_ForemanFirstName, "").isEmpty()
                && sp.getString(SharedPreferencesData.User_TypeOfProblem, "")=="" || sp.getString(SharedPreferencesData.User_TypeOfProblem, "").isEmpty() &&
        sp.getString(SharedPreferencesData.User_Payment, "")!="" || !sp.getString(SharedPreferencesData.User_Payment, "").isEmpty()){
            cardView1.setVisibility(View.GONE);
            cardView2.setVisibility(View.VISIBLE);
        } else {
            cardView1.setVisibility(View.VISIBLE);
            cardView2.setVisibility(View.GONE);
        }

        GetPaymentData();

        arrayList = new ArrayList<>();
        arrayList.add("Select Payment Mode");
        String S_array[] = ConstantData.PaymentMode;
        List<String> list;
        list = Arrays.asList(S_array);
        arrayList.addAll(list);

        PaymentMode.setSelection(arrayList.indexOf("Select Payment Mode"));
        ArrayAdapter adapter = new ArrayAdapter(UserEndActivity.this, android.R.layout.simple_list_item_1, arrayList);
        adapter.setDropDownViewResource(android.R.layout.simple_list_item_activated_1);
        PaymentMode.setAdapter(adapter);


        PaymentMode.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                sPaymentMode = arrayList.get(i);
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        if (sPaymentMode=="Cash"){
            PayButton.setVisibility(View.GONE);
            DoneButton.setVisibility(View.VISIBLE);
        } else if(sPaymentMode=="EPayment"){
            PayButton.setVisibility(View.VISIBLE);
            DoneButton.setVisibility(View.GONE);
        } else {
            new CommonMethod(UserEndActivity.this, "Please Select Payment Mode");
        }

        PayButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                pd = new ProgressDialog(UserEndActivity.this);
                pd.setMessage("Please Wait...");
                pd.setCancelable(false);
                pd.show();

                startPayment();
            }
        });

        DoneButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                paymentStatus = "Payment Success";
                pd = new ProgressDialog(UserEndActivity.this);
                pd.setMessage("Processing...");
                pd.setCancelable(false);
                pd.show();
                StorePayment();
                SendNotificationToForeman();
                new CommonMethod(UserEndActivity.this, UserRatingActivity.class);
                finish();
            }
        });


    }

    private void GetPaymentData() {

        Call<CartGetSPReqMoneyData> call = apiInterface.GetSPReqMoneyData(
                sp.getString(SharedPreferencesData.User_ServiceID, ""),
                sp.getString(SharedPreferencesData.User_ForemanID, ""),
                sp.getString(SharedPreferencesData.UserID, "")
        );

        call.enqueue(new Callback<CartGetSPReqMoneyData>() {
            @Override
            public void onResponse(Call<CartGetSPReqMoneyData> call, Response<CartGetSPReqMoneyData> response) {

                if(response.code()==200){

                    if(response.body().status==true){

                        tsum = Integer.valueOf(sp.getString(SharedPreferencesData.User_FixCharge, ""));
                        CartGetSPReqMoneyData data = response.body();

                        for(int i=0; i<data.response.size(); i++){
                            sp.edit().putString(SharedPreferencesData.User_CartID, data.response.get(i).cartID).commit();
                            tsum = tsum + Integer.valueOf(data.response.get(i).sPReqMoney);
                        }
                        PaymentAmount = String.valueOf(tsum);
                        moneyTextView.setText("₹ "+PaymentAmount);
                    } else {
                        moneyTextView.setText(sp.getString(SharedPreferencesData.User_FixCharge, ""));
                        new CommonMethod(UserEndActivity.this, response.body().message);
                    }

                } else {
                    new CommonMethod(UserEndActivity.this, "Server Error Code : "+response.code());
                }

            }

            @Override
            public void onFailure(Call<CartGetSPReqMoneyData> call, Throwable t) {
                new CommonMethod(UserEndActivity.this, t.getMessage());
            }
        });

    }

    public void startPayment() {

        Checkout checkout = new Checkout();

        checkout.setImage(R.mipmap.ic_launcher);

        final Activity activity = this;

        try {
            JSONObject options = new JSONObject();
            options.put("name", ConstantData.ProjectName);
            options.put("description", "Payment for Anything");
            options.put("send_sms_hash", true);
            options.put("allow_rotation", false);

            //You can omit the image option to fetch the image from dashboard
            options.put("currency", "INR");
            options.put("amount", Integer.valueOf(PaymentAmount)*100);

            JSONObject preFill = new JSONObject();
            preFill.put("email", sp.getString(SharedPreferencesData.Email, ""));
            preFill.put("contact", sp.getString(SharedPreferencesData.MobileNumber, ""));

            options.put("prefill", preFill);

            checkout.open(activity, options);
        } catch (Exception e) {
            Toast.makeText(activity, "Error in payment: " + e.getMessage(), Toast.LENGTH_SHORT)
                    .show();
            e.printStackTrace();
        }

    }


    @Override
    public void onPaymentSuccess(String s) {
        new CommonMethod(UserEndActivity.this, "SuccessFully "+s);
        new CommonMethod(UserEndActivity.this, "Thank You");
        paymentStatus = "Payment Success";
        pd = new ProgressDialog(UserEndActivity.this);
        pd.setMessage("Processing...");
        pd.setCancelable(false);
        pd.show();
        StorePayment();
        SendNotificationToForeman();
        new CommonMethod(UserEndActivity.this, UserRatingActivity.class);
        finish();
    }

    private void StorePayment() {

        Random random = new Random();
        String alphabet = "1234567890ABCDabcdXYZxyz";
        for (int i = 0; i < 10; i++) {
            PaymentID = String.valueOf(alphabet.charAt(random.nextInt(alphabet.length())));
        }

        PaymentID = sp.getString(SharedPreferencesData.UserID, "")+PaymentID;

        Call<CartAddServicesData> call = apiInterface.UpdateCartPaymentData(
                sp.getString(SharedPreferencesData.User_CartID, ""),
                sPaymentMode,
                PaymentAmount,
                "Yes",
                PaymentID
        );

        call.enqueue(new Callback<CartAddServicesData>() {
            @Override
            public void onResponse(Call<CartAddServicesData> call, Response<CartAddServicesData> response) {

                if(response.code()==200){

                    if(response.body().status==true){
                        sp.edit().putString(SharedPreferencesData.User_PaymentMode, sPaymentMode).commit();
                        sp.edit().putString(SharedPreferencesData.User_Payment, PaymentAmount).commit();
                        sp.edit().putString(SharedPreferencesData.User_PaymentID, PaymentID).commit();

                        StoreHistoryTBData();
                        new CommonMethod(UserEndActivity.this, response.body().message);
                    } else {
                        pd.dismiss();
                        new CommonMethod(UserEndActivity.this, response.body().message);
                        new CommonMethod(UserEndActivity.this, "Please Try Again");
                        new CommonMethod(UserEndActivity.this, UserEndActivity.class);
                    }

                } else {
                    new CommonMethod(UserEndActivity.this, "Server Error Code : "+response.code());
                }

            }

            @Override
            public void onFailure(Call<CartAddServicesData> call, Throwable t) {
                new CommonMethod(UserEndActivity.this, t.getMessage());
            }
        });

    }

    private void StoreHistoryTBData() {

        Call<CartAddServicesData> call = apiInterface.AddHistoryData(
                sp.getString(SharedPreferencesData.User_CartID, ""),
                sp.getString(SharedPreferencesData.User_ServiceID, ""),
                sp.getString(SharedPreferencesData.User_ForemanID, ""),
                sp.getString(SharedPreferencesData.UserID, ""),
                sp.getString(SharedPreferencesData.VehicleID, ""),
                sp.getString(SharedPreferencesData.User_DescriptionMessage, ""),
                sp.getString(SharedPreferencesData.User_PaymentID, ""),
                sp.getString(SharedPreferencesData.User_SPReqMoney, ""),
                sp.getString(SharedPreferencesData.User_PaymentMode, ""),
                sp.getString(SharedPreferencesData.User_Payment, ""),
                sp.getString(SharedPreferencesData.User_UserLocation, "")
        );

        call.enqueue(new Callback<CartAddServicesData>() {
            @Override
            public void onResponse(Call<CartAddServicesData> call, Response<CartAddServicesData> response) {

                if(response.code()==200){

                    if(response.body().status==true){
                       // new CommonMethod(UserEndActivity.this, response.body().message);
                    } else {
                        new CommonMethod(UserEndActivity.this, response.body().message);
                    }

                } else {
                    new CommonMethod(UserEndActivity.this, "Server Error Code : "+response.code());
                }

            }

            @Override
            public void onFailure(Call<CartAddServicesData> call, Throwable t) {
                new CommonMethod(UserEndActivity.this, t.getMessage());
            }
        });

    }

    @Override
    public void onPaymentError(int i, String s) {
        new CommonMethod(UserEndActivity.this, i+" UnSuccessFully "+s);
        new CommonMethod(UserEndActivity.this, "Re-Try");
        paymentStatus = "Payment UnSuccess";
        pd = new ProgressDialog(UserEndActivity.this);
        pd.setMessage("Processing...");
        pd.setCancelable(false);
        pd.show();
        SendNotificationToForeman();
    }

    private void SendNotificationToForeman() {

        String Title = ""+sp.getString(SharedPreferencesData.User_ForemanFirstName, "")+" Your "+paymentStatus;
        String Message = "UserID - "+sp.getString(SharedPreferencesData.UserID, "")+"\n Payment Status : "+paymentStatus+"\n Contact Number : "+sp.getString(SharedPreferencesData.MobileNumber, "")+" Type of Problem : "+sp.getString(SharedPreferencesData.UserTypeOfProblem, "")+"\n"+
                "Thank You!";

        Call<SendNotificationData> call = apiInterface.SendToForemanNotificationData(
                sp.getString(SharedPreferencesData.User_ForemanID, ""),
                Title,
                Message
        );

        call.enqueue(new Callback<SendNotificationData>() {
            @Override
            public void onResponse(Call<SendNotificationData> call, Response<SendNotificationData> response) {

                pd.dismiss();
                if(response.code()==200){

                    if(response.body().status==true){
                       // new CommonMethod(UserEndActivity.this, response.body().message);
                    } else {
                        new CommonMethod(UserEndActivity.this, response.body().message);
                    }

                } else {
                    new CommonMethod(UserEndActivity.this, "Server Error Code : "+response.code());
                }

            }

            @Override
            public void onFailure(Call<SendNotificationData> call, Throwable t) {
                pd.dismiss();
                new CommonMethod(UserEndActivity.this, t.getMessage());
            }
        });

    }


    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();
        if (id == android.R.id.home) {
            onBackPressed();
        }
        return super.onOptionsItemSelected(item);
    }


}