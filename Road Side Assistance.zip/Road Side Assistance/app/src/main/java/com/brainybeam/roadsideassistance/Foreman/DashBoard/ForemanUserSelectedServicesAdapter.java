package com.brainybeam.roadsideassistance.Foreman.DashBoard;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.FragmentActivity;
import androidx.recyclerview.widget.RecyclerView;

import com.brainybeam.roadsideassistance.Foreman.Activity.ForemanTrackingActivity;
import com.brainybeam.roadsideassistance.Foreman.CustomArrayList.ForemanUserSelectedServicesList;
import com.brainybeam.roadsideassistance.GPS.GPSTracker;
import com.brainybeam.roadsideassistance.R;
import com.brainybeam.roadsideassistance.RetrofitData.CartAddServicesData;
import com.brainybeam.roadsideassistance.RetrofitData.DeleteUserORForemanData;
import com.brainybeam.roadsideassistance.RetrofitData.LocationData;
import com.brainybeam.roadsideassistance.RetrofitData.SendNotificationData;
import com.brainybeam.roadsideassistance.User.DashBoard.UserDashboardActivity;
import com.brainybeam.roadsideassistance.User.DashBoard.UserVehicleDetailAdapter;
import com.brainybeam.roadsideassistance.Utils.ApiClient;
import com.brainybeam.roadsideassistance.Utils.ApiInterface;
import com.brainybeam.roadsideassistance.Utils.CommonMethod;
import com.brainybeam.roadsideassistance.Utils.ConstantData;
import com.brainybeam.roadsideassistance.Utils.SharedPreferencesData;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

import de.hdodenhof.circleimageview.CircleImageView;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ForemanUserSelectedServicesAdapter extends RecyclerView.Adapter<ForemanUserSelectedServicesAdapter.MyHolder> {

    Context context;
    ArrayList<ForemanUserSelectedServicesList> arrayList;
    ApiInterface apiInterface;
    SharedPreferences sp;

    GPSTracker gpsTracker;
    Double Curr_ForemanLatitude, Curr_ForemanLongitude;
    ProgressDialog pd;

    String sUserID, sUserFirstName, sUserLastName, sMobileNumber;

    public ForemanUserSelectedServicesAdapter(Context context, ArrayList<ForemanUserSelectedServicesList> arrayList) {
        this.context = context;
        this.arrayList = arrayList;
    }

    @NonNull
    @Override
    public MyHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.custom_foreman_user_selected_services, parent, false);

        return new MyHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyHolder holder, @SuppressLint("RecyclerView") int position) {

        sUserID = arrayList.get(position).getUserID();
        sUserFirstName = arrayList.get(position).getUserFirstName();
        sUserLastName = arrayList.get(position).getUserLastName();
        sMobileNumber = arrayList.get(position).getUserMobileNumber();

        if (arrayList.get(position).getUserProfileImage().isEmpty() || arrayList.get(position).getUserProfileImage().equalsIgnoreCase("")){
            holder.UserProfileImageView.setVisibility(View.GONE);
        } else {
            Picasso.with(context).load(arrayList.get(position).getUserProfileImage()).placeholder(R.drawable.ic_profile).into(holder.UserProfileImageView);
        }

        holder.UserID.setText(sUserID);

        holder.Name.setText(sUserFirstName+" "+sUserLastName);
        holder.MobileNumber.setText("+91 "+sMobileNumber);
        holder.TypeOfProblem.setText(arrayList.get(position).getTypeOfProblem());
        holder.ProblemSubType.setText(arrayList.get(position).getProblemSubType());
        holder.FixedCharge.setText("₹ "+arrayList.get(position).getServiceFixedCharge());
        holder.UserLocation.setText(arrayList.get(position).getUserLocation());
        holder.VehicleNumber.setText(arrayList.get(position).getNumberPlate_number());
        holder.TypeOfVehicle.setText(arrayList.get(position).getTypeOfVehicle());
        holder.ModelName.setText(arrayList.get(position).getVehicleModelName());
        holder.UserMessage.setText(arrayList.get(position).getProblemDescriptionMessage());

        holder.CallingImageLogo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                AlertDialog.Builder builder = new AlertDialog.Builder(view.getContext());
                builder.setTitle("Call to User "+arrayList.get(position).getUserFirstName()+"?");
                builder.setPositiveButton("CALL", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        Intent intent = new Intent(Intent.ACTION_CALL);
                        intent.setData(Uri.parse("tel:"+"+91"+arrayList.get(position).getUserMobileNumber()));
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                            if (context.checkSelfPermission(Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
                                // TODO: Consider calling
                                //    Activity#requestPermissions
                                // here to request the missing permissions, and then overriding
                                //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
                                //                                          int[] grantResults)
                                // to handle the case where the user grants the permission. See the documentation
                                // for Activity#requestPermissions for more details.
                                return;
                            }
                        }
                        context.startActivity(intent);
                    }
                });

                builder.setNegativeButton("CANCEL", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        dialogInterface.dismiss();
                    }
                });

                builder.show();
            }
        });

        gpsTracker = new GPSTracker(context);
        // Check if GPS enabled
        if(gpsTracker.canGetLocation()) {

            Curr_ForemanLatitude = gpsTracker.getLatitude();
            Curr_ForemanLongitude = gpsTracker.getLongitude();

            //  getLocation();

        } else {
            // Can't get location.
            // GPS or network is not enabled.
            // Ask user to enable GPS/network in settings.
            gpsTracker.showSettingsAlert();
        }


        holder.AcceptButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                sp.edit().putString(SharedPreferencesData.Foreman_UserID, arrayList.get(position).getUserID()).commit();
                sp.edit().putString(SharedPreferencesData.Foreman_UserFirstName, arrayList.get(position).getUserFirstName()).commit();
                sp.edit().putString(SharedPreferencesData.Foreman_UserLastName, arrayList.get(position).getUserLastName()).commit();

                sp.edit().putString(SharedPreferencesData.Foreman_ServiceID, arrayList.get(position).getServiceID()).commit();
                sp.edit().putString(SharedPreferencesData.Foreman_CartID, arrayList.get(position).getCartID()).commit();
                sp.edit().putString(SharedPreferencesData.Foreman_UserVehicleID, arrayList.get(position).getVehicleID()).commit();
                sp.edit().putString(SharedPreferencesData.Foreman_UserMobileNumber, arrayList.get(position).getUserMobileNumber()).commit();
                sp.edit().putString(SharedPreferencesData.Foreman_UserLocation, arrayList.get(position).getUserLocation()).commit();
                sp.edit().putString(SharedPreferencesData.Foreman_UserVehicleNumber, arrayList.get(position).getNumberPlate_number()).commit();
                sp.edit().putString(SharedPreferencesData.Foreman_UserTypeOfVehicle, arrayList.get(position).getTypeOfVehicle()).commit();
                sp.edit().putString(SharedPreferencesData.Foreman_UserVehicleModelName, arrayList.get(position).getVehicleModelName()).commit();
                sp.edit().putString(SharedPreferencesData.Foreman_UserDescriptionMessage, arrayList.get(position).getProblemDescriptionMessage()).commit();

                sp.edit().putString(SharedPreferencesData.Foreman_ForemanLatitude, String.valueOf(Curr_ForemanLatitude)).commit();
                sp.edit().putString(SharedPreferencesData.Foreman_ForemanLongitude, String.valueOf(Curr_ForemanLongitude)).commit();
                sp.edit().putString(SharedPreferencesData.Foreman_ForemanLocation, String.valueOf(gpsTracker.getLocation())).commit();

                pd = new ProgressDialog(context);
                pd.setMessage("Please Wait...");
                pd.setCancelable(false);
                pd.show();

                StoreForemanLocationData();
                UpdateReqStatus();
                SendNotificationToUserAfterAccept(sUserID, sUserFirstName, sUserLastName);
                new CommonMethod(view.getContext(), ForemanTrackingActivity.class);
            }
        });

        holder.RejectButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                SendNotificationToUserAfterReject(sUserID, sUserFirstName, sUserLastName);
                UpdateReqRejectStatus();
                notifyDataSetChanged();
            }
        });

    }

    private void UpdateReqStatus() {

        Call<CartAddServicesData> call = apiInterface.UpdateReqStatusData(
                sp.getString(SharedPreferencesData.Foreman_CartID, "")
        );

        call.enqueue(new Callback<CartAddServicesData>() {
            @Override
            public void onResponse(Call<CartAddServicesData> call, Response<CartAddServicesData> response) {

                if(response.code()==200){

                    if(response.body().status==true){
                        new CommonMethod(context, response.body().message);
                    } else {
                        new CommonMethod(context, response.body().message);
                    }

                } else {
                    new CommonMethod(context, "Server Error Code : "+response.code());
                }

            }

            @Override
            public void onFailure(Call<CartAddServicesData> call, Throwable t) {
                pd.dismiss();
                new CommonMethod(context, t.getMessage());
            }
        });

    }

    private void UpdateReqRejectStatus() {

        Call<CartAddServicesData> call = apiInterface.UpdateReqStatusRejectData(
                sp.getString(SharedPreferencesData.Foreman_CartID, "")
        );

        call.enqueue(new Callback<CartAddServicesData>() {
            @Override
            public void onResponse(Call<CartAddServicesData> call, Response<CartAddServicesData> response) {

                if(response.code()==200){

                    if(response.body().status==true){
                        new CommonMethod(context, response.body().message);
                    } else {
                        new CommonMethod(context, response.body().message);
                    }

                } else {
                    new CommonMethod(context, "Server Error Code : "+response.code());
                }

            }

            @Override
            public void onFailure(Call<CartAddServicesData> call, Throwable t) {
                pd.dismiss();
                new CommonMethod(context, t.getMessage());
            }
        });

    }

    private void DeleteCartItem() {

        Call<CartAddServicesData> call = apiInterface.DeleteCartData(
                sp.getString(SharedPreferencesData.Foreman_CartID, "")
        );

        call.enqueue(new Callback<CartAddServicesData>() {
            @Override
            public void onResponse(Call<CartAddServicesData> call, Response<CartAddServicesData> response) {

              //  pd.dismiss();
                if(response.code()==200){

                    if(response.body().status==true){

                        // new CommonMethod(context, response.body().message);
                        new CommonMethod(context, "SuccessFully Rejected");
                    } else {
                        new CommonMethod(context, response.body().message);
                    }

                } else {
                    new CommonMethod(context, "Server Error Code : "+response.code());
                }

            }

            @Override
            public void onFailure(Call<CartAddServicesData> call, Throwable t) {
                pd.dismiss();
                new CommonMethod(context, t.getMessage());
            }
        });

    }

    private void StoreForemanLocationData() {

        String FLatitude, FLongitude;

        FLatitude = String.valueOf(Curr_ForemanLatitude);
        FLongitude = String.valueOf(Curr_ForemanLongitude);

        sp.edit().putString(SharedPreferencesData.Foreman_ForemanCurrLatitude, FLatitude).commit();
        sp.edit().putString(SharedPreferencesData.Foreman_ForemanCurrLongitude, FLongitude).commit();

        Call<LocationData> call = apiInterface.AddForemanLocationData(
                sp.getString(SharedPreferencesData.UserID, ""),
                sp.getString(SharedPreferencesData.Foreman_UserID, ""),
                FLatitude,
                FLongitude
        );

        call.enqueue(new Callback<LocationData>() {
            @Override
            public void onResponse(Call<LocationData> call, Response<LocationData> response) {

                if(response.code()==200){

                    if(response.body().status==true){
                       // new CommonMethod(context, response.body().message);
                    } else {
                        new CommonMethod(context, response.body().message);
                    }

                } else {
                    new CommonMethod(context, "Server Error Code : "+response.code());
                }

            }

            @Override
            public void onFailure(Call<LocationData> call, Throwable t) {
                pd.dismiss();
                new CommonMethod(context, t.getMessage());
            }
        });

    }


    @Override
    public int getItemCount() {
        return arrayList.size();
    }


    public class MyHolder extends RecyclerView.ViewHolder{

        CircleImageView UserProfileImageView;
        ImageView CallingImageLogo;

        TextView UserID;
        TextView Name, MobileNumber, TypeOfProblem, ProblemSubType, FixedCharge;
        TextView UserLocation;
        TextView VehicleNumber, TypeOfVehicle, ModelName, UserMessage;
        Button AcceptButton, RejectButton;

        public MyHolder(@NonNull View itemView) {
            super(itemView);

            apiInterface = ApiClient.getClient().create(ApiInterface.class);
            sp = context.getSharedPreferences(SharedPreferencesData.PREF, Context.MODE_PRIVATE);


            UserID = itemView.findViewById(R.id.custom_foreman_user_selected_services_UserID);
            UserProfileImageView = itemView.findViewById(R.id.custom_foreman_user_selected_services_UserProfileImage);
            CallingImageLogo = itemView.findViewById(R.id.custom_foreman_user_selected_services_calling_Image_logo);
            Name = itemView.findViewById(R.id.custom_foreman_user_selected_services_FirstANDLastName);
            MobileNumber = itemView.findViewById(R.id.custom_foreman_user_selected_services_MobileNumber);
            TypeOfProblem = itemView.findViewById(R.id.custom_foreman_user_selected_services_TypeOfProblem);
            ProblemSubType = itemView.findViewById(R.id.custom_foreman_user_selected_services_problemSubType);
            FixedCharge = itemView.findViewById(R.id.custom_foreman_user_selected_services_FixedCharge);
            UserLocation = itemView.findViewById(R.id.custom_foreman_user_selected_services_UserLocation);

            VehicleNumber = itemView.findViewById(R.id.custom_foreman_user_selected_services_VehicleNumber);
            TypeOfVehicle = itemView.findViewById(R.id.custom_foreman_user_selected_services_TypeOfVehicle);
            ModelName = itemView.findViewById(R.id.custom_foreman_user_selected_services_ModelName);
            UserMessage = itemView.findViewById(R.id.custom_foreman_user_selected_services_UserMessage);

            AcceptButton = itemView.findViewById(R.id.custom_foreman_user_selected_services_AcceptButton);
            RejectButton = itemView.findViewById(R.id.custom_foreman_user_selected_services_RejectButton);

        }
    }


    private void SendNotificationToUserAfterReject(String UserID, String UserFirstName, String UserLastName) {

        String Title = "UserID - "+UserID+" "+UserFirstName+" "+UserLastName+" "+" Request Rejected";
        String Message = "Sorry for the inconvenience! Your request has been denied for some Reason.\n" +
                "Please Try Again OR Contact Road Side Assistant";

        Call<SendNotificationData> call = apiInterface.SendToUserNotificationData(
                UserID,
                Title,
                Message
        );

        call.enqueue(new Callback<SendNotificationData>() {
            @Override
            public void onResponse(Call<SendNotificationData> call, Response<SendNotificationData> response) {

              //  pd.dismiss();
                if(response.code()==200){

                    if(response.body().status==true){
                       // new CommonMethod(context, response.body().message);
                    } else {
                        new CommonMethod(context, response.body().message);
                    }

                } else {
                    new CommonMethod(context, "Server Error Code : "+response.code());
                }

            }

            @Override
            public void onFailure(Call<SendNotificationData> call, Throwable t) {
                pd.dismiss();
                new CommonMethod(context, t.getMessage());
            }
        });

    }

    private void SendNotificationToUserAfterAccept(String UserID, String UserFirstName, String UserLastName) {

        String Title = "UserID - "+UserID+" "+UserFirstName+" "+UserLastName+" "+" Request Accepted";
        String Message = "We are accepted your Request. We will try to reach your Location As soon as possible!\n" +
                "You Can Track our Location OR " + "Contact us "+"+91 "+ sMobileNumber +" \n" +
                "Thank you!";

        // new CommonMethod(context, UserID+" "+UserFirstName+" "+UserLastName+" "+sMobileNumber);

        Call<SendNotificationData> call = apiInterface.SendToUserNotificationData(
                UserID, Title, Message
        );

        call.enqueue(new Callback<SendNotificationData>() {
            @Override
            public void onResponse(Call<SendNotificationData> call, Response<SendNotificationData> response) {

                pd.dismiss();
                if(response.code()==200){

                    if(response.body().status==true){
                       // new CommonMethod(context, response.body().message);
                    } else {
                        new CommonMethod(context, response.body().message);
                    }

                } else {
                    new CommonMethod(context, "Server Error Code : "+response.code());
                }

            }

            @Override
            public void onFailure(Call<SendNotificationData> call, Throwable t) {
                pd.dismiss();
                new CommonMethod(context, t.getMessage());
            }
        });


    }

}
