package com.brainybeam.roadsideassistance.User.DashBoard;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Notification;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.FragmentManager;

import com.brainybeam.roadsideassistance.Login.LoginActivity;
import com.brainybeam.roadsideassistance.Notification.UserNotificationActivity;
import com.brainybeam.roadsideassistance.R;
import com.brainybeam.roadsideassistance.RetrofitData.SwitchAccountData;
import com.brainybeam.roadsideassistance.User.Activity.UserEndActivity;
import com.brainybeam.roadsideassistance.Utils.ApiClient;
import com.brainybeam.roadsideassistance.Utils.ApiInterface;
import com.brainybeam.roadsideassistance.Utils.CommonMethod;
import com.brainybeam.roadsideassistance.Utils.ConstantData;
import com.brainybeam.roadsideassistance.Utils.SharedPreferencesData;
import com.google.android.material.navigation.NavigationView;
import com.google.android.material.snackbar.Snackbar;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class UserDashboardActivity extends AppCompatActivity {

    private static final int STORAGE_PERMISSION_CODE = 123;

    TextView Title_menu;
    ImageView menu_image, calling_image, Notification_image;


    // TODO Navigation
    ImageView nav_header_profileImage;
    TextView nav_header_Name;
    LinearLayout nav_header_home_layout, nav_header_profile_layout, nav_header_verifyDocx_layout, nav_header_request_layout,
            nav_header_AddVehicleDetails_layout, nav_header_history_layout, nav_header_setting_layout, nav_header_logout_layout,
            nav_header_switchAccount_layout, nav_header_paymentPending_layout;

    ImageView nav_header_home_imageview_logo, nav_header_profile_imageview_logo, nav_header_verifyDocx_imageview_logo, nav_header_request_imageview_logo,
            nav_header_AddVehicleDetails_imageview_logo, nav_header_history_imageview_logo, nav_header_setting_imageview_logo, nav_header_logout_imageview_logo,
            nav_header_switchAccount_imageview_logo, nav_header_paymentPending_imageview_logo;

    TextView nav_header_home_TextButton, nav_header_profile_TextButton, nav_header_verifyDocx_TextButton, nav_header_request_TextButton,
            nav_header_AddVehicleDetails_TextButton, nav_header_history_TextButton, nav_header_setting_TextButton, nav_header_logout_TextButton,
            nav_header_switchAccount_TextButton, nav_header_paymentPending_TextButton;

    SharedPreferences sp;
    ApiInterface apiInterface;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_dashboard);
       // getSupportActionBar().hide();
//        getSupportActionBar().setTitle("Home");
//        ColorDrawable colorDrawable
//                = new ColorDrawable(Color.parseColor("#2196F3"));
//        getSupportActionBar().setBackgroundDrawable(colorDrawable);
//        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        setRequestedOrientation (ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);


        // Permission get method
        requestStoragePermission();

        sp = getSharedPreferences(SharedPreferencesData.PREF, MODE_PRIVATE);
        apiInterface = ApiClient.getClient().create(ApiInterface.class);


        // TODO Tab activity Start

        Title_menu = findViewById(R.id.user_content_main_dashboard_title);
        Title_menu.setText("Incident");

        final DrawerLayout drawer = (DrawerLayout) findViewById(R.id.user_drawer_layout);
        menu_image = findViewById(R.id.user_content_main_dashboard_menu_imageButton);
        menu_image.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                drawer.openDrawer(GravityCompat.START);

            }
        });

        calling_image = findViewById(R.id.user_content_main_dashboard_call_imageButton);
        calling_image.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View view) {

               AlertDialog.Builder builder = new AlertDialog.Builder(UserDashboardActivity.this);
               builder.setTitle("Call Assistance Center?");
               builder.setPositiveButton("CALL", new DialogInterface.OnClickListener() {
                   @Override
                   public void onClick(DialogInterface dialogInterface, int i) {
                       Intent intent = new Intent(Intent.ACTION_CALL);
                       intent.setData(Uri.parse("tel:"+ ConstantData.Call_Assistance_MobileNumber));
                       if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                           if (checkSelfPermission(Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
                               // TODO: Consider calling
                               //    Activity#requestPermissions
                               // here to request the missing permissions, and then overriding
                               //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
                               //                                          int[] grantResults)
                               // to handle the case where the user grants the permission. See the documentation
                               // for Activity#requestPermissions for more details.
                               return;
                           }
                       }
                       startActivity(intent);
                   }
               });

               builder.setNegativeButton("CANCEL", new DialogInterface.OnClickListener() {
                   @Override
                   public void onClick(DialogInterface dialogInterface, int i) {
                       dialogInterface.dismiss();
                   }
               });
               builder.show();

           }
       });

        Notification_image = findViewById(R.id.user_content_main_dashboard_Notification_image);
        Notification_image.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                new CommonMethod(UserDashboardActivity.this, UserNotificationActivity.class);
            }
        });


        // TODO Tab activity finished


        // TODO Default Fragment
        drawer.closeDrawer(GravityCompat.START);
        FragmentManager manager = getSupportFragmentManager();

        manager.beginTransaction()
                .replace(R.id.user_content_main_dashboard_FragmentContainerView, new UserHomeFragment(), null)
                .setReorderingAllowed(true)
                .addToBackStack("")
                .commit();




        // TODO ----------------------------------------------------------------
        // TODO                NavigationView Start
        // TODO ----------------------------------------------------------------

        NavigationView navigationView = (NavigationView) findViewById(R.id.user_dashboard_nav_view);
        View header = navigationView.getHeaderView(0);


        nav_header_profileImage = header.findViewById(R.id.user_nav_header_profileImage);
        nav_header_Name = header.findViewById(R.id.user_nav_header_Name);

        String FirstName = sp.getString(SharedPreferencesData.FirstName, "");
        String LastName = sp.getString(SharedPreferencesData.LastName, "");
        nav_header_Name.setText(FirstName+" "+LastName);


        nav_header_home_layout = header.findViewById(R.id.user_nav_header_home_layout);
        nav_header_profile_layout = header.findViewById(R.id.user_nav_header_profile_layout);
        nav_header_verifyDocx_layout = header.findViewById(R.id.user_nav_header_verifyDoc_layout);
        nav_header_request_layout = header.findViewById(R.id.user_nav_header_request_layout);
        nav_header_AddVehicleDetails_layout = header.findViewById(R.id.user_nav_header_AddVehicleDetails_layout);
        nav_header_history_layout = header.findViewById(R.id.user_nav_header_history_layout);
        nav_header_setting_layout = header.findViewById(R.id.user_nav_header_setting_layout);
        nav_header_logout_layout = header.findViewById(R.id.user_nav_header_logout_layout);
        nav_header_switchAccount_layout = header.findViewById(R.id.user_nav_header_switchAccount_layout);
        nav_header_paymentPending_layout = header.findViewById(R.id.user_nav_header_PendingPayment_layout);

        nav_header_home_imageview_logo = header.findViewById(R.id.user_nav_header_home_imageview_logo);
        nav_header_profile_imageview_logo = header.findViewById(R.id.user_nav_header_profile_imageview_logo);
        nav_header_verifyDocx_imageview_logo = header.findViewById(R.id.user_nav_header_verifyDoc_imageview_logo);
        nav_header_request_imageview_logo = header.findViewById(R.id.user_nav_header_request_imageview_logo);
        nav_header_AddVehicleDetails_imageview_logo = header.findViewById(R.id.user_nav_header_AddVehicleDetails_imageview_logo);
        nav_header_history_imageview_logo = header.findViewById(R.id.user_nav_header_history_imageview_logo);
        nav_header_setting_imageview_logo = header.findViewById(R.id.user_nav_header_setting_imageview_logo);
        nav_header_logout_imageview_logo = header.findViewById(R.id.user_nav_header_logout_imageview_logo);
        nav_header_switchAccount_imageview_logo = header.findViewById(R.id.user_nav_header_switchAccount_imageview_logo);
        nav_header_paymentPending_imageview_logo = header.findViewById(R.id.user_nav_header_PendingPayment_imageview_logo);

        nav_header_home_TextButton = header.findViewById(R.id.user_nav_header_home_TextButton);
        nav_header_profile_TextButton = header.findViewById(R.id.user_nav_header_profile_TextButton);
        nav_header_verifyDocx_TextButton = header.findViewById(R.id.user_nav_header_verifyDoc_TextButton);
        nav_header_request_TextButton = header.findViewById(R.id.user_nav_header_request_TextButton);
        nav_header_AddVehicleDetails_TextButton = header.findViewById(R.id.user_nav_header_AddVehicleDetails_TextButton);
        nav_header_history_TextButton = header.findViewById(R.id.user_nav_header_history_TextButton);
        nav_header_setting_TextButton = header.findViewById(R.id.user_nav_header_setting_TextButton);
        nav_header_logout_TextButton = header.findViewById(R.id.user_nav_header_logout_TextButton);
        nav_header_switchAccount_TextButton = header.findViewById(R.id.user_nav_header_switchAccount_TextButton);
        nav_header_paymentPending_TextButton = header.findViewById(R.id.user_nav_header_PendingPayment_TextButton);


        // TODO Home Fragment
        nav_header_home_TextButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Title_menu.setText("Incident");
                drawer.closeDrawer(GravityCompat.START);
                FragmentManager manager = getSupportFragmentManager();

                manager.beginTransaction()
                        .replace(R.id.user_content_main_dashboard_FragmentContainerView, new UserHomeFragment(), null)
                        .setReorderingAllowed(true)
                        .addToBackStack("")
                        .commit();
            }
        });

        nav_header_home_imageview_logo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Title_menu.setText("Incident");
                drawer.closeDrawer(GravityCompat.START);
                FragmentManager manager = getSupportFragmentManager();

                manager.beginTransaction()
                        .replace(R.id.user_content_main_dashboard_FragmentContainerView, new UserHomeFragment(), null)
                        .setReorderingAllowed(true)
                        .addToBackStack("")
                        .commit();
            }
        });

        nav_header_home_layout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Title_menu.setText("Incident");
                drawer.closeDrawer(GravityCompat.START);
                FragmentManager manager = getSupportFragmentManager();

                manager.beginTransaction()
                        .replace(R.id.user_content_main_dashboard_FragmentContainerView, new UserHomeFragment(), null)
                        .setReorderingAllowed(true)
                        .addToBackStack("")
                        .commit();
            }
        });

        // TODO Profile Fragment
        nav_header_profile_TextButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Title_menu.setText("Profile");
                drawer.closeDrawer(GravityCompat.START);
                FragmentManager manager = getSupportFragmentManager();

                manager.beginTransaction()
                        .replace(R.id.user_content_main_dashboard_FragmentContainerView, new UserProfileFragment(), null)
                        .setReorderingAllowed(true)
                        .addToBackStack("")
                        .commit();
            }
        });

        nav_header_profile_imageview_logo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Title_menu.setText("Profile");
                drawer.closeDrawer(GravityCompat.START);
                FragmentManager manager = getSupportFragmentManager();

                manager.beginTransaction()
                        .replace(R.id.user_content_main_dashboard_FragmentContainerView, new UserProfileFragment(), null)
                        .setReorderingAllowed(true)
                        .addToBackStack("")
                        .commit();
            }
        });

        nav_header_profile_layout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Title_menu.setText("Profile");
                drawer.closeDrawer(GravityCompat.START);
                FragmentManager manager = getSupportFragmentManager();

                manager.beginTransaction()
                        .replace(R.id.user_content_main_dashboard_FragmentContainerView, new UserProfileFragment(), null)
                        .setReorderingAllowed(true)
                        .addToBackStack("")
                        .commit();
            }
        });


        // TODO VerifyDocx Fragment
        nav_header_verifyDocx_TextButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Title_menu.setText("Verify Documents");
                drawer.closeDrawer(GravityCompat.START);
                FragmentManager manager = getSupportFragmentManager();

                manager.beginTransaction()
                        .replace(R.id.user_content_main_dashboard_FragmentContainerView, new UserVerifyDocumentsFragment(), null)
                        .setReorderingAllowed(true)
                        .addToBackStack("")
                        .commit();
            }
        });

        nav_header_verifyDocx_imageview_logo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Title_menu.setText("Verify Documents");
                drawer.closeDrawer(GravityCompat.START);
                FragmentManager manager = getSupportFragmentManager();

                manager.beginTransaction()
                        .replace(R.id.user_content_main_dashboard_FragmentContainerView, new UserVerifyDocumentsFragment(), null)
                        .setReorderingAllowed(true)
                        .addToBackStack("")
                        .commit();
            }
        });

        nav_header_verifyDocx_layout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Title_menu.setText("Verify Documents");
                drawer.closeDrawer(GravityCompat.START);
                FragmentManager manager = getSupportFragmentManager();

                manager.beginTransaction()
                        .replace(R.id.user_content_main_dashboard_FragmentContainerView, new UserVerifyDocumentsFragment(), null)
                        .setReorderingAllowed(true)
                        .addToBackStack("")
                        .commit();
            }
        });

        // TODO Request Fragment
        nav_header_request_TextButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Title_menu.setText("Requests");
                drawer.closeDrawer(GravityCompat.START);
                FragmentManager manager = getSupportFragmentManager();

                manager.beginTransaction()
                        .replace(R.id.user_content_main_dashboard_FragmentContainerView, new UserRequestFragment(), null)
                        .setReorderingAllowed(true)
                        .addToBackStack("")
                        .commit();
            }
        });

        nav_header_request_imageview_logo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Title_menu.setText("Requests");
                drawer.closeDrawer(GravityCompat.START);
                FragmentManager manager = getSupportFragmentManager();

                manager.beginTransaction()
                        .replace(R.id.user_content_main_dashboard_FragmentContainerView, new UserRequestFragment(), null)
                        .setReorderingAllowed(true)
                        .addToBackStack("")
                        .commit();
            }
        });

        nav_header_request_layout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Title_menu.setText("Requests");
                drawer.closeDrawer(GravityCompat.START);
                FragmentManager manager = getSupportFragmentManager();

                manager.beginTransaction()
                        .replace(R.id.user_content_main_dashboard_FragmentContainerView, new UserRequestFragment(), null)
                        .setReorderingAllowed(true)
                        .addToBackStack("")
                        .commit();
            }
        });

        // TODO Add Vehicle Detail Fragment
        nav_header_AddVehicleDetails_TextButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Title_menu.setText("Add Vehicle Details");
                drawer.closeDrawer(GravityCompat.START);
                FragmentManager manager = getSupportFragmentManager();

                manager.beginTransaction()
                        .replace(R.id.user_content_main_dashboard_FragmentContainerView, new UserAddVehicleDetailFragment(), null)
                        .setReorderingAllowed(true)
                        .addToBackStack("")
                        .commit();
            }
        });

        nav_header_AddVehicleDetails_imageview_logo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Title_menu.setText("Add Vehicle Details");
                drawer.closeDrawer(GravityCompat.START);
                FragmentManager manager = getSupportFragmentManager();

                manager.beginTransaction()
                        .replace(R.id.user_content_main_dashboard_FragmentContainerView, new UserAddVehicleDetailFragment(), null)
                        .setReorderingAllowed(true)
                        .addToBackStack("")
                        .commit();
            }
        });

        nav_header_AddVehicleDetails_layout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Title_menu.setText("Add Vehicle Details");
                drawer.closeDrawer(GravityCompat.START);
                FragmentManager manager = getSupportFragmentManager();

                manager.beginTransaction()
                        .replace(R.id.user_content_main_dashboard_FragmentContainerView, new UserAddVehicleDetailFragment(), null)
                        .setReorderingAllowed(true)
                        .addToBackStack("")
                        .commit();
            }
        });

        // TODO History Fragment
        nav_header_history_TextButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Title_menu.setText("History");
                drawer.closeDrawer(GravityCompat.START);
                FragmentManager manager = getSupportFragmentManager();

                manager.beginTransaction()
                        .replace(R.id.user_content_main_dashboard_FragmentContainerView, new UserHistoryFragment(), null)
                        .setReorderingAllowed(true)
                        .addToBackStack("")
                        .commit();
            }
        });

        nav_header_history_imageview_logo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Title_menu.setText("History");
                drawer.closeDrawer(GravityCompat.START);
                FragmentManager manager = getSupportFragmentManager();

                manager.beginTransaction()
                        .replace(R.id.user_content_main_dashboard_FragmentContainerView, new UserHistoryFragment(), null)
                        .setReorderingAllowed(true)
                        .addToBackStack("")
                        .commit();
            }
        });

        nav_header_history_layout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Title_menu.setText("History");
                drawer.closeDrawer(GravityCompat.START);
                FragmentManager manager = getSupportFragmentManager();

                manager.beginTransaction()
                        .replace(R.id.user_content_main_dashboard_FragmentContainerView, new UserHistoryFragment(), null)
                        .setReorderingAllowed(true)
                        .addToBackStack("")
                        .commit();
            }
        });

        // TODO Settings Fragment
        nav_header_setting_TextButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Title_menu.setText("Settings");
                drawer.closeDrawer(GravityCompat.START);
                FragmentManager manager = getSupportFragmentManager();

                manager.beginTransaction()
                        .replace(R.id.user_content_main_dashboard_FragmentContainerView, new UserSettingsFragment(), null)
                        .setReorderingAllowed(true)
                        .addToBackStack("")
                        .commit();
            }
        });

        nav_header_setting_imageview_logo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Title_menu.setText("Settings");
                drawer.closeDrawer(GravityCompat.START);
                FragmentManager manager = getSupportFragmentManager();

                manager.beginTransaction()
                        .replace(R.id.user_content_main_dashboard_FragmentContainerView, new UserSettingsFragment(), null)
                        .setReorderingAllowed(true)
                        .addToBackStack("")
                        .commit();
            }
        });

        nav_header_setting_layout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Title_menu.setText("Settings");
                drawer.closeDrawer(GravityCompat.START);
                FragmentManager manager = getSupportFragmentManager();

                manager.beginTransaction()
                        .replace(R.id.user_content_main_dashboard_FragmentContainerView, new UserSettingsFragment(), null)
                        .setReorderingAllowed(true)
                        .addToBackStack("")
                        .commit();
            }
        });

        // TODO Logout Fragment
        nav_header_logout_TextButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Title_menu.setText("Logout");
                sp.edit().clear().commit();
                startActivity(new Intent(UserDashboardActivity.this, LoginActivity.class).setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP));
            }
        });

        nav_header_logout_imageview_logo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Title_menu.setText("Logout");
                sp.edit().clear().commit();
                startActivity(new Intent(UserDashboardActivity.this, LoginActivity.class).setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP));
            }
        });

        nav_header_logout_layout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Title_menu.setText("Logout");
                sp.edit().clear().commit();
                startActivity(new Intent(UserDashboardActivity.this, LoginActivity.class).setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP));
            }
        });

        // TODO SwitchAccount Fragment
        nav_header_switchAccount_TextButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Title_menu.setText("Switch Account");
                sp.edit().clear().commit();
                new CommonMethod(UserDashboardActivity.this, LoginActivity.class);
            }
        });

        nav_header_switchAccount_imageview_logo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Title_menu.setText("Switch Account");
                sp.edit().clear().commit();
                new CommonMethod(UserDashboardActivity.this, LoginActivity.class);
            }
        });

        nav_header_switchAccount_layout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Title_menu.setText("Switch Account");
                sp.edit().clear().commit();
                new CommonMethod(UserDashboardActivity.this, LoginActivity.class);
            }
        });



        // TODO Pending Payment Fragment
        nav_header_paymentPending_TextButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Title_menu.setText("Pending Payment");
                new CommonMethod(UserDashboardActivity.this, UserEndActivity.class);
            }
        });

        nav_header_paymentPending_imageview_logo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Title_menu.setText("Pending Payment");
                new CommonMethod(UserDashboardActivity.this, UserEndActivity.class);
            }
        });

        nav_header_paymentPending_layout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Title_menu.setText("Pending Payment");
                new CommonMethod(UserDashboardActivity.this, UserEndActivity.class);
            }
        });





        // TODO If User Have Foreman Account
         nav_header_switchAccount_layout.setVisibility(View.GONE);
        String sUserEmail = sp.getString(SharedPreferencesData.Email, "");
        CheckUserISForeman(sUserEmail);



        // TODO ----------------------------------------------------------------
        // TODO                NavigationView Finished
        // TODO ----------------------------------------------------------------




    }


    private void CheckUserISForeman(String sUserEmail) {

        Call<SwitchAccountData> call = apiInterface.SwitchAccountData(
          sUserEmail
        );

        call.enqueue(new Callback<SwitchAccountData>() {
            @Override
            public void onResponse(Call<SwitchAccountData> call, Response<SwitchAccountData> response) {

                if(response.code()==200){

                    if(response.body().message.equalsIgnoreCase("Switch")){
                        nav_header_switchAccount_layout.setVisibility(View.VISIBLE);
                    } else if (response.body().message.equalsIgnoreCase("NotSwitch")) {
                        nav_header_switchAccount_layout.setVisibility(View.GONE);
                    }

                } else {
                    new CommonMethod(UserDashboardActivity.this, "Server Error Code : "+response.code());
                }

            }

            @Override
            public void onFailure(Call<SwitchAccountData> call, Throwable t) {
                new CommonMethod(UserDashboardActivity.this, t.getMessage());
            }
        });

    }


    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.user_drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            //super.onBackPressed();
            AlertDialog.Builder builder = new AlertDialog.Builder(UserDashboardActivity.this);
            builder.setTitle(getResources().getString(R.string.app_name));
            builder.setMessage("Are You Sure Want To Exit!");
            builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                    finishAffinity();
                }
            });
            builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                    dialogInterface.dismiss();
                }
            });
            builder.show();
        }
    }

    private void requestStoragePermission() {
        if (ContextCompat.checkSelfPermission(UserDashboardActivity.this,
                Manifest.permission.CALL_PHONE)
                != PackageManager.PERMISSION_GRANTED) {

            if (ActivityCompat.shouldShowRequestPermissionRationale
                    (UserDashboardActivity.this, Manifest.permission.CALL_PHONE)) {

                Snackbar.make(UserDashboardActivity.this.findViewById(android.R.id.content),
                        "Please Grant Permissions to Download photo",
                        Snackbar.LENGTH_INDEFINITE).setAction("ENABLE",
                        new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                                    requestPermissions(
                                            new String[]{Manifest.permission
                                                    .CALL_PHONE},
                                            STORAGE_PERMISSION_CODE);
                                }
                            }
                        }).show();
            } else {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    requestPermissions(
                            new String[]{Manifest.permission
                                    .CALL_PHONE},
                            STORAGE_PERMISSION_CODE);
                }
            }
        } else {
            // write your logic code if permission already granted
        }
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_notification, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();
        if (id == android.R.id.home) {
            onBackPressed();
        }
        if(id == R.id.notification_menu){
            new CommonMethod(UserDashboardActivity.this, UserNotificationActivity.class);
        }
        return super.onOptionsItemSelected(item);
    }


}