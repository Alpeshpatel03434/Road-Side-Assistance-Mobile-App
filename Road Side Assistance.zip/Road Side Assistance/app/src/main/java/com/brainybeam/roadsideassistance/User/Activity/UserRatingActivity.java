package com.brainybeam.roadsideassistance.User.Activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.RatingBar;

import com.brainybeam.roadsideassistance.R;
import com.brainybeam.roadsideassistance.RetrofitData.AdminRequestData;
import com.brainybeam.roadsideassistance.RetrofitData.CartAddServicesData;
import com.brainybeam.roadsideassistance.User.DashBoard.UserDashboardActivity;
import com.brainybeam.roadsideassistance.Utils.ApiClient;
import com.brainybeam.roadsideassistance.Utils.ApiInterface;
import com.brainybeam.roadsideassistance.Utils.CommonMethod;
import com.brainybeam.roadsideassistance.Utils.SharedPreferencesData;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class UserRatingActivity extends AppCompatActivity {

    RatingBar ratingBar;
    Button submitButton;
    String srating;

    ApiInterface apiInterface;
    SharedPreferences sp;
    ProgressDialog pd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_rating);
        getSupportActionBar().setTitle("Rating");
        ColorDrawable colorDrawable
                = new ColorDrawable(Color.parseColor("#2196F3"));
        getSupportActionBar().setBackgroundDrawable(colorDrawable);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        apiInterface = ApiClient.getClient().create(ApiInterface.class);
        sp = getSharedPreferences(SharedPreferencesData.PREF, MODE_PRIVATE);

        ratingBar = findViewById(R.id.user_rating_ratingBar);
        submitButton = findViewById(R.id.user_rating_submitButton);

        submitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                srating = String.valueOf(ratingBar.getRating());
                pd = new ProgressDialog(UserRatingActivity.this);
                pd.setTitle("Please Wait...");
                pd.setCancelable(false);
                pd.show();
                StoreRatingData();
                DeleteCartData();
            }
        });

    }

    private void DeleteCartData() {

        Call<CartAddServicesData> call = apiInterface.DeleteCartData(
                sp.getString(SharedPreferencesData.User_CartID, "")
        );

        call.enqueue(new Callback<CartAddServicesData>() {
            @Override
            public void onResponse(Call<CartAddServicesData> call, Response<CartAddServicesData> response) {

                pd.dismiss();
                if(response.code()==200){

                    if(response.body().status==true){
                        new CommonMethod(UserRatingActivity.this, UserDashboardActivity.class);
                        finish();
                    } else {
                        new CommonMethod(UserRatingActivity.this, response.body().message);
                    }

                } else {
                    new CommonMethod(UserRatingActivity.this, "Server Error Code : "+response.code());
                }

            }

            @Override
            public void onFailure(Call<CartAddServicesData> call, Throwable t) {
                pd.dismiss();
                new CommonMethod(UserRatingActivity.this, t.getMessage());
            }
        });

    }

    private void StoreRatingData() {

        Call<AdminRequestData> call = apiInterface.AddUserRatingData(
                sp.getString(SharedPreferencesData.User_ForemanID, ""),
                srating
        );

        call.enqueue(new Callback<AdminRequestData>() {
            @Override
            public void onResponse(Call<AdminRequestData> call, Response<AdminRequestData> response) {

                // pd.dismiss();
                if(response.code()==200){

                    if(response.body().status==true){
                        new CommonMethod(UserRatingActivity.this, "Thank you!");
                    } else {
                        new CommonMethod(UserRatingActivity.this, response.body().message);
                    }

                } else {
                    new CommonMethod(UserRatingActivity.this, "Server Error Code : "+response.code());
                }

            }

            @Override
            public void onFailure(Call<AdminRequestData> call, Throwable t) {
                pd.dismiss();
                new CommonMethod(UserRatingActivity.this, t.getMessage());
            }
        });

    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();
        if (id == android.R.id.home) {
            onBackPressed();
        }
        return super.onOptionsItemSelected(item);
    }


}