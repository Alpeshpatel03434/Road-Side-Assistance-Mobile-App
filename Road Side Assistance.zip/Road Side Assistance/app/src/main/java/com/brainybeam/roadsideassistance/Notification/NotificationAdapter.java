package com.brainybeam.roadsideassistance.Notification;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.SharedPreferences;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.brainybeam.roadsideassistance.R;
import com.brainybeam.roadsideassistance.RetrofitData.SendNotificationData;
import com.brainybeam.roadsideassistance.Utils.ApiInterface;
import com.brainybeam.roadsideassistance.Utils.CommonMethod;
import com.brainybeam.roadsideassistance.Utils.ConnectionDetector;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class NotificationAdapter extends RecyclerView.Adapter<NotificationAdapter.MyHolder> {

    Context context;
    ArrayList<NotificationList> arrayList;
    ApiInterface apiInterface;
    SharedPreferences sp;

    String sNotificationID;
    int iPosition;


    public NotificationAdapter(Context context, ArrayList<NotificationList> arrayList, ApiInterface apiInterface, SharedPreferences sp) {
        this.context = context;
        this.arrayList = arrayList;
        this.apiInterface = apiInterface;
        this.sp = sp;
    }

    @NonNull
    @Override
    public MyHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.custom_notification, parent, false);

        return new MyHolder(view);
    }

    public class MyHolder extends RecyclerView.ViewHolder {

        TextView title, message, date;
        CardView cardView;

        public MyHolder(@NonNull View itemView) {
            super(itemView);
            title = itemView.findViewById(R.id.custom_notification_title);
            message = itemView.findViewById(R.id.custom_notification_message);
            date = itemView.findViewById(R.id.custom_notification_date);
            cardView = itemView.findViewById(R.id.custom_notification_card);
        }
    }

    @Override
    public void onBindViewHolder(@NonNull MyHolder holder, @SuppressLint("RecyclerView") int position) {

        holder.title.setText(arrayList.get(position).getTitle());
        holder.message.setText(arrayList.get(position).getMessage());
        holder.date.setText(arrayList.get(position).getNotificationTime());

        if(arrayList.get(position).getMStatus().equalsIgnoreCase("Unread")){
            holder.cardView.setCardBackgroundColor(context.getResources().getColor(R.color.gray));
        }
        else{
            holder.cardView.setCardBackgroundColor(context.getResources().getColor(R.color.light_gray));
        }

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(new ConnectionDetector(context).isConnectingToInternet()){
                    sNotificationID = arrayList.get(position).getNotificationID();
                    iPosition = position;
                    updateNotificationData();
                }
                else{
                    new ConnectionDetector(context).connectiondetect();
                }
            }
        });

        holder.itemView.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                if(new ConnectionDetector(context).isConnectingToInternet()){
                    sNotificationID = arrayList.get(position).getNotificationID();
                    iPosition = position;
                    deleteNotificationData();
                }
                else{
                    new ConnectionDetector(context).connectiondetect();
                }
                return false;
            }
        });

    }

    @Override
    public int getItemCount() {
        return arrayList.size();
    }

    private void updateNotificationData() {

        Call<SendNotificationData> call = apiInterface.UpdateNotificationData(
                sNotificationID
        );

        call.enqueue(new Callback<SendNotificationData>() {
            @Override
            public void onResponse(Call<SendNotificationData> call, Response<SendNotificationData> response) {

                if(response.code()==200){

                    if(response.body().status==true){

                        NotificationList list = new NotificationList();
                        list.setNotificationID(arrayList.get(iPosition).getNotificationID());
                        list.setTitle(arrayList.get(iPosition).getTitle());
                        list.setMessage(arrayList.get(iPosition).getMessage());
                        list.setMStatus("Read");
                        list.setNotificationTime(arrayList.get(iPosition).getNotificationTime());
                        arrayList.set(iPosition,list);
                        notifyDataSetChanged();

                    } else {
                        new CommonMethod(context, response.body().message);
                    }

                } else {
                    new CommonMethod(context, "Server Error Code : "+response.code());
                }

            }

            @Override
            public void onFailure(Call<SendNotificationData> call, Throwable t) {
                new CommonMethod(context, t.getMessage());
            }
        });

    }

    private void deleteNotificationData() {

        Call<SendNotificationData> call = apiInterface.DeleteNotificationData(
                sNotificationID
        );

        call.enqueue(new Callback<SendNotificationData>() {
            @Override
            public void onResponse(Call<SendNotificationData> call, Response<SendNotificationData> response) {

                if(response.code()==200){

                    if(response.body().status==true){

                        arrayList.remove(iPosition);
                        notifyDataSetChanged();

                    } else {
                        new CommonMethod(context, response.body().message);
                    }

                } else {
                    new CommonMethod(context, "Server Error Code : "+response.code());
                }

            }

            @Override
            public void onFailure(Call<SendNotificationData> call, Throwable t) {
                new CommonMethod(context, t.getMessage());
            }
        });

    }


}
