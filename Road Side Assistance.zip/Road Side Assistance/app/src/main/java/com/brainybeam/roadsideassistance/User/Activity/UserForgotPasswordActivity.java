package com.brainybeam.roadsideassistance.User.Activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.brainybeam.roadsideassistance.Login.LoginActivity;
import com.brainybeam.roadsideassistance.R;
import com.brainybeam.roadsideassistance.RetrofitData.DeleteUserORForemanData;
import com.brainybeam.roadsideassistance.Utils.ApiClient;
import com.brainybeam.roadsideassistance.Utils.ApiInterface;
import com.brainybeam.roadsideassistance.Utils.CommonMethod;
import com.brainybeam.roadsideassistance.Utils.SharedPreferencesData;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class UserForgotPasswordActivity extends AppCompatActivity {

    EditText Password, ReEnterPassword;
    Button login;

    String sPassword, sPassword2;

    ApiInterface apiInterface;
    SharedPreferences sp;
    ProgressDialog pd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_forgot_password);
        getSupportActionBar().setTitle("Forgot Password");
        ColorDrawable colorDrawable
                = new ColorDrawable(Color.parseColor("#2196F3"));
        getSupportActionBar().setBackgroundDrawable(colorDrawable);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);


        apiInterface = ApiClient.getClient().create(ApiInterface.class);
        sp = getSharedPreferences(SharedPreferencesData.PREF, MODE_PRIVATE);

        Password = findViewById(R.id.user_forgot_password_PasswordEditText);
        ReEnterPassword = findViewById(R.id.user_forgot_password_ReEnterPasswordEditText);
        login = findViewById(R.id.user_forgot_password_LoginButton);

        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                sPassword = Password.getText().toString();
                sPassword2 = ReEnterPassword.getText().toString();

                if(sPassword.isEmpty() || sPassword.equalsIgnoreCase("")){
                    Password.setError("Password is Required");
                } else if(sPassword2.isEmpty() || sPassword2.equalsIgnoreCase("")){
                    ReEnterPassword.setError("Password is Required");
                } else if(sPassword.length()<8){
                    Password.setError("Password Must be 8 char long");
                } else if(!sPassword.equals(sPassword2)){
                    ReEnterPassword.setError("Password is Not Match");
                } else {

                    pd = new ProgressDialog(UserForgotPasswordActivity.this);
                    pd.setTitle("Password Resetting...");
                    pd.setCancelable(false);
                    pd.show();
                    PasswordUpdateData();

                }
            }
        });

    }

    private void PasswordUpdateData() {

        Call<DeleteUserORForemanData> call = apiInterface.UserForgotPassword(
                sp.getString(SharedPreferencesData.UserID, ""),
                sPassword
        );

        call.enqueue(new Callback<DeleteUserORForemanData>() {
            @Override
            public void onResponse(Call<DeleteUserORForemanData> call, Response<DeleteUserORForemanData> response) {

                pd.dismiss();
                if(response.code()==200){

                    if(response.body().status==true){
                        sp.edit().putString(SharedPreferencesData.Password, sPassword).commit();
                        new CommonMethod(UserForgotPasswordActivity.this, LoginActivity.class);
                        finish();
                    } else {
                        new CommonMethod(UserForgotPasswordActivity.this, response.body().message);
                    }

                } else {
                    new CommonMethod(UserForgotPasswordActivity.this, "Server Error Code : "+response.code());
                }

            }

            @Override
            public void onFailure(Call<DeleteUserORForemanData> call, Throwable t) {
                pd.dismiss();
                new CommonMethod(UserForgotPasswordActivity.this, t.getMessage());
            }
        });

    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();
        if (id == android.R.id.home) {
            onBackPressed();
        }
        return super.onOptionsItemSelected(item);
    }

}