package com.brainybeam.roadsideassistance.Foreman.DashBoard;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.brainybeam.roadsideassistance.R;
import com.brainybeam.roadsideassistance.RetrofitData.RatingData;
import com.brainybeam.roadsideassistance.Utils.ApiClient;
import com.brainybeam.roadsideassistance.Utils.ApiInterface;
import com.brainybeam.roadsideassistance.Utils.CommonMethod;
import com.brainybeam.roadsideassistance.Utils.ConnectionDetector;
import com.brainybeam.roadsideassistance.Utils.SharedPreferencesData;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


public class RatingFragment extends Fragment {

    CardView cardView1, cardView2;

    int ratingAboveFour, ratingAboveFourBetweenTwo, ratingLessThenTwo;

    ApiInterface apiInterface;
    SharedPreferences sp;
    ProgressDialog pd;

    TextView rating4, rating2to4, rating2;

    public RatingFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_rating, container, false);

        apiInterface = ApiClient.getClient().create(ApiInterface.class);
        sp = getActivity().getSharedPreferences(SharedPreferencesData.PREF, Context.MODE_PRIVATE);

        cardView2 = view.findViewById(R.id.frag_rating_CardView2);


        cardView2.setVisibility(View.VISIBLE);

        rating4 = view.findViewById(R.id.frag_rating_ratingFour_TextView);
        rating2to4 = view.findViewById(R.id.frag_rating_ratingBetween2to4_TextView);
        rating2 = view.findViewById(R.id.frag_rating_ratingLessThen2_TextView);

        ratingAboveFour = 0;
        ratingAboveFourBetweenTwo = 0;
        ratingLessThenTwo = 0;

        if(new ConnectionDetector(getActivity()).isConnectingToInternet()){

            pd = new ProgressDialog(getActivity());
            pd.setTitle("Please Wait...");
            pd.setCancelable(false);
            pd.show();

            GetRatingData();

        } else {
            new ConnectionDetector(getActivity()).connectiondetect();
        }

        if(sp.getString(SharedPreferencesData.Foreman_Rating_ratingAboveFour, "").equalsIgnoreCase("") || sp.getString(SharedPreferencesData.Foreman_Rating_ratingAboveFour, "").isEmpty()){
            rating4.setText("0+");
        } else {
            rating4.setText(sp.getString(SharedPreferencesData.Foreman_Rating_ratingAboveFour, "")+"+");
        }

        if(sp.getString(SharedPreferencesData.Foreman_Rating_ratingAboveFourBetweenTwo, "").equalsIgnoreCase("") || sp.getString(SharedPreferencesData.Foreman_Rating_ratingAboveFourBetweenTwo, "").isEmpty()){
            rating2to4.setText("0+");
        } else {
            rating2to4.setText(sp.getString(SharedPreferencesData.Foreman_Rating_ratingAboveFourBetweenTwo, "")+"+");
        }

        if(sp.getString(SharedPreferencesData.Foreman_Rating_ratingLessThenTwo, "").equalsIgnoreCase("") || sp.getString(SharedPreferencesData.Foreman_Rating_ratingLessThenTwo, "").isEmpty()){
            rating2.setText("0+");
        } else {
            rating2.setText(sp.getString(SharedPreferencesData.Foreman_Rating_ratingLessThenTwo, "")+"+");
        }

        return view;
    }

    private void GetRatingData() {

        Call<RatingData> call = apiInterface.GetUserRatingData(
                sp.getString(SharedPreferencesData.User_ForemanID, "")
        );

        call.enqueue(new Callback<RatingData>() {
            @Override
            public void onResponse(Call<RatingData> call, Response<RatingData> response) {

                pd.dismiss();
                if(response.code()==200){

                   if(response.body().status==true){

                       RatingData data = response.body();

                       for(int i=0; i<data.response.size(); i++){

                           if(2>Integer.valueOf(data.response.get(i).rating) ){
                               ratingLessThenTwo = ratingLessThenTwo + 1;
                           } else if(2<=Integer.valueOf(data.response.get(i).rating) && 4>Integer.valueOf(data.response.get(i).rating)){
                               ratingAboveFourBetweenTwo = ratingAboveFourBetweenTwo + 1;
                           } else {
                               ratingAboveFour = ratingAboveFour + 1;
                           }

                       }

                       sp.edit().putString(SharedPreferencesData.Foreman_Rating_ratingAboveFour, String.valueOf(ratingAboveFour)).commit();
                       sp.edit().putString(SharedPreferencesData.Foreman_Rating_ratingAboveFourBetweenTwo, String.valueOf(ratingAboveFourBetweenTwo)).commit();
                       sp.edit().putString(SharedPreferencesData.Foreman_Rating_ratingLessThenTwo, String.valueOf(ratingLessThenTwo)).commit();

                   } else {
                       new CommonMethod(getActivity(), response.body().message);
                   }

                } else {
                    new CommonMethod(getActivity(), "Server Error Code : "+response.code());
                }

            }

            @Override
            public void onFailure(Call<RatingData> call, Throwable t) {
                pd.dismiss();
                new CommonMethod(getActivity(), t.getMessage());
            }
        });

    }

}