package com.brainybeam.roadsideassistance.Foreman.CustomArrayList;

public class ServiceListData {

    String ServiceID;
    String ForemanID;
    String FirstName;
    String LastName;
    String ProfileImage;
    String MobileNumber;
    String TypeOfService;
    String ProblemSubType;
    String ServiceFixedCharge;

    public String getServiceID() {
        return ServiceID;
    }

    public void setServiceID(String serviceID) {
        ServiceID = serviceID;
    }

    public String getForemanID() {
        return ForemanID;
    }

    public void setForemanID(String foremanID) {
        ForemanID = foremanID;
    }

    public String getFirstName() {
        return FirstName;
    }

    public void setFirstName(String firstName) {
        FirstName = firstName;
    }

    public String getLastName() {
        return LastName;
    }

    public void setLastName(String lastName) {
        LastName = lastName;
    }

    public String getProfileImage() {
        return ProfileImage;
    }

    public void setProfileImage(String profileImage) {
        ProfileImage = profileImage;
    }

    public String getMobileNumber() {
        return MobileNumber;
    }

    public void setMobileNumber(String mobileNumber) {
        MobileNumber = mobileNumber;
    }

    public String getTypeOfService() {
        return TypeOfService;
    }

    public void setTypeOfService(String TypeOfService) {
        this.TypeOfService = TypeOfService;
    }

    public String getProblemSubType() {
        return ProblemSubType;
    }

    public void setProblemSubType(String ProblemSubType) {
        this.ProblemSubType = ProblemSubType;
    }

    public String getServiceFixedCharge() {
        return ServiceFixedCharge;
    }

    public void setServiceFixedCharge(String ServiceFixedCharge) {
        this.ServiceFixedCharge = ServiceFixedCharge;
    }
}
