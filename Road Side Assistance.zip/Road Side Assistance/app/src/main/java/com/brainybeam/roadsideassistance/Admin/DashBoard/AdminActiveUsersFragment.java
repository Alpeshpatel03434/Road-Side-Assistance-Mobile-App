package com.brainybeam.roadsideassistance.Admin.DashBoard;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.brainybeam.roadsideassistance.Admin.CustomArrayList.ActiveUsersList;
import com.brainybeam.roadsideassistance.R;
import com.brainybeam.roadsideassistance.RetrofitData.AdminActiveUsersData;
import com.brainybeam.roadsideassistance.Utils.ApiClient;
import com.brainybeam.roadsideassistance.Utils.ApiInterface;
import com.brainybeam.roadsideassistance.Utils.CommonMethod;
import com.brainybeam.roadsideassistance.Utils.ConnectionDetector;
import com.brainybeam.roadsideassistance.Utils.SharedPreferencesData;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


public class AdminActiveUsersFragment extends Fragment {

    RecyclerView recyclerView;

    ArrayList<ActiveUsersList> arrayList;

    ApiInterface apiInterface;
    SharedPreferences sp;
    ProgressDialog pd;

    public AdminActiveUsersFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_admin_active_users, container, false);

        apiInterface = ApiClient.getClient().create(ApiInterface.class);
        sp = getActivity().getSharedPreferences(SharedPreferencesData.PREF, Context.MODE_PRIVATE);

        recyclerView = view.findViewById(R.id.frag_admin_activeUser_recyclerView);

        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        recyclerView.setItemAnimator(new DefaultItemAnimator());

        if(new ConnectionDetector(getActivity()).isConnectingToInternet()){

            pd = new ProgressDialog(getActivity());
            pd.setMessage("Please Wait...");
            pd.setCancelable(false);
            pd.show();

            recyclerViewDataSetMethod();

        } else {
            new ConnectionDetector(getActivity()).connectiondetect();
        }


        return view;
    }

    private void recyclerViewDataSetMethod() {

        Call<AdminActiveUsersData> call = apiInterface.GetAdminActiveUsersData();

        call.enqueue(new Callback<AdminActiveUsersData>() {
            @Override
            public void onResponse(Call<AdminActiveUsersData> call, Response<AdminActiveUsersData> response) {

                pd.dismiss();
                if(response.code()==200){

                    if(response.body().status==true){

                        sp.edit().putString(SharedPreferencesData.Admin_NumberOfUsers, String.valueOf(response.body().numberOfRow)).commit();

                        //   new CommonMethod(getActivity(), response.body().message);
                        arrayList = new ArrayList<>();
                        AdminActiveUsersData data = response.body();

                        for(int i=0; i<data.response.size(); i++){

                            ActiveUsersList list = new ActiveUsersList();

                            list.setUserID(data.response.get(i).userID);
                            list.setUserType(data.response.get(i).userType);
                            list.setFirstName(data.response.get(i).firstName);
                            list.setLastName(data.response.get(i).lastName);
                            list.setProfileImage(data.response.get(i).profileImage);
                            list.setMobileNumber(data.response.get(i).mobileNumber);
                            list.setEmail(data.response.get(i).email);
                            list.setAccount_Status(data.response.get(i).accountStatus);
                            list.setCreated_time(data.response.get(i).createdTime);

                            arrayList.add(list);
                        }

                        AdminActiveUserAdapter adapter = new AdminActiveUserAdapter(getActivity(), arrayList);
                        recyclerView.setAdapter(adapter);
                        adapter.notifyDataSetChanged();

                    } else {
                        new CommonMethod(getActivity(), response.body().message);
                    }

                } else {
                    new CommonMethod(getActivity(), "Server Error Code : "+response.code());
                }

            }

            @Override
            public void onFailure(Call<AdminActiveUsersData> call, Throwable t) {
                pd.dismiss();
                new CommonMethod(getActivity(), t.getMessage());
            }
        });


    }

}