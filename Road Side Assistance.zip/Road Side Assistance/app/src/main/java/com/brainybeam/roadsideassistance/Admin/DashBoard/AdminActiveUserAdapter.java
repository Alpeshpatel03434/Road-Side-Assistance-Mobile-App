package com.brainybeam.roadsideassistance.Admin.DashBoard;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.brainybeam.roadsideassistance.Admin.CustomArrayList.ActiveUsersList;
import com.brainybeam.roadsideassistance.R;
import com.brainybeam.roadsideassistance.RetrofitData.DeleteUserORForemanData;
import com.brainybeam.roadsideassistance.RetrofitData.SendNotificationData;
import com.brainybeam.roadsideassistance.Utils.ApiClient;
import com.brainybeam.roadsideassistance.Utils.ApiInterface;
import com.brainybeam.roadsideassistance.Utils.CommonMethod;
import com.brainybeam.roadsideassistance.Utils.SharedPreferencesData;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

import de.hdodenhof.circleimageview.CircleImageView;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class AdminActiveUserAdapter extends RecyclerView.Adapter<AdminActiveUserAdapter.MyHolder> {

    Context context;
    ArrayList<ActiveUsersList> arrayList;

    ApiInterface apiInterface;
    SharedPreferences sp;
    ProgressDialog pd;

    int iPosition;


    public AdminActiveUserAdapter(Context context, ArrayList<ActiveUsersList> arrayList) {
        this.context = context;
        this.arrayList = arrayList;
    }

    @NonNull
    @Override
    public MyHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.custom_admin_active_users, parent, false);

        return new MyHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyHolder holder, @SuppressLint("RecyclerView") int position) {


        if (arrayList.get(position).getProfileImage().isEmpty() || arrayList.get(position).getProfileImage().equalsIgnoreCase("")){
            holder.circleImageView.setVisibility(View.GONE);
        } else {
            Picasso.with(context).load(arrayList.get(position).getProfileImage()).placeholder(R.drawable.ic_profile).into(holder.circleImageView);
        }

//        if(sp.getString(SharedPreferencesData.ProfileImage, "").equalsIgnoreCase("https://alpeshpatel-project.000webhostapp.com/RoadSideAssistance/UsersImages/")){
//
//        } else {
//            Picasso.with(context).load(sp.getString(SharedPreferencesData.ProfileImage, "")).placeholder(R.drawable.ic_profile).into(holder.circleImageView);
//        }

        holder.callingImageLogo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                AlertDialog.Builder builder = new AlertDialog.Builder(view.getContext());
                builder.setTitle("Call to User "+arrayList.get(position).getFirstName()+"?");
                builder.setPositiveButton("CALL", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        Intent intent = new Intent(Intent.ACTION_CALL);
                        intent.setData(Uri.parse("tel:"+"+91"+arrayList.get(position).getMobileNumber()));
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                            if (context.checkSelfPermission(Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
                                // TODO: Consider calling
                                //    Activity#requestPermissions
                                // here to request the missing permissions, and then overriding
                                //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
                                //                                          int[] grantResults)
                                // to handle the case where the user grants the permission. See the documentation
                                // for Activity#requestPermissions for more details.
                                return;
                            }
                        }
                        context.startActivity(intent);
                    }
                });

                builder.setNegativeButton("CANCEL", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        dialogInterface.dismiss();
                    }
                });

                builder.show();
            }
        });

        holder.Name.setText(arrayList.get(position).getFirstName()+" "+arrayList.get(position).getLastName());
        holder.MobileNumber.setText("+91 "+arrayList.get(position).getMobileNumber());
        holder.Email.setText(arrayList.get(position).getEmail());
        holder.AccountStatus.setText(arrayList.get(position).getAccount_Status());

        holder.DeActivateButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                iPosition = position;
                pd = new ProgressDialog(context);
                pd.setTitle("Please Wait...");
                pd.setCancelable(false);
                pd.show();
                DeactivateUserAccount();
                notifyDataSetChanged();
            }
        });


    }

    private void DeactivateUserAccount() {

        Call<DeleteUserORForemanData> call = apiInterface.DeactivateUserAccountData(
                arrayList.get(iPosition).getUserID()
        );

        call.enqueue(new Callback<DeleteUserORForemanData>() {
            @Override
            public void onResponse(Call<DeleteUserORForemanData> call, Response<DeleteUserORForemanData> response) {
               // pd.dismiss();
                if(response.code()==200){

                    if (response.body().status==true){
                        // new CommonMethod(context, response.body().message);
                        new CommonMethod(context, "Deactivate");
                        arrayList.remove(iPosition);
                        SendNotificationToDeactivateUser();
                        notifyDataSetChanged();
                    } else {
                        new CommonMethod(context, response.body().message);
                    }

                } else {
                    new CommonMethod(context, "Server Error Code "+response.code());
                }

            }

            @Override
            public void onFailure(Call<DeleteUserORForemanData> call, Throwable t) {
                pd.dismiss();
                new CommonMethod(context, t.getMessage());
            }
        });

    }

    private void SendNotificationToDeactivateUser() {

        String Title = "User "+arrayList.get(iPosition).getFirstName()+" your Account Deactivate";
        String Message = "Your Account (UserID-"+arrayList.get(iPosition).getUserID()+") Deactivate By Admin For Some Reason, \nPlease Contact Roadside Assistance Center OR Activate Again?";

        Call<SendNotificationData> call = apiInterface.SendToUserNotificationData(
                arrayList.get(iPosition).getUserID(),
                Title,
                Message
        );

        call.enqueue(new Callback<SendNotificationData>() {
            @Override
            public void onResponse(Call<SendNotificationData> call, Response<SendNotificationData> response) {

                pd.dismiss();
                if(response.code()==200){

                    if(response.body().status==true){
                       // new CommonMethod(context, response.body().message);
                    } else {
                        new CommonMethod(context, response.body().message);
                    }

                } else {
                    new CommonMethod(context, "Server Error Code : "+response.code());
                }

            }

            @Override
            public void onFailure(Call<SendNotificationData> call, Throwable t) {
                pd.dismiss();
                new CommonMethod(context, t.getMessage());
            }
        });


    }


    @Override
    public int getItemCount() {
        return arrayList.size();
    }

    public class MyHolder extends RecyclerView.ViewHolder {
        
        CircleImageView circleImageView;
        ImageView callingImageLogo;
        
        TextView Name, MobileNumber, Email, AccountStatus;
        Button DeActivateButton;
        
        public MyHolder(@NonNull View itemView) {
            super(itemView);

            apiInterface = ApiClient.getClient().create(ApiInterface.class);
            sp = context.getSharedPreferences(SharedPreferencesData.PREF, Context.MODE_PRIVATE);

            circleImageView = itemView.findViewById(R.id.custom_admin_active_users_ProfileImage);
            callingImageLogo = itemView.findViewById(R.id.custom_admin_active_users_calling_Image_logo);

            Name = itemView.findViewById(R.id.custom_admin_active_users_FirstANDLastName);
            MobileNumber = itemView.findViewById(R.id.custom_admin_active_users_MobileNumber);
            Email = itemView.findViewById(R.id.custom_admin_active_users_Email);
            AccountStatus = itemView.findViewById(R.id.custom_admin_active_users_AccountStatus);

            DeActivateButton = itemView.findViewById(R.id.custom_admin_active_users_DeActivateButton);


        }
    }
}
