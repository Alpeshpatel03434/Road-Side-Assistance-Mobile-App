package com.brainybeam.roadsideassistance;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.brainybeam.roadsideassistance.Login.LoginActivity;
import com.brainybeam.roadsideassistance.OTPVerification.OTPVerificationActivity;
import com.brainybeam.roadsideassistance.User.Signup.UserSignupActivity;
import com.brainybeam.roadsideassistance.Utils.ApiClient;
import com.brainybeam.roadsideassistance.Utils.ApiInterface;
import com.brainybeam.roadsideassistance.Utils.CommonMethod;
import com.brainybeam.roadsideassistance.Utils.SharedPreferencesData;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseApp;
import com.google.firebase.FirebaseException;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.PhoneAuthCredential;
import com.google.firebase.auth.PhoneAuthOptions;
import com.google.firebase.auth.PhoneAuthProvider;

import org.jetbrains.annotations.NotNull;

import java.util.concurrent.TimeUnit;

public class PleaseVerifyAccountActivity extends AppCompatActivity {

    LinearLayout EditTextLayout, OTPLayout;
    
    EditText MobileNumber, Email;
    Button GetOTPButton;
    
    EditText OTP;
    TextView ResendOTPTextButton, ResendLinkTextButton, EmailVerified;
    Button VerifyButton;

    String sMobileNumber, sEmail;
    Bundle bundle;
    String sPhone, sMail;
    private String EmailPattern = "[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+";

    private String sOTP;
    private String Mobile_VerificationID;

    private FirebaseAuth mAuth;
    private PhoneAuthProvider.OnVerificationStateChangedCallbacks mCallbacks;
    FirebaseApp firebaseApp;

    ApiInterface apiInterface;
    SharedPreferences sp;
    ProgressDialog pd;

    int count1 = 0;
    int count2 = 0;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_please_verify_account);

        firebaseApp = FirebaseApp.initializeApp(getApplicationContext());
        mAuth = FirebaseAuth.getInstance();
        apiInterface = ApiClient.getClient().create(ApiInterface.class);
        sp = getSharedPreferences(SharedPreferencesData.PREF, MODE_PRIVATE);

        EditTextLayout = findViewById(R.id.please_verify_account_EditLayout);
        OTPLayout = findViewById(R.id.please_verify_account_VerifyLayout);
        
        MobileNumber = findViewById(R.id.please_verify_account_MobileNumber);
        Email = findViewById(R.id.please_verify_account_Email);
        GetOTPButton = findViewById(R.id.please_verify_account_GetOTPButton);
        
        OTP = findViewById(R.id.please_verify_account_OTPMobileNumber);
        ResendOTPTextButton = findViewById(R.id.please_verify_account_ResendOTP);
        ResendLinkTextButton = findViewById(R.id.please_verify_account_ResendLink);
        EmailVerified = findViewById(R.id.please_verify_account_EmailVerify);
        VerifyButton = findViewById(R.id.please_verify_account_VerifyButton);
        
        GetOTPButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                sMobileNumber = MobileNumber.getText().toString();
                sEmail = Email.getText().toString();

                if(sMobileNumber.isEmpty() || sMobileNumber.equalsIgnoreCase("")){
                    MobileNumber.setError("Mobile Number is Required");
                } else if(sMobileNumber.length()>10 && sMobileNumber.length()<10){
                    MobileNumber.setError("Please Enter Valid Mobile number");
                } else if(sEmail.isEmpty() || sEmail.equalsIgnoreCase("")){
                    Email.setError("Email is Required");
                } else if(!sEmail.matches(EmailPattern)){
                    Email.setError("Please Enter Valid Email");
                } else {
                    EditTextLayout.setVisibility(View.GONE);
                    OTPLayout.setVisibility(View.VISIBLE);
                    pd = new ProgressDialog(PleaseVerifyAccountActivity.this);
                    pd.setTitle("OTP Generating");
                    pd.setCancelable(false);
                    pd.show();
                    bundle = new Bundle();
                    sPhone = sMobileNumber;
                    otpSendToMobile(sPhone);
                    sMail = sEmail;
                    otpSendToEmail(sMail);
                    pd.dismiss();
                }

            }
        });
        
        ResendOTPTextButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                otpSendToMobile(sMobileNumber);
            }
        });
        
        ResendLinkTextButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                otpSendToEmail(sEmail);
            }
        });
        
        VerifyButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                sOTP = OTP.getText().toString();
                if(sOTP.isEmpty() || sOTP.equalsIgnoreCase("")){
                    OTP.setError("OTP is Required");
                } else {
                    MobileVerifyingCheck();
                    EmailVerifyingCheck();
                    if(count1==count2){
                        new CommonMethod(PleaseVerifyAccountActivity.this, LoginActivity.class);
                    } else{
                        EditTextLayout.setVisibility(View.VISIBLE);
                        OTPLayout.setVisibility(View.GONE);
                        new CommonMethod(PleaseVerifyAccountActivity.this, "Not Valid");
                    }
                }
            }
        });
        
    }

    private void MobileVerifyingCheck() {

        PhoneAuthCredential credential = PhoneAuthProvider.getCredential(Mobile_VerificationID, sOTP);
        FirebaseAuth
                .getInstance()
                .signInWithCredential(credential)
                .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull @NotNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {

                            count1 = count1 + 1;
                            new CommonMethod(PleaseVerifyAccountActivity.this, "Congratulation SuccessFully Partially Verify");
                            new CommonMethod(PleaseVerifyAccountActivity.this, "Mobile Number Verified");

                        } else {
                            new CommonMethod(PleaseVerifyAccountActivity.this, "OTP is not Valid!");
                        }
                    }
                });
    }

    private void EmailVerifyingCheck() {
        FirebaseUser user = mAuth.getCurrentUser();

        if (user != null) {
            // TODO User is signed in
            count2 = count2 + 1;
            new CommonMethod(PleaseVerifyAccountActivity.this, "Email is Verified");
        } else {
            // TODO No user is signed in
            new CommonMethod(PleaseVerifyAccountActivity.this, "Email is Not Verified");
        }
    }


    private void otpSendToMobile(String sPhone) {

        mCallbacks = new PhoneAuthProvider.OnVerificationStateChangedCallbacks() {

            @Override
            public void onVerificationCompleted(PhoneAuthCredential credential) {

            }

            @Override
            public void onVerificationFailed(FirebaseException e) {
                pd.dismiss();
                new CommonMethod(PleaseVerifyAccountActivity.this, e.getLocalizedMessage());
            }

            @Override
            public void onCodeSent(@NonNull String VerificationId,
                                   @NonNull PhoneAuthProvider.ForceResendingToken token) {
                pd.dismiss();

                new CommonMethod(PleaseVerifyAccountActivity.this, "OTP is successFully Send");

                Mobile_VerificationID = VerificationId;
            }
        };

        PhoneAuthOptions options =
                PhoneAuthOptions.newBuilder(mAuth)
                        .setPhoneNumber("+91" + sPhone.trim())
                        .setTimeout(60L, TimeUnit.SECONDS)
                        .setActivity(this)
                        .setCallbacks(mCallbacks)
                        .build();
        PhoneAuthProvider.verifyPhoneNumber(options);

    }

    private void otpSendToEmail(String sMail) {

        mAuth.createUserWithEmailAndPassword(sMail, sp.getString(SharedPreferencesData.Password, "")).addOnCompleteListener(PleaseVerifyAccountActivity.this, new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {

                if (task.isSuccessful()) {
                    // TODO Sign in success, update UI with the signed-in user's information
                    FirebaseUser user = mAuth.getCurrentUser();

                    try {
                        if (user != null)
                            user.sendEmailVerification()
                                    .addOnCompleteListener(new OnCompleteListener<Void>() {
                                        @Override
                                        public void onComplete(@NonNull Task<Void> task) {
                                            if (task.isSuccessful()) {

                                                AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(
                                                        PleaseVerifyAccountActivity.this);

                                                // set title
                                                alertDialogBuilder.setTitle("Please Verify Your EmailID");

                                                // set dialog message
                                                alertDialogBuilder
                                                        .setMessage("A verification Email Is Sent To Your Registered EmailID, please click on the link and Sign in again!")
                                                        .setCancelable(false)
                                                        .setPositiveButton("Sign In", new DialogInterface.OnClickListener() {
                                                            public void onClick(DialogInterface dialog, int id) {

                                                            }
                                                        });

                                                // create alert dialog
                                                AlertDialog alertDialog = alertDialogBuilder.create();

                                                // show it
                                                alertDialog.show();

                                            }
                                        }
                                    });


                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                } else {
                    // TODO If sign in fails, display a message to the user.
                    new CommonMethod(PleaseVerifyAccountActivity.this, "Authentication failed");

                    if (task.getException() != null) {
                        new CommonMethod(PleaseVerifyAccountActivity.this, task.getException().getMessage());
                    }

                }

            }
        });



    }


}