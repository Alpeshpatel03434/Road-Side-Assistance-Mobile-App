package com.brainybeam.roadsideassistance.Login;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.brainybeam.roadsideassistance.Admin.AdminCredential.AdminCredential;
import com.brainybeam.roadsideassistance.Admin.DashBoard.AdminDashboardActivity;
import com.brainybeam.roadsideassistance.Foreman.Activity.ForemanEnableActivity;
import com.brainybeam.roadsideassistance.Foreman.Activity.ForemanForgotPasswordActivity;
import com.brainybeam.roadsideassistance.Foreman.DashBoard.ForemanDashboardActivity;
import com.brainybeam.roadsideassistance.Foreman.Signup.ForemanSignupActivity;
import com.brainybeam.roadsideassistance.GPS.GPSTracker;
import com.brainybeam.roadsideassistance.Notification.PushNotification.Config;
import com.brainybeam.roadsideassistance.PleaseVerifyAccountActivity;
import com.brainybeam.roadsideassistance.R;
import com.brainybeam.roadsideassistance.RetrofitData.ForemanLoginData;
import com.brainybeam.roadsideassistance.RetrofitData.UpdateFCMIDData;
import com.brainybeam.roadsideassistance.RetrofitData.UserANDForemanLoginData;
import com.brainybeam.roadsideassistance.RetrofitData.UserLoginData;
import com.brainybeam.roadsideassistance.RetrofitData.SwitchAccountData;
import com.brainybeam.roadsideassistance.User.Activity.UserEnableActivity;
import com.brainybeam.roadsideassistance.User.Activity.UserForgotPasswordActivity;
import com.brainybeam.roadsideassistance.User.DashBoard.UserDashboardActivity;
import com.brainybeam.roadsideassistance.User.Signup.UserSignupActivity;
import com.brainybeam.roadsideassistance.Utils.ApiClient;
import com.brainybeam.roadsideassistance.Utils.ApiInterface;
import com.brainybeam.roadsideassistance.Utils.CommonMethod;
import com.brainybeam.roadsideassistance.Utils.ConnectionDetector;
import com.brainybeam.roadsideassistance.Utils.SharedPreferencesData;
import com.google.android.gms.common.SignInButton;
import com.google.firebase.iid.FirebaseInstanceId;
import com.google.firebase.messaging.FirebaseMessaging;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class LoginActivity extends AppCompatActivity {

    private EditText EmailORMobile, Password;
    private TextView ForgotPassword, Signup;
    private Button Login;
    private SignInButton signInButton;

    private ArrayList<String> AdminEmail;
    private ArrayList<String> AdminPassword;

    private String EmailPattern = "[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+";

    String sEmailORMobile, sPassword;

    SharedPreferences sp;
    ProgressDialog pd;
    GPSTracker gpsTracker;
    ApiInterface apiInterface;

    // TODO FCMID For Notification
    BroadcastReceiver broadcastReceiver;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        int or = getResources().getConfiguration().orientation;
        if(or== Configuration.ORIENTATION_LANDSCAPE){
            getSupportActionBar().hide();
        } else {
//            getSupportActionBar().show();
//            getSupportActionBar().setTitle("Login");
//            getSupportActionBar().setDisplayShowHomeEnabled(true);
//            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }

        gpsTracker = new GPSTracker(LoginActivity.this);
        apiInterface = ApiClient.getClient().create(ApiInterface.class);
        sp = getSharedPreferences(SharedPreferencesData.PREF, MODE_PRIVATE);

        AdminEmail = new ArrayList<>();
        AdminPassword = new ArrayList<>();

        List<String> list1 = Arrays.asList(AdminCredential.AdminEmail);
        List<String> list2 = Arrays.asList(AdminCredential.AdminPassword);
        AdminEmail.addAll(list1);
        AdminPassword.addAll(list2);

        EmailORMobile = findViewById(R.id.login_EmailORMobile);
        Password = findViewById(R.id.login_Password);
        ForgotPassword = findViewById(R.id.login_forgotPassword);
        Login = findViewById(R.id.login_loginButton);
        Signup = findViewById(R.id.login_signupButton);
      //  signInButton = findViewById(R.id.login_googleSignIn);

        // Check if GPS enabled
        if(gpsTracker.canGetLocation()) {
        } else {
            // Can't get location.
            // GPS or network is not enabled.
            // Ask user to enable GPS/network in settings.
            gpsTracker.showSettingsAlert();
        }

        Login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                sEmailORMobile = EmailORMobile.getText().toString();
                sPassword = Password.getText().toString();

                if(sEmailORMobile.isEmpty() || sEmailORMobile.equalsIgnoreCase(" ")){
                    EmailORMobile.setError("Email OR Mobile Number is Required");
                } else if (!sEmailORMobile.matches(EmailPattern) && sEmailORMobile.length()<10 && sEmailORMobile.length()>10){
                    EmailORMobile.setError("Valid Email OR Mobile Number is Required");
                } else if(sPassword.isEmpty() || sPassword.equalsIgnoreCase(" ")){
                    Password.setError("Password is Required");
                } else if(AdminEmail.contains(sEmailORMobile) && AdminPassword.contains(sPassword)){
                    AdminFCMIDStore();
                    sp.edit().putString(SharedPreferencesData.AdminLoginState, "AdminLogin").commit();
                    new CommonMethod(LoginActivity.this, AdminDashboardActivity.class);
                    finish();
                } else {

                    if(new ConnectionDetector(LoginActivity.this).isConnectingToInternet()){

                        pd = new ProgressDialog(LoginActivity.this);
                        pd.setTitle("Please Wait...");
                        pd.setCancelable(false);
                        pd.show();

                        LoginMethod(sEmailORMobile, sPassword);


                    } else {
                        new ConnectionDetector(LoginActivity.this).connectiondetect();
                    }


                }

            }
        });


        Signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder alertDialog = new AlertDialog.Builder(LoginActivity.this);

                alertDialog.setPositiveButton("Signup As User", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        new CommonMethod(LoginActivity.this, UserSignupActivity.class);
                    }
                });
                alertDialog.setNeutralButton("Signup As Foreman", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        new CommonMethod(LoginActivity.this, ForemanSignupActivity.class);
                    }
                });
                alertDialog.show();

            }
        });


    }

    private void AdminFCMIDStore() {

        getAdminToken();

    }

    // TODO Login Method Start
    public void LoginMethod(String sEmailORMobile, String sPassword) {

        Call<SwitchAccountData> call = apiInterface.SwitchAccountData(
                sEmailORMobile
        );

        call.enqueue(new Callback<SwitchAccountData>() {
            @Override
            public void onResponse(Call<SwitchAccountData> call, Response<SwitchAccountData> response) {

                if(response.code()==200){

                    if(response.body().message.equalsIgnoreCase("Switch")){

                        AlertDialog.Builder alertDialog = new AlertDialog.Builder(LoginActivity.this);
                        pd.dismiss();

                        alertDialog.setPositiveButton("Login as a User", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {

                                Call<UserLoginData> call1 = apiInterface.UserLoginData(
                                        sEmailORMobile, sPassword
                                );

                                call1.enqueue(new Callback<UserLoginData>() {
                                    @Override
                                    public void onResponse(Call<UserLoginData> call, Response<UserLoginData> response) {

                                        if(response.code()==200){

                                            if(response.body().status.equalsIgnoreCase("True")){

                                                new CommonMethod(LoginActivity.this, response.body().message);

                                                UserLoginData data = response.body();

                                                for(int i=0; i<data.response.size(); i++){
                                                    sp.edit().putString(SharedPreferencesData.UserType, data.response.get(i).userType).commit();
                                                    sp.edit().putString(SharedPreferencesData.UserID, data.response.get(i).userID).commit();
                                                    sp.edit().putString(SharedPreferencesData.FirstName, data.response.get(i).firstName).commit();
                                                    sp.edit().putString(SharedPreferencesData.LastName, data.response.get(i).lastName).commit();
                                                    sp.edit().putString(SharedPreferencesData.ProfileImage, data.response.get(i).profileImage).commit();
                                                    sp.edit().putString(SharedPreferencesData.MobileNumber, data.response.get(i).mobileNumber).commit();
                                                    sp.edit().putString(SharedPreferencesData.Email, data.response.get(i).email).commit();
                                                    sp.edit().putString(SharedPreferencesData.Password, data.response.get(i).password).commit();
                                                    sp.edit().putString(SharedPreferencesData.Account_Status, data.response.get(i).accountStatus).commit();
                                                }

                                                // TODO Notification FCMID
                                                broadcastReceiver = new BroadcastReceiver() {
                                                    @Override
                                                    public void onReceive(Context context, Intent intent) {
                                                        if (intent.getAction().equals(Config.REGISTRATION_COMPLETE)) {
                                                            FirebaseMessaging.getInstance().subscribeToTopic(Config.TOPIC_GLOBAL);
                                                            getUserToken();
                                                        } else if (intent.getAction().equals(Config.PUSH_NOTIFICATION)) {
                                                            String s = intent.getStringExtra("message");
                                                        } else {
                                                        }
                                                    }
                                                };
                                                getUserToken();

                                                new CommonMethod(LoginActivity.this, UserDashboardActivity.class);
                                                finish();

                                            } else if(response.body().status.equalsIgnoreCase("Pending")){

                                                new CommonMethod(LoginActivity.this, response.body().message);

                                                UserLoginData data = response.body();

                                                for(int i=0; i<data.response.size(); i++){
                                                    sp.edit().putString(SharedPreferencesData.UserType, data.response.get(i).userType).commit();
                                                    sp.edit().putString(SharedPreferencesData.UserID, data.response.get(i).userID).commit();
                                                    sp.edit().putString(SharedPreferencesData.FirstName, data.response.get(i).firstName).commit();
                                                    sp.edit().putString(SharedPreferencesData.LastName, data.response.get(i).lastName).commit();
                                                    sp.edit().putString(SharedPreferencesData.ProfileImage, data.response.get(i).profileImage).commit();
                                                    sp.edit().putString(SharedPreferencesData.MobileNumber, data.response.get(i).mobileNumber).commit();
                                                    sp.edit().putString(SharedPreferencesData.Email, data.response.get(i).email).commit();
                                                    sp.edit().putString(SharedPreferencesData.Password, data.response.get(i).password).commit();
                                                    sp.edit().putString(SharedPreferencesData.Account_Status, data.response.get(i).accountStatus).commit();
                                                }


                                                new CommonMethod(LoginActivity.this, PleaseVerifyAccountActivity.class);
                                                finish();
                                            } else {
                                              //  new CommonMethod(LoginActivity.this, response.body().message);
                                                UserEnableLogin();
                                            }


                                        } else {
                                            new CommonMethod(LoginActivity.this, "Server Error Code : "+response.code());
                                        }

                                    }

                                    @Override
                                    public void onFailure(Call<UserLoginData> call, Throwable t) {
                                        new CommonMethod(LoginActivity.this, t.getMessage());
                                    }

                                });

                            }
                        });


                        alertDialog.setNeutralButton("Login as a Foreman", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {

                                Call<ForemanLoginData> call1 = apiInterface.ForemanLoginData(
                                        sEmailORMobile, sPassword
                                );

                                call1.enqueue(new Callback<ForemanLoginData>() {
                                    @Override
                                    public void onResponse(Call<ForemanLoginData> call, Response<ForemanLoginData> response) {

                                        if(response.code()==200) {

                                            if(response.body().status.equalsIgnoreCase("True")) {

                                                new CommonMethod(LoginActivity.this, response.body().message);

                                                ForemanLoginData data = response.body();

                                                for(int i=0; i<data.response.size(); i++){
                                                    sp.edit().putString(SharedPreferencesData.UserType, data.response.get(i).userType).commit();
                                                    sp.edit().putString(SharedPreferencesData.UserID, data.response.get(i).foremanID).commit();
                                                    sp.edit().putString(SharedPreferencesData.FirstName, data.response.get(i).firstName).commit();
                                                    sp.edit().putString(SharedPreferencesData.LastName, data.response.get(i).lastName).commit();
                                                    sp.edit().putString(SharedPreferencesData.ProfileImage, data.response.get(i).profileImage).commit();
                                                    sp.edit().putString(SharedPreferencesData.MobileNumber, data.response.get(i).mobileNumber).commit();
                                                    sp.edit().putString(SharedPreferencesData.Email, data.response.get(i).email).commit();
                                                    sp.edit().putString(SharedPreferencesData.Password, data.response.get(i).password).commit();
                                                    sp.edit().putString(SharedPreferencesData.ForemanAddress, data.response.get(i).address).commit();
                                                    sp.edit().putString(SharedPreferencesData.ForemanArea, data.response.get(i).area).commit();
                                                    sp.edit().putString(SharedPreferencesData.ForemanCity, data.response.get(i).city).commit();
                                                    sp.edit().putString(SharedPreferencesData.ForemanState, data.response.get(i).state).commit();
                                                    sp.edit().putString(SharedPreferencesData.Account_Status, data.response.get(i).accountStatus).commit();
                                                }

                                                // TODO Notification FCMID
                                                broadcastReceiver = new BroadcastReceiver() {
                                                    @Override
                                                    public void onReceive(Context context, Intent intent) {
                                                        if (intent.getAction().equals(Config.REGISTRATION_COMPLETE)) {
                                                            FirebaseMessaging.getInstance().subscribeToTopic(Config.TOPIC_GLOBAL);
                                                            getForemanToken();
                                                        } else if (intent.getAction().equals(Config.PUSH_NOTIFICATION)) {
                                                            String s = intent.getStringExtra("message");
                                                        } else {
                                                        }
                                                    }
                                                };
                                                getForemanToken();

                                                new CommonMethod(LoginActivity.this, ForemanDashboardActivity.class);
                                                finish();

                                            } else if(response.body().status.equalsIgnoreCase("Pending")) {

                                                new CommonMethod(LoginActivity.this, response.body().message);

                                                ForemanLoginData data = response.body();

                                                for(int i=0; i<data.response.size(); i++){
                                                    sp.edit().putString(SharedPreferencesData.UserType, data.response.get(i).userType).commit();
                                                    sp.edit().putString(SharedPreferencesData.UserID, data.response.get(i).foremanID).commit();
                                                    sp.edit().putString(SharedPreferencesData.FirstName, data.response.get(i).firstName).commit();
                                                    sp.edit().putString(SharedPreferencesData.LastName, data.response.get(i).lastName).commit();
                                                    sp.edit().putString(SharedPreferencesData.ProfileImage, data.response.get(i).profileImage).commit();
                                                    sp.edit().putString(SharedPreferencesData.MobileNumber, data.response.get(i).mobileNumber).commit();
                                                    sp.edit().putString(SharedPreferencesData.Email, data.response.get(i).email).commit();
                                                    sp.edit().putString(SharedPreferencesData.Password, data.response.get(i).password).commit();
                                                    sp.edit().putString(SharedPreferencesData.ForemanAddress, data.response.get(i).address).commit();
                                                    sp.edit().putString(SharedPreferencesData.ForemanArea, data.response.get(i).area).commit();
                                                    sp.edit().putString(SharedPreferencesData.ForemanCity, data.response.get(i).city).commit();
                                                    sp.edit().putString(SharedPreferencesData.ForemanState, data.response.get(i).state).commit();
                                                    sp.edit().putString(SharedPreferencesData.Account_Status, data.response.get(i).accountStatus).commit();
                                                }

                                                new CommonMethod(LoginActivity.this, PleaseVerifyAccountActivity.class);
                                                finish();

                                            } else {
                                              //  new CommonMethod(LoginActivity.this, response.body().message);
                                                ForemanEnableLogin();
                                            }

                                        } else {
                                            new CommonMethod(LoginActivity.this, "Server Error Code : "+response.code());
                                        }

                                    }

                                    @Override
                                    public void onFailure(Call<ForemanLoginData> call, Throwable t) {
                                        new CommonMethod(LoginActivity.this, t.getMessage());
                                    }
                                });

                            }
                        });

                        alertDialog.show();
                        // TODO Switch End

                    } else {

                        // TODO Not SWitch

                        Call<UserANDForemanLoginData> call1 = apiInterface.UserANDForemanLoginData(
                                sEmailORMobile, sPassword
                        );

                        call1.enqueue(new Callback<UserANDForemanLoginData>() {
                            @Override
                            public void onResponse(Call<UserANDForemanLoginData> call, Response<UserANDForemanLoginData> response) {
                                pd.dismiss();
                                if(response.code()==200) {

                                    if(response.body().status.equalsIgnoreCase("User")) {

                                        new CommonMethod(LoginActivity.this, response.body().message);

                                        UserANDForemanLoginData data = response.body();

                                        for(int i=0; i<data.response.size(); i++){
                                            String userID = data.response.get(i).foremanID;
                                            sp.edit().putString(SharedPreferencesData.UserType, data.response.get(i).userType).commit();
                                            sp.edit().putString(SharedPreferencesData.UserID, userID).commit();
                                            sp.edit().putString(SharedPreferencesData.FirstName, data.response.get(i).firstName).commit();
                                            sp.edit().putString(SharedPreferencesData.LastName, data.response.get(i).lastName).commit();
                                            sp.edit().putString(SharedPreferencesData.ProfileImage, data.response.get(i).profileImage).commit();
                                            sp.edit().putString(SharedPreferencesData.MobileNumber, data.response.get(i).mobileNumber).commit();
                                            sp.edit().putString(SharedPreferencesData.Email, data.response.get(i).email).commit();
                                            sp.edit().putString(SharedPreferencesData.Password, data.response.get(i).password).commit();
                                            sp.edit().putString(SharedPreferencesData.Account_Status, data.response.get(i).accountStatus).commit();
                                        }


                                        // TODO Notification FCMID
                                        broadcastReceiver = new BroadcastReceiver() {
                                            @Override
                                            public void onReceive(Context context, Intent intent) {
                                                if (intent.getAction().equals(Config.REGISTRATION_COMPLETE)) {
                                                    FirebaseMessaging.getInstance().subscribeToTopic(Config.TOPIC_GLOBAL);
                                                    getUserToken();
                                                } else if (intent.getAction().equals(Config.PUSH_NOTIFICATION)) {
                                                    String s = intent.getStringExtra("message");
                                                } else {
                                                }
                                            }
                                        };
                                        getUserToken();

                                        new CommonMethod(LoginActivity.this, UserDashboardActivity.class);


                                    } else if(response.body().status.equalsIgnoreCase("Foreman")) {


                                        new CommonMethod(LoginActivity.this, response.body().message);

                                        UserANDForemanLoginData data = response.body();

                                        for(int i=0; i<data.response.size(); i++){
                                            sp.edit().putString(SharedPreferencesData.UserType, data.response.get(i).userType).commit();
                                            sp.edit().putString(SharedPreferencesData.UserID, data.response.get(i).foremanID).commit();
                                            sp.edit().putString(SharedPreferencesData.FirstName, data.response.get(i).firstName).commit();
                                            sp.edit().putString(SharedPreferencesData.LastName, data.response.get(i).lastName).commit();
                                            sp.edit().putString(SharedPreferencesData.ProfileImage, data.response.get(i).profileImage).commit();
                                            sp.edit().putString(SharedPreferencesData.MobileNumber, data.response.get(i).mobileNumber).commit();
                                            sp.edit().putString(SharedPreferencesData.Email, data.response.get(i).email).commit();
                                            sp.edit().putString(SharedPreferencesData.Password, data.response.get(i).password).commit();
                                            sp.edit().putString(SharedPreferencesData.ForemanAddress, data.response.get(i).address).commit();
                                            sp.edit().putString(SharedPreferencesData.ForemanArea, data.response.get(i).area).commit();
                                            sp.edit().putString(SharedPreferencesData.ForemanCity, data.response.get(i).city).commit();
                                            sp.edit().putString(SharedPreferencesData.ForemanState, data.response.get(i).state).commit();
                                            sp.edit().putString(SharedPreferencesData.Account_Status, data.response.get(i).accountStatus).commit();
                                        }


                                        // TODO Notification FCMID
                                        broadcastReceiver = new BroadcastReceiver() {
                                            @Override
                                            public void onReceive(Context context, Intent intent) {
                                                if (intent.getAction().equals(Config.REGISTRATION_COMPLETE)) {
                                                    FirebaseMessaging.getInstance().subscribeToTopic(Config.TOPIC_GLOBAL);
                                                    getForemanToken();
                                                } else if (intent.getAction().equals(Config.PUSH_NOTIFICATION)) {
                                                    String s = intent.getStringExtra("message");
                                                } else {
                                                }
                                            }
                                        };
                                        getForemanToken();

                                        new CommonMethod(LoginActivity.this, ForemanDashboardActivity.class);



                                    } else if(response.body().status.equalsIgnoreCase("UserPending")) {

                                        new CommonMethod(LoginActivity.this, response.body().message);

                                        UserANDForemanLoginData data = response.body();

                                        for(int i=0; i<data.response.size(); i++){
                                            String userID = data.response.get(i).foremanID;
                                            sp.edit().putString(SharedPreferencesData.UserType, data.response.get(i).userType).commit();
                                            sp.edit().putString(SharedPreferencesData.UserID, userID).commit();
                                            sp.edit().putString(SharedPreferencesData.FirstName, data.response.get(i).firstName).commit();
                                            sp.edit().putString(SharedPreferencesData.LastName, data.response.get(i).lastName).commit();
                                            sp.edit().putString(SharedPreferencesData.ProfileImage, data.response.get(i).profileImage).commit();
                                            sp.edit().putString(SharedPreferencesData.MobileNumber, data.response.get(i).mobileNumber).commit();
                                            sp.edit().putString(SharedPreferencesData.Email, data.response.get(i).email).commit();
                                            sp.edit().putString(SharedPreferencesData.Password, data.response.get(i).password).commit();
                                            sp.edit().putString(SharedPreferencesData.Account_Status, data.response.get(i).accountStatus).commit();
                                        }

                                        new CommonMethod(LoginActivity.this, PleaseVerifyAccountActivity.class);

                                    }
                                    else if(response.body().status.equalsIgnoreCase("ForemanPending")) {

                                        new CommonMethod(LoginActivity.this, response.body().message);

                                        UserANDForemanLoginData data = response.body();

                                        for(int i=0; i<data.response.size(); i++){
                                            sp.edit().putString(SharedPreferencesData.UserType, data.response.get(i).userType).commit();
                                            sp.edit().putString(SharedPreferencesData.UserID, data.response.get(i).foremanID).commit();
                                            sp.edit().putString(SharedPreferencesData.FirstName, data.response.get(i).firstName).commit();
                                            sp.edit().putString(SharedPreferencesData.LastName, data.response.get(i).lastName).commit();
                                            sp.edit().putString(SharedPreferencesData.ProfileImage, data.response.get(i).profileImage).commit();
                                            sp.edit().putString(SharedPreferencesData.MobileNumber, data.response.get(i).mobileNumber).commit();
                                            sp.edit().putString(SharedPreferencesData.Email, data.response.get(i).email).commit();
                                            sp.edit().putString(SharedPreferencesData.Password, data.response.get(i).password).commit();
                                            sp.edit().putString(SharedPreferencesData.ForemanAddress, data.response.get(i).address).commit();
                                            sp.edit().putString(SharedPreferencesData.ForemanArea, data.response.get(i).area).commit();
                                            sp.edit().putString(SharedPreferencesData.ForemanCity, data.response.get(i).city).commit();
                                            sp.edit().putString(SharedPreferencesData.ForemanState, data.response.get(i).state).commit();
                                            sp.edit().putString(SharedPreferencesData.Account_Status, data.response.get(i).accountStatus).commit();
                                        }

                                        new CommonMethod(LoginActivity.this, PleaseVerifyAccountActivity.class);


                                    } else {
                                       // new CommonMethod(LoginActivity.this, response.body().message);
                                        UserForemanEnableLogin();
                                    }

                                } else {
                                    new CommonMethod(LoginActivity.this, "Server Error Code : "+response.code());
                                }

                            }

                            @Override
                            public void onFailure(Call<UserANDForemanLoginData> call, Throwable t) {
                                pd.dismiss();
                                new CommonMethod(LoginActivity.this, t.getMessage());
                            }
                        });


                    }

                } else {
                    new CommonMethod(LoginActivity.this, "Server Error Code : "+response.code());
                }

            }

            @Override
            public void onFailure(Call<SwitchAccountData> call, Throwable t) {
                new CommonMethod(LoginActivity.this, t.getMessage());
            }
        });

    }
    // TODO Login Method End














    private void UserEnableLogin(){

        Call<UserLoginData> call = apiInterface.UserEnableLoginData(
                sEmailORMobile, sPassword
        );

        call.enqueue(new Callback<UserLoginData>() {
            @Override
            public void onResponse(Call<UserLoginData> call, Response<UserLoginData> response) {

                if (response.code() == 200) {

                    if (response.body().status.equalsIgnoreCase("True")) {

                        new CommonMethod(LoginActivity.this, response.body().message);

                        UserLoginData data = response.body();

                        for (int i = 0; i < data.response.size(); i++) {
                            String userID = data.response.get(i).userID;
                           // sp.edit().putString(SharedPreferencesData.UserType, data.response.get(i).userType).commit();
                            sp.edit().putString(SharedPreferencesData.UserID, userID).commit();
                            sp.edit().putString(SharedPreferencesData.FirstName, data.response.get(i).firstName).commit();
                            sp.edit().putString(SharedPreferencesData.LastName, data.response.get(i).lastName).commit();
                            sp.edit().putString(SharedPreferencesData.ProfileImage, data.response.get(i).profileImage).commit();
                            sp.edit().putString(SharedPreferencesData.MobileNumber, data.response.get(i).mobileNumber).commit();
                            sp.edit().putString(SharedPreferencesData.Email, data.response.get(i).email).commit();
                            sp.edit().putString(SharedPreferencesData.Password, data.response.get(i).password).commit();
                            sp.edit().putString(SharedPreferencesData.Account_Status, data.response.get(i).accountStatus).commit();

                            sp.edit().putString(SharedPreferencesData.UserEnable, "UserEnable").commit();

                        }


                        // TODO Notification FCMID
                        broadcastReceiver = new BroadcastReceiver() {
                            @Override
                            public void onReceive(Context context, Intent intent) {
                                if (intent.getAction().equals(Config.REGISTRATION_COMPLETE)) {
                                    FirebaseMessaging.getInstance().subscribeToTopic(Config.TOPIC_GLOBAL);
                                    getUserToken();
                                } else if (intent.getAction().equals(Config.PUSH_NOTIFICATION)) {
                                    String s = intent.getStringExtra("message");
                                } else {
                                }
                            }
                        };
                        getUserToken();

                        new CommonMethod(LoginActivity.this, UserEnableActivity.class);
                        finish();
                    } else {
                        new CommonMethod(LoginActivity.this, response.body().message);
                    }

                } else {
                    new CommonMethod(LoginActivity.this, "Server Error Code : " + response.code());
                }

            }

            @Override
            public void onFailure(Call<UserLoginData> call, Throwable t) {
                pd.dismiss();
                new CommonMethod(LoginActivity.this, t.getMessage());
            }
        });

    }

    private void ForemanEnableLogin(){

        Call<ForemanLoginData> call = apiInterface.ForemanEnableLoginData(
                sEmailORMobile, sPassword
        );

        call.enqueue(new Callback<ForemanLoginData>() {
            @Override
            public void onResponse(Call<ForemanLoginData> call, Response<ForemanLoginData> response) {

                if (response.code() == 200) {

                    if (response.body().status.equalsIgnoreCase("True")) {

                        new CommonMethod(LoginActivity.this, response.body().message);

                        ForemanLoginData data = response.body();

                        for (int i = 0; i < data.response.size(); i++) {
                            String userID = data.response.get(i).foremanID;
                          //  sp.edit().putString(SharedPreferencesData.UserType, data.response.get(i).userType).commit();
                            sp.edit().putString(SharedPreferencesData.UserID, userID).commit();
                            sp.edit().putString(SharedPreferencesData.FirstName, data.response.get(i).firstName).commit();
                            sp.edit().putString(SharedPreferencesData.LastName, data.response.get(i).lastName).commit();
                            sp.edit().putString(SharedPreferencesData.ProfileImage, data.response.get(i).profileImage).commit();
                            sp.edit().putString(SharedPreferencesData.MobileNumber, data.response.get(i).mobileNumber).commit();
                            sp.edit().putString(SharedPreferencesData.Email, data.response.get(i).email).commit();
                            sp.edit().putString(SharedPreferencesData.Password, data.response.get(i).password).commit();
                            sp.edit().putString(SharedPreferencesData.ForemanAddress, data.response.get(i).address).commit();
                            sp.edit().putString(SharedPreferencesData.ForemanArea, data.response.get(i).area).commit();
                            sp.edit().putString(SharedPreferencesData.ForemanCity, data.response.get(i).city).commit();
                            sp.edit().putString(SharedPreferencesData.ForemanState, data.response.get(i).state).commit();
                            sp.edit().putString(SharedPreferencesData.Account_Status, data.response.get(i).accountStatus).commit();

                            sp.edit().putString(SharedPreferencesData.ForemanEnable, "ForemanEnable").commit();
                        }


                        // TODO Notification FCMID
                        broadcastReceiver = new BroadcastReceiver() {
                            @Override
                            public void onReceive(Context context, Intent intent) {
                                if (intent.getAction().equals(Config.REGISTRATION_COMPLETE)) {
                                    FirebaseMessaging.getInstance().subscribeToTopic(Config.TOPIC_GLOBAL);
                                    getForemanToken();
                                } else if (intent.getAction().equals(Config.PUSH_NOTIFICATION)) {
                                    String s = intent.getStringExtra("message");
                                } else {
                                }
                            }
                        };
                        getForemanToken();

                        new CommonMethod(LoginActivity.this, ForemanEnableActivity.class);
                        finish();

                    } else {
                        new CommonMethod(LoginActivity.this, response.body().message);
                    }

                } else {
                    new CommonMethod(LoginActivity.this, "Server Error Code : " + response.code());
                }
            }

            @Override
            public void onFailure(Call<ForemanLoginData> call, Throwable t) {
                pd.dismiss();
                new CommonMethod(LoginActivity.this, t.getMessage());
            }
        });

    }


    private void UserForemanEnableLogin(){

        Call<UserANDForemanLoginData> call = apiInterface.UserANDForemanEnableLoginData(
                sEmailORMobile, sPassword
        );

        call.enqueue(new Callback<UserANDForemanLoginData>() {
            @Override
            public void onResponse(Call<UserANDForemanLoginData> call, Response<UserANDForemanLoginData> response) {
                pd.dismiss();
                if(response.code()==200) {

                    if(response.body().status.equalsIgnoreCase("User")) {

                        new CommonMethod(LoginActivity.this, response.body().message);

                        UserANDForemanLoginData data = response.body();

                        for(int i=0; i<data.response.size(); i++){
                            String userID = data.response.get(i).foremanID;
                            //sp.edit().putString(SharedPreferencesData.UserType, data.response.get(i).userType).commit();
                            sp.edit().putString(SharedPreferencesData.UserID, userID).commit();
                            sp.edit().putString(SharedPreferencesData.FirstName, data.response.get(i).firstName).commit();
                            sp.edit().putString(SharedPreferencesData.LastName, data.response.get(i).lastName).commit();
                            sp.edit().putString(SharedPreferencesData.ProfileImage, data.response.get(i).profileImage).commit();
                            sp.edit().putString(SharedPreferencesData.MobileNumber, data.response.get(i).mobileNumber).commit();
                            sp.edit().putString(SharedPreferencesData.Email, data.response.get(i).email).commit();
                            sp.edit().putString(SharedPreferencesData.Password, data.response.get(i).password).commit();
                            sp.edit().putString(SharedPreferencesData.Account_Status, data.response.get(i).accountStatus).commit();

                            sp.edit().putString(SharedPreferencesData.UserEnable, "UserEnable").commit();
                        }



                        // TODO Notification FCMID
                        broadcastReceiver = new BroadcastReceiver() {
                            @Override
                            public void onReceive(Context context, Intent intent) {
                                if (intent.getAction().equals(Config.REGISTRATION_COMPLETE)) {
                                    FirebaseMessaging.getInstance().subscribeToTopic(Config.TOPIC_GLOBAL);
                                    getUserToken();
                                } else if (intent.getAction().equals(Config.PUSH_NOTIFICATION)) {
                                    String s = intent.getStringExtra("message");
                                } else {
                                }
                            }
                        };
                        getUserToken();

                        new CommonMethod(LoginActivity.this, UserEnableActivity.class);
                        finish();

                    } else if(response.body().status.equalsIgnoreCase("Foreman")) {


                        new CommonMethod(LoginActivity.this, response.body().message);

                        UserANDForemanLoginData data = response.body();

                        for(int i=0; i<data.response.size(); i++){
                           // sp.edit().putString(SharedPreferencesData.UserType, data.response.get(i).userType).commit();
                            sp.edit().putString(SharedPreferencesData.UserID, data.response.get(i).foremanID).commit();
                            sp.edit().putString(SharedPreferencesData.FirstName, data.response.get(i).firstName).commit();
                            sp.edit().putString(SharedPreferencesData.LastName, data.response.get(i).lastName).commit();
                            sp.edit().putString(SharedPreferencesData.ProfileImage, data.response.get(i).profileImage).commit();
                            sp.edit().putString(SharedPreferencesData.MobileNumber, data.response.get(i).mobileNumber).commit();
                            sp.edit().putString(SharedPreferencesData.Email, data.response.get(i).email).commit();
                            sp.edit().putString(SharedPreferencesData.Password, data.response.get(i).password).commit();
                            sp.edit().putString(SharedPreferencesData.ForemanAddress, data.response.get(i).address).commit();
                            sp.edit().putString(SharedPreferencesData.ForemanArea, data.response.get(i).area).commit();
                            sp.edit().putString(SharedPreferencesData.ForemanCity, data.response.get(i).city).commit();
                            sp.edit().putString(SharedPreferencesData.ForemanState, data.response.get(i).state).commit();
                            sp.edit().putString(SharedPreferencesData.Account_Status, data.response.get(i).accountStatus).commit();

                            sp.edit().putString(SharedPreferencesData.ForemanEnable, "ForemanEnable").commit();
                        }


                        // TODO Notification FCMID
                        broadcastReceiver = new BroadcastReceiver() {
                            @Override
                            public void onReceive(Context context, Intent intent) {
                                if (intent.getAction().equals(Config.REGISTRATION_COMPLETE)) {
                                    FirebaseMessaging.getInstance().subscribeToTopic(Config.TOPIC_GLOBAL);
                                    getForemanToken();
                                } else if (intent.getAction().equals(Config.PUSH_NOTIFICATION)) {
                                    String s = intent.getStringExtra("message");
                                } else {
                                }
                            }
                        };
                        getForemanToken();

                        new CommonMethod(LoginActivity.this, ForemanEnableActivity.class);
                        finish();


                    }  else {
                        new CommonMethod(LoginActivity.this, response.body().message);
                    }

                } else {
                    new CommonMethod(LoginActivity.this, "Server Error Code : "+response.code());
                }


            }

            @Override
            public void onFailure(Call<UserANDForemanLoginData> call, Throwable t) {
                pd.dismiss();
                new CommonMethod(LoginActivity.this, t.getMessage());
            }
        });

    }


    private void getAdminToken() {
        FirebaseInstanceId.getInstance().getInstanceId().addOnSuccessListener(this, instanceIdResult -> {
            String sToken = instanceIdResult.getToken();
            Log.d("RESPONSE_TOKEN", sToken);
            sp.edit().putString(SharedPreferencesData.UserFCMID, sToken).commit();

            if (new ConnectionDetector(this).isConnectingToInternet()) {

                if(!sp.getString(SharedPreferencesData.UserType, "").equalsIgnoreCase("")){
                    sp.edit().putString(SharedPreferencesData.Admin_FCMID, sToken).commit();
                }

            } else {
                new ConnectionDetector(this).connectiondetect();
            }
        });
    }

    private void getUserToken() {
        FirebaseInstanceId.getInstance().getInstanceId().addOnSuccessListener(this, instanceIdResult -> {
            String sToken = instanceIdResult.getToken();
            Log.d("RESPONSE_TOKEN", sToken);
            sp.edit().putString(SharedPreferencesData.UserFCMID, sToken).commit();

            if (new ConnectionDetector(this).isConnectingToInternet()) {

                if(!sp.getString(SharedPreferencesData.UserType, "").equalsIgnoreCase("")){
                    addUserFcmIDData();
                }

            } else {
                new ConnectionDetector(this).connectiondetect();
            }
        });
    }


    private void getForemanToken() {
        FirebaseInstanceId.getInstance().getInstanceId().addOnSuccessListener(this, instanceIdResult -> {
            String sToken = instanceIdResult.getToken();
            Log.d("RESPONSE_TOKEN", sToken);
            sp.edit().putString(SharedPreferencesData.ForemanFCMID, sToken).commit();

            if (new ConnectionDetector(this).isConnectingToInternet()) {

                if(!sp.getString(SharedPreferencesData.UserType, "").equalsIgnoreCase("")) {
                    addForemanFcmIDData();
                }

            } else {
                new ConnectionDetector(this).connectiondetect();
            }
        });
    }


    private void addUserFcmIDData() {

        Call<UpdateFCMIDData> call = apiInterface.UpdateUserFCMIDData(
                sp.getString(SharedPreferencesData.UserID, ""),
                sp.getString(SharedPreferencesData.UserFCMID, "")
        );

        call.enqueue(new Callback<UpdateFCMIDData>() {
            @Override
            public void onResponse(Call<UpdateFCMIDData> call, Response<UpdateFCMIDData> response) {

                if(response.code()==200){
                    if(response.body().status==true){
                     //   new CommonMethod(LoginActivity.this, response.body().message);
                    } else {
                        new CommonMethod(LoginActivity.this, response.body().message);
                    }

                } else {
                    new CommonMethod(LoginActivity.this, "Server Error Code : "+response.code());
                }

            }

            @Override
            public void onFailure(Call<UpdateFCMIDData> call, Throwable t) {
                new CommonMethod(LoginActivity.this, t.getMessage());
            }
        });

    }


    private void addForemanFcmIDData() {

        Call<UpdateFCMIDData> call = apiInterface.UpdateForemanFCMIDData(
                sp.getString(SharedPreferencesData.UserID, ""),
                sp.getString(SharedPreferencesData.ForemanFCMID, "")
        );

        call.enqueue(new Callback<UpdateFCMIDData>() {
            @Override
            public void onResponse(Call<UpdateFCMIDData> call, Response<UpdateFCMIDData> response) {

                if(response.code()==200){
                    if(response.body().status==true){
                      //  new CommonMethod(LoginActivity.this, response.body().message);
                    } else {
                        new CommonMethod(LoginActivity.this, response.body().message);
                    }

                } else {
                    new CommonMethod(LoginActivity.this, "Server Error Code : "+response.code());
                }

            }

            @Override
            public void onFailure(Call<UpdateFCMIDData> call, Throwable t) {
                new CommonMethod(LoginActivity.this, t.getMessage());
            }
        });








        ForgotPassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                AlertDialog.Builder alertDialog = new AlertDialog.Builder(LoginActivity.this);

                alertDialog.setPositiveButton("User", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        new CommonMethod(LoginActivity.this, UserForgotPasswordActivity.class);
                    }
                });

                alertDialog.setNeutralButton("Foreman", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        new CommonMethod(LoginActivity.this, ForemanForgotPasswordActivity.class);
                    }
                });

                alertDialog.setCancelable(true);
                alertDialog.show();
            }
        });




    }



}