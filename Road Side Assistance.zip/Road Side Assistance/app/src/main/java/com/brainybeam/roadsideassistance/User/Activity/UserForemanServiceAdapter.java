package com.brainybeam.roadsideassistance.User.Activity;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.brainybeam.roadsideassistance.GPS.GPSTracker;
import com.brainybeam.roadsideassistance.R;
import com.brainybeam.roadsideassistance.RetrofitData.CartAddServicesData;
import com.brainybeam.roadsideassistance.RetrofitData.LocationData;
import com.brainybeam.roadsideassistance.User.CustomArrayList.UserForemanServiceList;
import com.brainybeam.roadsideassistance.Utils.ApiClient;
import com.brainybeam.roadsideassistance.Utils.ApiInterface;
import com.brainybeam.roadsideassistance.Utils.CommonMethod;
import com.brainybeam.roadsideassistance.Utils.SharedPreferencesData;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

import de.hdodenhof.circleimageview.CircleImageView;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class UserForemanServiceAdapter extends RecyclerView.Adapter<UserForemanServiceAdapter.MyHolder> {

    Context context;
    ArrayList<UserForemanServiceList> arrayList;

    ApiInterface apiInterface;
    SharedPreferences sp;
    double UserCurrLatitude, UserCurrLongitude;
    String sUserCurrLatitude, sUserCurrLongitude;

    GPSTracker gpsTracker;

    public UserForemanServiceAdapter(Context context, ArrayList<UserForemanServiceList> arrayList) {
        this.context = context;
        this.arrayList = arrayList;
    }

    @NonNull
    @Override
    public MyHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.custom_user_request_foreman_services, parent, false);

        return new MyHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyHolder holder, @SuppressLint("RecyclerView") int position) {

        if(sp.getString(SharedPreferencesData.ProfileImage, "").equalsIgnoreCase("https://alpeshpatel-project.000webhostapp.com/RoadSideAssistance/ForemanImages/")){

        } else {
            Picasso.with(context).load(sp.getString(SharedPreferencesData.ProfileImage, "")).placeholder(R.drawable.ic_foreman).into(holder.ProfileImage);
        }

        gpsTracker = new GPSTracker(context);
        // Check if GPS enabled
        if(gpsTracker.canGetLocation()) {

            UserCurrLatitude = gpsTracker.getLatitude();
            UserCurrLongitude = gpsTracker.getLongitude();

            //  getLocation();

        } else {
            // Can't get location.
            // GPS or network is not enabled.
            // Ask user to enable GPS/network in settings.
            gpsTracker.showSettingsAlert();
        }


        holder.Name.setText(arrayList.get(position).getFirstName()+" "+arrayList.get(position).getLastName());
        holder.MobileNumber.setText("+91 "+ arrayList.get(position).getMobileNumber());
        holder.TypeOfProblem.setText(arrayList.get(position).getTypeOfProblem());
        holder.SubTypeOfProblem.setText(arrayList.get(position).getProblemSubType());
        holder.FixCharge.setText("₹ "+ arrayList.get(position).getServiceFixedCharge());
        holder.Distance.setText(arrayList.get(position).getDistance()+" meter");

        sp.edit().putString(SharedPreferencesData.User_DistanceWithForeman, arrayList.get(position).getDistance()).commit();

        holder.SelectButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                sUserCurrLatitude = arrayList.get(position).getUserLatitude();
                sUserCurrLongitude = arrayList.get(position).getUserLongitude();

                // TODO Store Data in SharedPreferences
                sp.edit().putString(SharedPreferencesData.User_ServiceID, arrayList.get(position).getServiceID()).commit();
                sp.edit().putString(SharedPreferencesData.User_ForemanFirstName, arrayList.get(position).getFirstName()).commit();
                sp.edit().putString(SharedPreferencesData.User_ForemanLastName, arrayList.get(position).getLastName()).commit();
                sp.edit().putString(SharedPreferencesData.User_ForemanProfileImage, arrayList.get(position).getProfileImage()).commit();

                sp.edit().putString(SharedPreferencesData.User_TypeOfProblem, arrayList.get(position).getTypeOfProblem()).commit();
                sp.edit().putString(SharedPreferencesData.User_ProblemSubType, arrayList.get(position).getProblemSubType()).commit();
                sp.edit().putString(SharedPreferencesData.User_FixCharge, arrayList.get(position).getServiceFixedCharge()).commit();
                sp.edit().putString(SharedPreferencesData.User_ForemanID, arrayList.get(position).getForemanID()).commit();
                sp.edit().putString(SharedPreferencesData.User_ForemanMobileNumber, arrayList.get(position).getMobileNumber()).commit();
                sp.edit().putString(SharedPreferencesData.User_SPReqMoney, arrayList.get(position).getServiceFixedCharge()).commit();

                sp.edit().putString(SharedPreferencesData.User_PaymentStatus, "No").commit();

                sp.edit().putString(SharedPreferencesData.User_ForemanLatitude, arrayList.get(position).getLatitude()).commit();
                sp.edit().putString(SharedPreferencesData.User_ForemanLongitude, arrayList.get(position).getLongitude()).commit();
                sp.edit().putString(SharedPreferencesData.User_UserLatitude, arrayList.get(position).getUserLatitude()).commit();
                sp.edit().putString(SharedPreferencesData.User_UserLongitude, arrayList.get(position).getUserLongitude()).commit();
                sp.edit().putString(SharedPreferencesData.User_UserLocation, arrayList.get(position).getUserLocation()).commit();


                sp.edit().putString(SharedPreferencesData.User_VehicleID, "").commit();
                sp.edit().putString(SharedPreferencesData.User_NumberPlate_number, "").commit();
                sp.edit().putString(SharedPreferencesData.User_TypeOfVehicle, "").commit();
                sp.edit().putString(SharedPreferencesData.User_VehicleModelName, "").commit();
                sp.edit().putString(SharedPreferencesData.User_Vehicle_Colour, "").commit();



                StoreUserLocationData();
                new CommonMethod(holder.itemView.getContext(), ProblemDescriptionMessageActivity.class);
            }
        });


        holder.CallButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                AlertDialog.Builder builder = new AlertDialog.Builder(context);
                builder.setTitle("Call Service Provider "+arrayList.get(position).getFirstName());
                builder.setPositiveButton("CALL", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        Intent intent = new Intent(Intent.ACTION_CALL);
                        intent.setData(Uri.parse("tel:"+ "+91"+arrayList.get(position).getMobileNumber()));
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                            if (context.checkSelfPermission(Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
                                // TODO: Consider calling
                                //    Activity#requestPermissions
                                // here to request the missing permissions, and then overriding
                                //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
                                //                                          int[] grantResults)
                                // to handle the case where the user grants the permission. See the documentation
                                // for Activity#requestPermissions for more details.
                                return;
                            }
                        }
                        context.getApplicationContext().startActivity(intent);
                    }
                });

                builder.setNegativeButton("CANCEL", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        dialogInterface.dismiss();
                    }
                });
                builder.show();

            }
        });
        
    }

    private void StoreUserLocationData() {

        String cLatitude, cLongitude;

        cLatitude = String.valueOf(UserCurrLatitude);
        cLongitude = String.valueOf(UserCurrLongitude);

        sp.edit().putString(SharedPreferencesData.User_UserCurrLatitude, cLatitude).commit();
        sp.edit().putString(SharedPreferencesData.User_UserCurrLongitude, cLongitude).commit();

        Call<LocationData> call = apiInterface.AddUserLocationData(
                sp.getString(SharedPreferencesData.UserID, ""),
                sp.getString(SharedPreferencesData.User_ForemanID, ""),
                cLatitude,
                cLongitude
        );

        call.enqueue(new Callback<LocationData>() {
            @Override
            public void onResponse(Call<LocationData> call, Response<LocationData> response) {

                if(response.code()==200){

                    if(response.body().status==true){
                       // new CommonMethod(context, response.body().message);
                    } else {
                        new CommonMethod(context, response.body().message);
                    }

                } else {
                    new CommonMethod(context, "Server Error Code : "+response.code());
                }

            }

            @Override
            public void onFailure(Call<LocationData> call, Throwable t) {
                new CommonMethod(context, t.getMessage());
            }
        });

    }


    @Override
    public int getItemCount() {
        return arrayList.size();
    }


    public class MyHolder extends RecyclerView.ViewHolder {

        CircleImageView ProfileImage;
        TextView Name, MobileNumber, TypeOfProblem, SubTypeOfProblem, FixCharge, Distance;
        Button SelectButton, CallButton;

        String sName, sMobileNumber, sTypeOfProblem, sSubTypeOfProblem, sFixCharge, sDistance;

        public MyHolder(@NonNull View itemView) {
            super(itemView);

            apiInterface = ApiClient.getClient().create(ApiInterface.class);
            sp = context.getSharedPreferences(SharedPreferencesData.PREF, Context.MODE_PRIVATE);

            ProfileImage = itemView.findViewById(R.id.custom_user_request_foreman_services_foremanProfileImage);
            Name = itemView.findViewById(R.id.custom_user_request_foreman_services_FirstANDLastName);
            MobileNumber = itemView.findViewById(R.id.custom_user_request_foreman_services_MobileNumber);
            TypeOfProblem = itemView.findViewById(R.id.custom_user_request_foreman_services_TypeOfProblem);
            SubTypeOfProblem = itemView.findViewById(R.id.custom_user_request_foreman_services_problemSubType);
            FixCharge = itemView.findViewById(R.id.custom_user_request_foreman_services_FixedCharge);
            Distance = itemView.findViewById(R.id.custom_user_request_foreman_services_Distance);

            SelectButton = itemView.findViewById(R.id.custom_user_request_foreman_services_SelectButton);
            CallButton = itemView.findViewById(R.id.custom_user_request_foreman_services_CallButton);

        }
    }


}
