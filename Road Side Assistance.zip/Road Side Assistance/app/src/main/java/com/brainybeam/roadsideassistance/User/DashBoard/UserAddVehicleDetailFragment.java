package com.brainybeam.roadsideassistance.User.DashBoard;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RelativeLayout;
import android.widget.Spinner;

import com.brainybeam.roadsideassistance.R;
import com.brainybeam.roadsideassistance.RetrofitData.AddUserVehicleData;
import com.brainybeam.roadsideassistance.RetrofitData.GetUserVehicleData;
import com.brainybeam.roadsideassistance.User.Activity.AddVehicleActivity;
import com.brainybeam.roadsideassistance.User.CustomArrayList.UserVehicleList;
import com.brainybeam.roadsideassistance.Utils.ApiClient;
import com.brainybeam.roadsideassistance.Utils.ApiInterface;
import com.brainybeam.roadsideassistance.Utils.CommonMethod;
import com.brainybeam.roadsideassistance.Utils.ConnectionDetector;
import com.brainybeam.roadsideassistance.Utils.ConstantData;
import com.brainybeam.roadsideassistance.Utils.SharedPreferencesData;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


public class UserAddVehicleDetailFragment extends Fragment {


    RecyclerView recyclerView;
    FloatingActionButton floatingActionButton;

    ArrayList<UserVehicleList> arrayList;

    ApiInterface apiInterface;
    SharedPreferences sp;
    ProgressDialog pd;

    public UserAddVehicleDetailFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_user_add_vehicle_detail, container, false);

        apiInterface = ApiClient.getClient().create(ApiInterface.class);
        sp = getActivity().getSharedPreferences(SharedPreferencesData.PREF, Context.MODE_PRIVATE);

        recyclerView = view.findViewById(R.id.frag_user_Addvehicle_recyclerview);
        floatingActionButton = view.findViewById(R.id.frag_user_Addvehicle_floatingAddButton);

        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        recyclerView.setItemAnimator(new DefaultItemAnimator());

        floatingActionButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                new CommonMethod(getActivity(), AddVehicleActivity.class);
            }
        });

        if(new ConnectionDetector(getActivity()).isConnectingToInternet()){
            pd = new ProgressDialog(getActivity());
            pd.setMessage("Please Wait...");
            pd.setCancelable(false);
            pd.show();
            recyclerViewDataSetMethod();

        } else {
            new ConnectionDetector(getActivity()).connectiondetect();
        }

        return view;
    }

    private void recyclerViewDataSetMethod() {

        Call<GetUserVehicleData> call = apiInterface.GetUserVehicleData(
                sp.getString(SharedPreferencesData.UserID, "")
        );

        call.enqueue(new Callback<GetUserVehicleData>() {
            @Override
            public void onResponse(Call<GetUserVehicleData> call, Response<GetUserVehicleData> response) {
                pd.dismiss();
                if(response.code()==200){

                    if(response.body().status==true){
                        new CommonMethod(getActivity(), response.body().message);

                        arrayList = new ArrayList<>();
                        GetUserVehicleData data = response.body();
                        for(int i=0; i<data.response.size(); i++){
                            UserVehicleList list = new UserVehicleList();

                            list.setVehicleID(data.response.get(i).vehicleID);
                            list.setUserID(data.response.get(i).userID);
                            list.setNumberPlate_number(data.response.get(i).numberPlateNumber);
                            list.setTypeOfVehicle(data.response.get(i).typeOfVehicle);
                            list.setVehicleModelName(data.response.get(i).vehicleModelName);
                            list.setVehicle_Colour(data.response.get(i).vehicleColour);

                            arrayList.add(list);
                        }

                        UserVehicleDetailAdapter adapter = new UserVehicleDetailAdapter(getActivity(), arrayList);
                        recyclerView.setAdapter(adapter);
                        adapter.notifyDataSetChanged();

                    } else {
                        new CommonMethod(getActivity(), response.body().message);
                    }

                } else {
                    new CommonMethod(getActivity(), "Server Error Code "+response.code());
                }

            }

            @Override
            public void onFailure(Call<GetUserVehicleData> call, Throwable t) {
                pd.dismiss();
                new CommonMethod(getActivity(), t.getMessage());
            }
        });

    }


}