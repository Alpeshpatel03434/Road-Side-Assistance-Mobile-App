package com.brainybeam.roadsideassistance.Foreman.Activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.ProgressDialog;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;

import com.brainybeam.roadsideassistance.Foreman.CustomArrayList.ServiceListData;
import com.brainybeam.roadsideassistance.Foreman.DashBoard.ForemanServicesAdapter;
import com.brainybeam.roadsideassistance.Notification.UserNotificationActivity;
import com.brainybeam.roadsideassistance.R;
import com.brainybeam.roadsideassistance.RetrofitData.GetForemanServicesData;
import com.brainybeam.roadsideassistance.User.DashBoard.UserDashboardActivity;
import com.brainybeam.roadsideassistance.Utils.ApiClient;
import com.brainybeam.roadsideassistance.Utils.ApiInterface;
import com.brainybeam.roadsideassistance.Utils.CommonMethod;
import com.brainybeam.roadsideassistance.Utils.ConnectionDetector;
import com.brainybeam.roadsideassistance.Utils.SharedPreferencesData;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ForemanHomeAddServicesActivity extends AppCompatActivity {

    RecyclerView recyclerView;
    FloatingActionButton floatingAddButton;

    ArrayList<ServiceListData> arrayList_ForRecyclerView;


    SharedPreferences sp;
    ApiInterface apiInterface;
    ProgressDialog pd;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_foreman_home_add_services);
        getSupportActionBar().setTitle("Add Services");
        ColorDrawable colorDrawable
                = new ColorDrawable(Color.parseColor("#2196F3"));
        getSupportActionBar().setBackgroundDrawable(colorDrawable);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        
        apiInterface = ApiClient.getClient().create(ApiInterface.class);
        sp = getSharedPreferences(SharedPreferencesData.PREF, MODE_PRIVATE);

        floatingAddButton = findViewById(R.id.foreman_services_floatingAddButton);

        recyclerView = findViewById(R.id.foreman_services_recyclerview);
        recyclerView.setLayoutManager(new LinearLayoutManager(ForemanHomeAddServicesActivity.this));
        recyclerView.setItemAnimator(new DefaultItemAnimator());

        floatingAddButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                new CommonMethod(ForemanHomeAddServicesActivity.this, AddForemanServicesActivity.class);
            }
        });


        if(new ConnectionDetector(ForemanHomeAddServicesActivity.this).isConnectingToInternet()){
            pd = new ProgressDialog(ForemanHomeAddServicesActivity.this);
            pd.setMessage("Please Wait...");
            pd.setCancelable(false);
            pd.show();
            recyclerViewDataSetMethod();

        } else {
            new ConnectionDetector(ForemanHomeAddServicesActivity.this).connectiondetect();
        }
        
    }

    private void recyclerViewDataSetMethod() {

        Call<GetForemanServicesData> call = apiInterface.GetForemanServicesData(
                sp.getString(SharedPreferencesData.UserID, "")
        );

        call.enqueue(new Callback<GetForemanServicesData>() {
            @Override
            public void onResponse(Call<GetForemanServicesData> call, Response<GetForemanServicesData> response) {

                pd.dismiss();
                if (response.code()==200) {
                    if (response.body().status == true) {
                        // new CommonMethod(ForemanHomeAddServicesActivity.this, response.body().message);

                        arrayList_ForRecyclerView = new ArrayList<>();
                        GetForemanServicesData data = response.body();

                        for (int i = 0; i < data.response.size(); i++) {
                            ServiceListData list = new ServiceListData();

                            list.setServiceID(data.response.get(i).serviceID);
                            list.setForemanID(data.response.get(i).foremanID);
                            list.setFirstName(data.response.get(i).firstName);
                            list.setLastName(data.response.get(i).lastName);
                            list.setProfileImage(data.response.get(i).profileImage);
                            list.setMobileNumber(data.response.get(i).mobileNumber);
                            list.setTypeOfService(data.response.get(i).typeOfProblem);
                            list.setProblemSubType(data.response.get(i).problemSubType);
                            list.setServiceFixedCharge(data.response.get(i).serviceFixedCharge);

                            arrayList_ForRecyclerView.add(list);
                        }

                        ForemanServicesAdapter adapter = new ForemanServicesAdapter(ForemanHomeAddServicesActivity.this, arrayList_ForRecyclerView);
                        recyclerView.setAdapter(adapter);

                    } else {
                        new CommonMethod(ForemanHomeAddServicesActivity.this, response.body().message);
                    }
                } else {
                    new CommonMethod(ForemanHomeAddServicesActivity.this, "Server Error Code : "+response.code());
                }
            }

            @Override
            public void onFailure(Call<GetForemanServicesData> call, Throwable t) {
                pd.dismiss();
                new CommonMethod(ForemanHomeAddServicesActivity.this, t.getMessage());
            }
        });

    }


    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();
        if (id == android.R.id.home) {
            onBackPressed();
        }
        return super.onOptionsItemSelected(item);
    }

}