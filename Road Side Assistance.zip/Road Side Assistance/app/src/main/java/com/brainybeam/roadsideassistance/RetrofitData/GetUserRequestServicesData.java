package com.brainybeam.roadsideassistance.RetrofitData;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.List;

public class GetUserRequestServicesData {

    @SerializedName("Status")
    @Expose
    public Boolean status;
    @SerializedName("Message")
    @Expose
    public String message;
    @SerializedName("response")
    @Expose
    public List<GetUserRequestServicesResponse> response = null;

    public class GetUserRequestServicesResponse {
        @SerializedName("ServiceID")
        @Expose
        public String serviceID;
        @SerializedName("ForemanID")
        @Expose
        public String foremanID;
        @SerializedName("FirstName")
        @Expose
        public String firstName;
        @SerializedName("LastName")
        @Expose
        public String lastName;
        @SerializedName("ProfileImage")
        @Expose
        public String profileImage;
        @SerializedName("MobileNumber")
        @Expose
        public String mobileNumber;
        @SerializedName("Address")
        @Expose
        public String address;
        @SerializedName("TypeOfProblem")
        @Expose
        public String typeOfProblem;
        @SerializedName("ProblemSubType")
        @Expose
        public String problemSubType;
        @SerializedName("ServiceFixedCharge")
        @Expose
        public String serviceFixedCharge;
        @SerializedName("locationID")
        @Expose
        public String locationID;
        @SerializedName("Latitude")
        @Expose
        public String latitude;
        @SerializedName("Longitude")
        @Expose
        public String longitude;
    }
}
