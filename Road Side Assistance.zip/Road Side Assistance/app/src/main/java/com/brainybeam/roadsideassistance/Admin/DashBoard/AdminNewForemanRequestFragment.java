package com.brainybeam.roadsideassistance.Admin.DashBoard;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.brainybeam.roadsideassistance.Admin.CustomArrayList.NewForemanRequestList;
import com.brainybeam.roadsideassistance.R;
import com.brainybeam.roadsideassistance.RetrofitData.AdminGetNewForemanRequestData;
import com.brainybeam.roadsideassistance.Utils.ApiClient;
import com.brainybeam.roadsideassistance.Utils.ApiInterface;
import com.brainybeam.roadsideassistance.Utils.CommonMethod;
import com.brainybeam.roadsideassistance.Utils.ConnectionDetector;
import com.brainybeam.roadsideassistance.Utils.SharedPreferencesData;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


public class AdminNewForemanRequestFragment extends Fragment {

    RecyclerView recyclerView;

    ArrayList<NewForemanRequestList> arrayList;

    ApiInterface apiInterface;
    SharedPreferences sp;
    ProgressDialog pd;


    public AdminNewForemanRequestFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_admin_new_foreman_request, container, false);

        apiInterface = ApiClient.getClient().create(ApiInterface.class);
        sp = getActivity().getSharedPreferences(SharedPreferencesData.PREF, Context.MODE_PRIVATE);

        recyclerView = view.findViewById(R.id.frag_admin_new_foreman_request_recyclerView);

        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        recyclerView.setItemAnimator(new DefaultItemAnimator());

        if(new ConnectionDetector(getActivity()).isConnectingToInternet()){

            pd = new ProgressDialog(getActivity());
            pd.setMessage("Please Wait...");
            pd.setCancelable(false);
            pd.show();

            recyclerViewDataSetMethod();

        } else {
            new ConnectionDetector(getActivity()).connectiondetect();
        }

        return view;
    }

    private void recyclerViewDataSetMethod() {

        Call<AdminGetNewForemanRequestData> call = apiInterface.GetAdminNewForemanRequestData();

        call.enqueue(new Callback<AdminGetNewForemanRequestData>() {
            @Override
            public void onResponse(Call<AdminGetNewForemanRequestData> call, Response<AdminGetNewForemanRequestData> response) {

                pd.dismiss();
                if(response.code()==200){

                    if(response.body().status==true){

                     //   new CommonMethod(getActivity(), response.body().message);
                        arrayList = new ArrayList<>();
                        AdminGetNewForemanRequestData data = response.body();

                        for(int i=0; i<data.response.size(); i++){
                            NewForemanRequestList list = new NewForemanRequestList();

                            list.setForemanID(data.response.get(i).foremanID);
                            list.setUserType(data.response.get(i).userType);
                            list.setFirstName(data.response.get(i).firstName);
                            list.setLastName(data.response.get(i).lastName);
                            list.setProfileImage(data.response.get(i).profileImage);
                            list.setMobileNumber(data.response.get(i).mobileNumber);
                            list.setEmail(data.response.get(i).email);
                            list.setAddress(data.response.get(i).address);
                            list.setArea(data.response.get(i).area);
                            list.setCity(data.response.get(i).city);
                            list.setState(data.response.get(i).state);
                            list.setAccount_Status(data.response.get(i).accountStatus);
                            list.setCreated_time(data.response.get(i).createdTime);

                            arrayList.add(list);
                        }

                        AdminNewForemanRequestAdapter adapter = new AdminNewForemanRequestAdapter(getActivity(), arrayList);
                        recyclerView.setAdapter(adapter);
                        adapter.notifyDataSetChanged();

                    } else {
                        new CommonMethod(getActivity(), response.body().message);
                    }

                } else {
                    new CommonMethod(getActivity(), "Server Error Code : "+response.code());
                }

            }

            @Override
            public void onFailure(Call<AdminGetNewForemanRequestData> call, Throwable t) {
                pd.dismiss();
                new CommonMethod(getActivity(), t.getMessage());
            }
        });

    }

}