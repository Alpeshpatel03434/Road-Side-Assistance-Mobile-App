package com.brainybeam.roadsideassistance.User.DashBoard;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.brainybeam.roadsideassistance.R;
import com.brainybeam.roadsideassistance.User.Activity.UserForemanServicesActivity;
import com.brainybeam.roadsideassistance.Utils.ApiClient;
import com.brainybeam.roadsideassistance.Utils.ApiInterface;
import com.brainybeam.roadsideassistance.Utils.CommonMethod;
import com.brainybeam.roadsideassistance.Utils.SharedPreferencesData;

import java.util.ArrayList;


public class UserHomeFragment extends Fragment {


    private TextView continueTextButton;

    private LinearLayout accident_layout, battery_layout, clutch_break_problem_layout, fuel_problem_layout, lost_lock_Key_layout,
            Towing_layout, Tyre_Damage_layout, Other_layout;

    private LinearLayout fuel_problem_Sub_layout;
    CheckBox outOfOil, outOfPetrol, outOfWrongFuel;
    String sfuel_subProblem;

    private LinearLayout Tyre_problem_Sub_layout;
    RadioGroup TyreSubChoice_radioGroup;
    String sTyre_subProblem;

    ApiInterface apiInterface;
    SharedPreferences sp;
    ProgressDialog pd;

    public UserHomeFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_user_home, container, false);

        apiInterface = ApiClient.getClient().create(ApiInterface.class);
        sp = getContext().getSharedPreferences(SharedPreferencesData.PREF, Context.MODE_PRIVATE);


        // TODO Layout
        accident_layout = view.findViewById(R.id.frag_user_home_accident_layout);
        battery_layout = view.findViewById(R.id.frag_user_home_battery_layout);
        clutch_break_problem_layout = view.findViewById(R.id.frag_user_home_clutch_layout);
        fuel_problem_layout = view.findViewById(R.id.frag_user_home_fuel_layout);
        lost_lock_Key_layout = view.findViewById(R.id.frag_user_home_lost_lock_key_layout);
        Towing_layout = view.findViewById(R.id.frag_user_home_towing_layout);
        Tyre_Damage_layout = view.findViewById(R.id.frag_user_home_tyre_layout);
        Other_layout = view.findViewById(R.id.frag_user_home_other_layout);

        // TODO Sub layout
        fuel_problem_Sub_layout = view.findViewById(R.id.frag_user_home_fuel_sub_layout);
        outOfOil = view.findViewById(R.id.frag_user_home_fuel_diesel);
        outOfPetrol = view.findViewById(R.id.frag_user_home_fuel_petrol);
        outOfWrongFuel = view.findViewById(R.id.frag_user_home_fuel_wrong);

        fuel_problem_Sub_layout.setVisibility(View.GONE);

        Tyre_problem_Sub_layout = view.findViewById(R.id.frag_user_home_tyre_sub_layout);
        TyreSubChoice_radioGroup = view.findViewById(R.id.frag_user_home_tyre_radioGroup);

        Tyre_problem_Sub_layout.setVisibility(View.GONE);


        // TODO If User Any Issue Select after User can continue throw this Text Button
        continueTextButton = view.findViewById(R.id.frag_user_home_continueTextButton);
        continueTextButton.setVisibility(View.GONE);

        // TODO Orientation of Device
        int orientation = getResources().getConfiguration().orientation;
        if (orientation == Configuration.ORIENTATION_LANDSCAPE) {
            // In landscape
            RelativeLayout.LayoutParams layoutParams =
                    (RelativeLayout.LayoutParams)continueTextButton.getLayoutParams();
          //  layoutParams.addRule(RelativeLayout.CENTER_IN_PARENT, RelativeLayout.TRUE);
            layoutParams.addRule(RelativeLayout.ALIGN_PARENT_RIGHT, RelativeLayout.TRUE);
//            continueTextButton.setMaxHeight(200);
//            continueTextButton.setMaxWidth(200);
            continueTextButton.setLayoutParams(layoutParams);
        }


        // TODO Accident occur after vehicle issue
        accident_layout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                sp.edit().putString(SharedPreferencesData.UserSelectionCount, "Yes").commit();
                sp.edit().putString(SharedPreferencesData.User_TypeOfProblem, "Accident Situation").commit();
                sp.edit().putString(SharedPreferencesData.User_ProblemSubType, "").commit();
                fuel_problem_Sub_layout.setVisibility(View.GONE);
                Tyre_problem_Sub_layout.setVisibility(View.GONE);

                accident_layout.setBackground(getResources().getDrawable(R.drawable.custom_border_selected_home_layout));
                battery_layout.setBackground(getResources().getDrawable(R.drawable.custom_border_notselected_home_layout));
                clutch_break_problem_layout.setBackground(getResources().getDrawable(R.drawable.custom_border_notselected_home_layout));
                fuel_problem_layout.setBackground(getResources().getDrawable(R.drawable.custom_border_notselected_home_layout));
                lost_lock_Key_layout.setBackground(getResources().getDrawable(R.drawable.custom_border_notselected_home_layout));
                Towing_layout.setBackground(getResources().getDrawable(R.drawable.custom_border_notselected_home_layout));
                Tyre_Damage_layout.setBackground(getResources().getDrawable(R.drawable.custom_border_notselected_home_layout));
                Other_layout.setBackground(getResources().getDrawable(R.drawable.custom_border_notselected_home_layout));

                continueTextButton.setVisibility(View.VISIBLE);
            }
        });

        // TODO Battery Jump Start, Starter issue
        battery_layout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                sp.edit().putString(SharedPreferencesData.UserSelectionCount, "Yes").commit();
                sp.edit().putString(SharedPreferencesData.User_TypeOfProblem, "Battery Discharged/Not Working").commit();
                sp.edit().putString(SharedPreferencesData.User_ProblemSubType, "").commit();
                fuel_problem_Sub_layout.setVisibility(View.GONE);
                Tyre_problem_Sub_layout.setVisibility(View.GONE);

                accident_layout.setBackground(getResources().getDrawable(R.drawable.custom_border_notselected_home_layout));
                battery_layout.setBackground(getResources().getDrawable(R.drawable.custom_border_selected_home_layout));
                clutch_break_problem_layout.setBackground(getResources().getDrawable(R.drawable.custom_border_notselected_home_layout));
                fuel_problem_layout.setBackground(getResources().getDrawable(R.drawable.custom_border_notselected_home_layout));
                lost_lock_Key_layout.setBackground(getResources().getDrawable(R.drawable.custom_border_notselected_home_layout));
                Towing_layout.setBackground(getResources().getDrawable(R.drawable.custom_border_notselected_home_layout));
                Tyre_Damage_layout.setBackground(getResources().getDrawable(R.drawable.custom_border_notselected_home_layout));
                Other_layout.setBackground(getResources().getDrawable(R.drawable.custom_border_notselected_home_layout));

                continueTextButton.setVisibility(View.VISIBLE);
            }
        });

        // TODO Clutch/Break Problem
        clutch_break_problem_layout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                sp.edit().putString(SharedPreferencesData.UserSelectionCount, "Yes").commit();
                sp.edit().putString(SharedPreferencesData.User_TypeOfProblem, "Clutch/Break Problem").commit();
                sp.edit().putString(SharedPreferencesData.User_ProblemSubType, "").commit();
                fuel_problem_Sub_layout.setVisibility(View.GONE);
                Tyre_problem_Sub_layout.setVisibility(View.GONE);

                accident_layout.setBackground(getResources().getDrawable(R.drawable.custom_border_notselected_home_layout));
                battery_layout.setBackground(getResources().getDrawable(R.drawable.custom_border_notselected_home_layout));
                clutch_break_problem_layout.setBackground(getResources().getDrawable(R.drawable.custom_border_selected_home_layout));
                fuel_problem_layout.setBackground(getResources().getDrawable(R.drawable.custom_border_notselected_home_layout));
                lost_lock_Key_layout.setBackground(getResources().getDrawable(R.drawable.custom_border_notselected_home_layout));
                Towing_layout.setBackground(getResources().getDrawable(R.drawable.custom_border_notselected_home_layout));
                Tyre_Damage_layout.setBackground(getResources().getDrawable(R.drawable.custom_border_notselected_home_layout));
                Other_layout.setBackground(getResources().getDrawable(R.drawable.custom_border_notselected_home_layout));

                continueTextButton.setVisibility(View.VISIBLE);
            }
        });

        // TODO Fuel Problem

        fuel_problem_layout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                sp.edit().putString(SharedPreferencesData.UserSelectionCount, "Yes").commit();
                sp.edit().putString(SharedPreferencesData.User_TypeOfProblem, "Fuel Problem").commit();

                fuel_problem_Sub_layout.setVisibility(View.VISIBLE);
                StringBuilder stringBuilder = new StringBuilder();
                ArrayList<String> arrayList = new ArrayList<>();
                int x = 0;

                if(outOfOil.isChecked()){
                    arrayList.add(x, outOfOil.getText().toString());
                    x++;
                }
//                else {
//                    arrayList.remove(x);
//                    x--;
//;               }
                if(outOfPetrol.isChecked()){
                    arrayList.add(x, outOfPetrol.getText().toString());
                    x++;
                }
//                else {
//                    arrayList.remove(x);
//                    x--;
//                }
                if(outOfWrongFuel.isChecked()){
                    arrayList.add(x, outOfWrongFuel.getText().toString());
                    x++;
                }
//                else {
//                    arrayList.remove(x);
//                    x--;
//                }

                for(int i=0; i<arrayList.size(); i++){
                    stringBuilder.append(arrayList.get(i));
                }

                sfuel_subProblem = stringBuilder.toString();
                sp.edit().putString(SharedPreferencesData.User_ProblemSubType, sfuel_subProblem).commit();

                Tyre_problem_Sub_layout.setVisibility(View.GONE);

                accident_layout.setBackground(getResources().getDrawable(R.drawable.custom_border_notselected_home_layout));
                battery_layout.setBackground(getResources().getDrawable(R.drawable.custom_border_notselected_home_layout));
                clutch_break_problem_layout.setBackground(getResources().getDrawable(R.drawable.custom_border_notselected_home_layout));
                fuel_problem_layout.setBackground(getResources().getDrawable(R.drawable.custom_border_selected_home_layout));
                lost_lock_Key_layout.setBackground(getResources().getDrawable(R.drawable.custom_border_notselected_home_layout));
                Towing_layout.setBackground(getResources().getDrawable(R.drawable.custom_border_notselected_home_layout));
                Tyre_Damage_layout.setBackground(getResources().getDrawable(R.drawable.custom_border_notselected_home_layout));
                Other_layout.setBackground(getResources().getDrawable(R.drawable.custom_border_notselected_home_layout));

                continueTextButton.setVisibility(View.VISIBLE);
            }
        });

        // TODO Lost/Locked Key, Car issue
        lost_lock_Key_layout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                sp.edit().putString(SharedPreferencesData.UserSelectionCount, "Yes").commit();
                sp.edit().putString(SharedPreferencesData.User_TypeOfProblem, "Lost/Lock Key").commit();
                sp.edit().putString(SharedPreferencesData.User_ProblemSubType, "").commit();
                fuel_problem_Sub_layout.setVisibility(View.GONE);
                Tyre_problem_Sub_layout.setVisibility(View.GONE);

                accident_layout.setBackground(getResources().getDrawable(R.drawable.custom_border_notselected_home_layout));
                battery_layout.setBackground(getResources().getDrawable(R.drawable.custom_border_notselected_home_layout));
                clutch_break_problem_layout.setBackground(getResources().getDrawable(R.drawable.custom_border_notselected_home_layout));
                fuel_problem_layout.setBackground(getResources().getDrawable(R.drawable.custom_border_notselected_home_layout));
                lost_lock_Key_layout.setBackground(getResources().getDrawable(R.drawable.custom_border_selected_home_layout));
                Towing_layout.setBackground(getResources().getDrawable(R.drawable.custom_border_notselected_home_layout));
                Tyre_Damage_layout.setBackground(getResources().getDrawable(R.drawable.custom_border_notselected_home_layout));
                Other_layout.setBackground(getResources().getDrawable(R.drawable.custom_border_notselected_home_layout));

                continueTextButton.setVisibility(View.VISIBLE);
            }
        });

        // TODO Towing issue if Big issue
        Towing_layout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                sp.edit().putString(SharedPreferencesData.UserSelectionCount, "Yes").commit();
                sp.edit().putString(SharedPreferencesData.User_TypeOfProblem, "Towing").commit();
                sp.edit().putString(SharedPreferencesData.User_ProblemSubType, "").commit();
                fuel_problem_Sub_layout.setVisibility(View.GONE);
                Tyre_problem_Sub_layout.setVisibility(View.GONE);

                accident_layout.setBackground(getResources().getDrawable(R.drawable.custom_border_notselected_home_layout));
                battery_layout.setBackground(getResources().getDrawable(R.drawable.custom_border_notselected_home_layout));
                clutch_break_problem_layout.setBackground(getResources().getDrawable(R.drawable.custom_border_notselected_home_layout));
                fuel_problem_layout.setBackground(getResources().getDrawable(R.drawable.custom_border_notselected_home_layout));
                lost_lock_Key_layout.setBackground(getResources().getDrawable(R.drawable.custom_border_notselected_home_layout));
                Towing_layout.setBackground(getResources().getDrawable(R.drawable.custom_border_selected_home_layout));
                Tyre_Damage_layout.setBackground(getResources().getDrawable(R.drawable.custom_border_notselected_home_layout));
                Other_layout.setBackground(getResources().getDrawable(R.drawable.custom_border_notselected_home_layout));

                continueTextButton.setVisibility(View.VISIBLE);
            }
        });

        // TODO Tyre Damage issue if Puncture tyre or destroyed tyre changes
        Tyre_Damage_layout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                sp.edit().putString(SharedPreferencesData.UserSelectionCount, "Yes").commit();
                sp.edit().putString(SharedPreferencesData.User_TypeOfProblem, "Tyre Problem").commit();
                fuel_problem_Sub_layout.setVisibility(View.GONE);

                TyreSubChoice_radioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
                    @Override
                    public void onCheckedChanged(RadioGroup radioGroup, int i) {
                        RadioButton radioButton = view.findViewById(i);
                        sTyre_subProblem = radioButton.getText().toString();
                    }
                });

                sp.edit().putString(SharedPreferencesData.User_ProblemSubType, sTyre_subProblem).commit();
                Tyre_problem_Sub_layout.setVisibility(View.VISIBLE);

                accident_layout.setBackground(getResources().getDrawable(R.drawable.custom_border_notselected_home_layout));
                battery_layout.setBackground(getResources().getDrawable(R.drawable.custom_border_notselected_home_layout));
                clutch_break_problem_layout.setBackground(getResources().getDrawable(R.drawable.custom_border_notselected_home_layout));
                fuel_problem_layout.setBackground(getResources().getDrawable(R.drawable.custom_border_notselected_home_layout));
                lost_lock_Key_layout.setBackground(getResources().getDrawable(R.drawable.custom_border_notselected_home_layout));
                Towing_layout.setBackground(getResources().getDrawable(R.drawable.custom_border_notselected_home_layout));
                Tyre_Damage_layout.setBackground(getResources().getDrawable(R.drawable.custom_border_selected_home_layout));
                Other_layout.setBackground(getResources().getDrawable(R.drawable.custom_border_notselected_home_layout));

                continueTextButton.setVisibility(View.VISIBLE);
            }
        });

        // TODO Other issue
        Other_layout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                sp.edit().putString(SharedPreferencesData.UserSelectionCount, "Yes").commit();
                sp.edit().putString(SharedPreferencesData.User_TypeOfProblem, "Other issue").commit();
                sp.edit().putString(SharedPreferencesData.User_ProblemSubType, "").commit();
                fuel_problem_Sub_layout.setVisibility(View.GONE);
                Tyre_problem_Sub_layout.setVisibility(View.GONE);

                accident_layout.setBackground(getResources().getDrawable(R.drawable.custom_border_notselected_home_layout));
                battery_layout.setBackground(getResources().getDrawable(R.drawable.custom_border_notselected_home_layout));
                clutch_break_problem_layout.setBackground(getResources().getDrawable(R.drawable.custom_border_notselected_home_layout));
                fuel_problem_layout.setBackground(getResources().getDrawable(R.drawable.custom_border_notselected_home_layout));
                lost_lock_Key_layout.setBackground(getResources().getDrawable(R.drawable.custom_border_notselected_home_layout));
                Towing_layout.setBackground(getResources().getDrawable(R.drawable.custom_border_notselected_home_layout));
                Tyre_Damage_layout.setBackground(getResources().getDrawable(R.drawable.custom_border_notselected_home_layout));
                Other_layout.setBackground(getResources().getDrawable(R.drawable.custom_border_selected_home_layout));

                continueTextButton.setVisibility(View.VISIBLE);
            }
        });


        continueTextButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                continueTextButton.setVisibility(View.GONE);

                if (sp.getString(SharedPreferencesData.UserSelectionCount, "").equals("Yes")) {
                    if (sp.getString(SharedPreferencesData.User_TypeOfProblem, "").equals("Fuel Problem")) {
                        if (sfuel_subProblem.isEmpty() || sfuel_subProblem.equalsIgnoreCase("")) {
                            new CommonMethod(getActivity(), "Please Select Fuel Problem Type");
                        }
                        else {
                            new CommonMethod(getContext(), UserForemanServicesActivity.class);
                        }
                    } else if (sp.getString(SharedPreferencesData.User_TypeOfProblem, "").equals("Tyre Problem")) {
                        if (TyreSubChoice_radioGroup.getCheckedRadioButtonId() == -1) {
                            new CommonMethod(getActivity(), "");
                            Toast.makeText(getActivity(), "Please Select Tyre Damage Type", Toast.LENGTH_SHORT).show();
                        } else {

//                            sp.edit().putString(SharedPreferencesData.User_ServiceID, "").commit();
//                            sp.edit().putString(SharedPreferencesData.User_ForemanFirstName, "").commit();
//                            sp.edit().putString(SharedPreferencesData.User_ForemanLastName, "").commit();
//                            sp.edit().putString(SharedPreferencesData.User_ForemanProfileImage, "").commit();
//
//                            sp.edit().putString(SharedPreferencesData.User_TypeOfProblem, "").commit();
//                            sp.edit().putString(SharedPreferencesData.User_ProblemSubType, "").commit();
//                            sp.edit().putString(SharedPreferencesData.User_FixCharge, "").commit();
//                            sp.edit().putString(SharedPreferencesData.User_ForemanID, "").commit();
//                            sp.edit().putString(SharedPreferencesData.User_ForemanMobileNumber, "").commit();
//                            sp.edit().putString(SharedPreferencesData.User_SPReqMoney, "").commit();


                            new CommonMethod(getContext(), UserForemanServicesActivity.class);
                        }
                    } else {

//                        sp.edit().putString(SharedPreferencesData.User_ServiceID, "").commit();
//                        sp.edit().putString(SharedPreferencesData.User_ForemanFirstName, "").commit();
//                        sp.edit().putString(SharedPreferencesData.User_ForemanLastName, "").commit();
//                        sp.edit().putString(SharedPreferencesData.User_ForemanProfileImage, "").commit();
//
//                        sp.edit().putString(SharedPreferencesData.User_TypeOfProblem, "").commit();
//                        sp.edit().putString(SharedPreferencesData.User_ProblemSubType, "").commit();
//                        sp.edit().putString(SharedPreferencesData.User_FixCharge, "").commit();
//                        sp.edit().putString(SharedPreferencesData.User_ForemanID, "").commit();
//                        sp.edit().putString(SharedPreferencesData.User_ForemanMobileNumber, "").commit();
//                        sp.edit().putString(SharedPreferencesData.User_SPReqMoney, "").commit();

                        new CommonMethod(getContext(), UserForemanServicesActivity.class);
                    }
                } else {
                    new CommonMethod(getActivity(), "Please Select Any One Option");
                }

            }
        });

        return view;
    }
}