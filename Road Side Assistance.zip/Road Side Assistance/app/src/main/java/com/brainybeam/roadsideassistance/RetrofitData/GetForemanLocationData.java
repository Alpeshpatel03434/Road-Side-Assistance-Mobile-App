package com.brainybeam.roadsideassistance.RetrofitData;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.List;

public class GetForemanLocationData {

    @SerializedName("Status")
    @Expose
    public Boolean status;
    @SerializedName("Message")
    @Expose
    public String message;
    @SerializedName("response")
    @Expose
    public List<GetForemanLocationResponse> response = null;

    public class GetForemanLocationResponse {

        @SerializedName("ForemanLocationID")
        @Expose
        public String foremanLocationID;
        @SerializedName("ForemanID")
        @Expose
        public String foremanID;
        @SerializedName("UserID")
        @Expose
        public String userID;
        @SerializedName("ForemanLatitude")
        @Expose
        public String foremanLatitude;
        @SerializedName("ForemanLongitude")
        @Expose
        public String foremanLongitude;

    }

}
