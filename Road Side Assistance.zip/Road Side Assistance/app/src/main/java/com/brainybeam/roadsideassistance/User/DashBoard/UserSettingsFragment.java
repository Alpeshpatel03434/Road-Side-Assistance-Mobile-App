package com.brainybeam.roadsideassistance.User.DashBoard;

import android.app.ProgressDialog;
import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.brainybeam.roadsideassistance.Login.LoginActivity;
import com.brainybeam.roadsideassistance.R;
import com.brainybeam.roadsideassistance.RetrofitData.DeleteUserORForemanData;
import com.brainybeam.roadsideassistance.Utils.ApiClient;
import com.brainybeam.roadsideassistance.Utils.ApiInterface;
import com.brainybeam.roadsideassistance.Utils.CommonMethod;
import com.brainybeam.roadsideassistance.Utils.SharedPreferencesData;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


public class UserSettingsFragment extends Fragment {


    LinearLayout ProfileDelete_layout, ProfileDeActivate_layout;

    ImageView ProfileDelete_imageview_logo, ProfileDeActivate_imageview_logo;

    TextView ProfileDelete_TextButton, ProfileDeActivate_TextButton;

    ApiInterface apiInterface;
    SharedPreferences sp;
    ProgressDialog pd;

    public UserSettingsFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_user_settings, container, false);

        sp = getActivity().getSharedPreferences(SharedPreferencesData.PREF, getActivity().MODE_PRIVATE);
        apiInterface = ApiClient.getClient().create(ApiInterface.class);


        ProfileDelete_layout = view.findViewById(R.id.frag_user_setting_profileDelete_layout);
        ProfileDeActivate_layout = view.findViewById(R.id.frag_user_setting_profileDeactivate_layout);

        ProfileDelete_imageview_logo = view.findViewById(R.id.frag_user_setting_profileDelete_imageview_logo);
        ProfileDeActivate_imageview_logo = view.findViewById(R.id.frag_user_setting_profileDeactivate_imageview_logo);

        ProfileDelete_TextButton = view.findViewById(R.id.frag_user_setting_profileDelete_TextButton);
        ProfileDeActivate_TextButton = view.findViewById(R.id.frag_user_setting_profileDeactivate_TextButton);


        // TODO User Profile Delete
        ProfileDelete_TextButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DeleteUserProfile();
            }
        });

        ProfileDelete_imageview_logo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DeleteUserProfile();
            }
        });

        ProfileDelete_layout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DeleteUserProfile();
            }
        });


        // TODO User Profile Deactivate
        ProfileDeActivate_TextButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DeactivateUserAccount();
            }
        });

        ProfileDeActivate_imageview_logo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DeactivateUserAccount();
            }
        });

        ProfileDeActivate_layout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DeactivateUserAccount();
            }
        });

        return view;
    }

    private void DeactivateUserAccount() {


        Call<DeleteUserORForemanData> call = apiInterface.DeactivateUserData(
                sp.getString(SharedPreferencesData.UserID, "")
        );

        call.enqueue(new Callback<DeleteUserORForemanData>() {
            @Override
            public void onResponse(Call<DeleteUserORForemanData> call, Response<DeleteUserORForemanData> response) {
                if(response.code()==200){

                    if (response.body().status==true){
                        new CommonMethod(getActivity(), "Your Account SuccessFully Deactivate");
                        new CommonMethod(getActivity(), LoginActivity.class);
                    } else {
                        new CommonMethod(getActivity(), response.body().message);
                    }

                } else {
                    new CommonMethod(getActivity(), "Server Error Code "+response.code());
                }

            }

            @Override
            public void onFailure(Call<DeleteUserORForemanData> call, Throwable t) {
                new CommonMethod(getActivity(), t.getMessage());
            }
        });

    }

    private void DeleteUserProfile() {

        Call<DeleteUserORForemanData> call = apiInterface.DeleteUserAccountData(
                sp.getString(SharedPreferencesData.UserID, "")
        );

        call.enqueue(new Callback<DeleteUserORForemanData>() {
            @Override
            public void onResponse(Call<DeleteUserORForemanData> call, Response<DeleteUserORForemanData> response) {

                if(response.code()==200){

                    if(response.body().status==true){
                        new CommonMethod(getActivity(), "Delete SuccessFully");
                        new CommonMethod(getActivity(), LoginActivity.class);
                        sp.edit().clear();
                    } else {
                        new CommonMethod(getActivity(), response.body().message);
                    }

                } else {
                    new CommonMethod(getActivity(), "Server Error Code : "+response.code());
                }

            }

            @Override
            public void onFailure(Call<DeleteUserORForemanData> call, Throwable t) {

            }
        });

    }

}