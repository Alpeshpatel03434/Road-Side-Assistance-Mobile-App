package com.brainybeam.roadsideassistance.User.CustomArrayList;

public class UserHistoryList {

    String HistoryID, ServiceID, ForemanID, UserID, VehicleID;
    String ProblemDescriptionMessage;
    String PaymentID, SPReqMoney, PaymentMode, Payment, UserLocation, PaymentDate;
    String ForemanFirstName, ForemanLastName, ForemanProfileImage, ForemanMobileNumber, ForemanFullAddress;
    String TypeOfProblem, ProblemSubType, ServiceFixedCharge;
    String VehicleNumber, TypeOfVehicle, VehicleModelName, VehicleColor;

    public String getHistoryID() {
        return HistoryID;
    }

    public void setHistoryID(String historyID) {
        HistoryID = historyID;
    }

    public String getServiceID() {
        return ServiceID;
    }

    public void setServiceID(String serviceID) {
        ServiceID = serviceID;
    }

    public String getForemanID() {
        return ForemanID;
    }

    public void setForemanID(String foremanID) {
        ForemanID = foremanID;
    }

    public String getUserID() {
        return UserID;
    }

    public void setUserID(String userID) {
        UserID = userID;
    }

    public String getVehicleID() {
        return VehicleID;
    }

    public void setVehicleID(String vehicleID) {
        VehicleID = vehicleID;
    }

    public String getProblemDescriptionMessage() {
        return ProblemDescriptionMessage;
    }

    public void setProblemDescriptionMessage(String problemDescriptionMessage) {
        ProblemDescriptionMessage = problemDescriptionMessage;
    }

    public String getPaymentID() {
        return PaymentID;
    }

    public void setPaymentID(String paymentID) {
        PaymentID = paymentID;
    }

    public String getSPReqMoney() {
        return SPReqMoney;
    }

    public void setSPReqMoney(String SPReqMoney) {
        this.SPReqMoney = SPReqMoney;
    }

    public String getPaymentMode() {
        return PaymentMode;
    }

    public void setPaymentMode(String paymentMode) {
        PaymentMode = paymentMode;
    }

    public String getPayment() {
        return Payment;
    }

    public void setPayment(String payment) {
        Payment = payment;
    }

    public String getUserLocation() {
        return UserLocation;
    }

    public void setUserLocation(String userLocation) {
        UserLocation = userLocation;
    }

    public String getPaymentDate() {
        return PaymentDate;
    }

    public void setPaymentDate(String paymentDate) {
        PaymentDate = paymentDate;
    }

    public String getForemanFirstName() {
        return ForemanFirstName;
    }

    public void setForemanFirstName(String foremanFirstName) {
        ForemanFirstName = foremanFirstName;
    }

    public String getForemanLastName() {
        return ForemanLastName;
    }

    public void setForemanLastName(String foremanLastName) {
        ForemanLastName = foremanLastName;
    }

    public String getForemanProfileImage() {
        return ForemanProfileImage;
    }

    public void setForemanProfileImage(String foremanProfileImage) {
        ForemanProfileImage = foremanProfileImage;
    }

    public String getForemanMobileNumber() {
        return ForemanMobileNumber;
    }

    public void setForemanMobileNumber(String foremanMobileNumber) {
        ForemanMobileNumber = foremanMobileNumber;
    }

    public String getForemanFullAddress() {
        return ForemanFullAddress;
    }

    public void setForemanFullAddress(String foremanFullAddress) {
        ForemanFullAddress = foremanFullAddress;
    }

    public String getTypeOfProblem() {
        return TypeOfProblem;
    }

    public void setTypeOfProblem(String typeOfProblem) {
        TypeOfProblem = typeOfProblem;
    }

    public String getProblemSubType() {
        return ProblemSubType;
    }

    public void setProblemSubType(String problemSubType) {
        ProblemSubType = problemSubType;
    }

    public String getServiceFixedCharge() {
        return ServiceFixedCharge;
    }

    public void setServiceFixedCharge(String serviceFixedCharge) {
        ServiceFixedCharge = serviceFixedCharge;
    }

    public String getVehicleNumber() {
        return VehicleNumber;
    }

    public void setVehicleNumber(String vehicleNumber) {
        VehicleNumber = vehicleNumber;
    }

    public String getTypeOfVehicle() {
        return TypeOfVehicle;
    }

    public void setTypeOfVehicle(String typeOfVehicle) {
        TypeOfVehicle = typeOfVehicle;
    }

    public String getVehicleModelName() {
        return VehicleModelName;
    }

    public void setVehicleModelName(String vehicleModelName) {
        VehicleModelName = vehicleModelName;
    }

    public String getVehicleColor() {
        return VehicleColor;
    }

    public void setVehicleColor(String vehicleColor) {
        VehicleColor = vehicleColor;
    }

}
