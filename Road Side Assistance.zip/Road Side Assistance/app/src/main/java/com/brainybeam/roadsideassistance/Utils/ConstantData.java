package com.brainybeam.roadsideassistance.Utils;

import android.widget.LinearLayout;

import java.math.BigInteger;

public class ConstantData {

    public static final String ProjectName = "Road Side Assistance";
    public static final String Call_Assistance_MobileNumber = "+919979663217";

    public static final String State[] = { "Andhra Pradesh",
            "Arunachal Pradesh",
            "Assam",
            "Bihar",
            "Chhattisgarh",
            "Goa",
            "Gujarat",
            "Haryana",
            "Himachal Pradesh",
            "Jammu and Kashmir",
            "Jharkhand",
            "Karnataka",
            "Kerala",
            "Madhya Pradesh",
            "Maharashtra",
            "Manipur",
            "Meghalaya",
            "Mizoram",
            "Nagaland",
            "Odisha",
            "Punjab",
            "Rajasthan",
            "Sikkim",
            "Tamil Nadu",
            "Telangana",
            "Tripura",
            "Uttarakhand",
            "Uttar Pradesh",
            "West Bengal",
            "Andaman and Nicobar Islands",
            "Chandigarh",
            "Dadra and Nagar Haveli",
            "Daman and Diu",
            "Delhi",
            "Lakshadweep",
            "Puducherry"
    };



    public static final String TypeOfProblem[] = {
            "Accident Situation",
            "Battery Discharged/Not Working",
            "Clutch/Break Problem",
            "Fuel Problem",
            "Lost/Lock Key",
            "Towing",
            "Tyre Problem",
            "Other issue"
    };


    public static final String ProblemSubTypeFuel[] = {
            "Out Of Diesel",
            "Out Of Petrol",
            "Wrong Fuel"
    };

    public static final String ProblemSubTypeTyre[] = {
            "Need Repair",
            "Spare Wheel"
    };

    public static final String ProblemSubType[] = {
            "-",
            "Out Of Diesel",
            "Out Of Petrol",
            "Wrong Fuel",
            "Need Repair",
            "Spare Wheel"
    };

    public static final String TypeOfVehicle[] = {
            "2-Wheeler",
            "4-Wheeler",
            "Heavy Motor Vehicles"
    };

    public static final String PaymentMode[] = {
            "Cash",
            "EPayment"
    };

}
