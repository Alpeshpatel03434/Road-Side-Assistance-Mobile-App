package com.brainybeam.roadsideassistance.User.CustomArrayList;

public class UserForemanServiceList {

    String ServiceID;
    String ForemanID;
    String FirstName, LastName, ProfileImage;
    String MobileNumber;
    String FullAddress;
    String TypeOfProblem, ProblemSubType, ServiceFixedCharge;
    String LocationID, Latitude, Longitude;

    String UserLocation;
    String UserLatitude, UserLongitude;
    String Distance;

    public String getUserLocation() {
        return UserLocation;
    }

    public void setUserLocation(String userLocation) {
        UserLocation = userLocation;
    }

    public String getUserLatitude() {
        return UserLatitude;
    }

    public void setUserLatitude(String userLatitude) {
        UserLatitude = userLatitude;
    }

    public String getUserLongitude() {
        return UserLongitude;
    }

    public void setUserLongitude(String userLongitude) {
        UserLongitude = userLongitude;
    }

    public String getDistance() {
        return Distance;
    }

    public void setDistance(String distance) {
        Distance = distance;
    }

    public String getServiceID() {
        return ServiceID;
    }

    public void setServiceID(String serviceID) {
        ServiceID = serviceID;
    }

    public String getForemanID() {
        return ForemanID;
    }

    public void setForemanID(String foremanID) {
        ForemanID = foremanID;
    }

    public String getFirstName() {
        return FirstName;
    }

    public void setFirstName(String firstName) {
        FirstName = firstName;
    }

    public String getLastName() {
        return LastName;
    }

    public void setLastName(String lastName) {
        LastName = lastName;
    }

    public String getProfileImage() {
        return ProfileImage;
    }

    public void setProfileImage(String profileImage) {
        ProfileImage = profileImage;
    }

    public String getMobileNumber() {
        return MobileNumber;
    }

    public void setMobileNumber(String mobileNumber) {
        MobileNumber = mobileNumber;
    }

    public String getFullAddress() {
        return FullAddress;
    }

    public void setFullAddress(String fullAddress) {
        FullAddress = fullAddress;
    }

    public String getTypeOfProblem() {
        return TypeOfProblem;
    }

    public void setTypeOfProblem(String typeOfProblem) {
        TypeOfProblem = typeOfProblem;
    }

    public String getProblemSubType() {
        return ProblemSubType;
    }

    public void setProblemSubType(String problemSubType) {
        ProblemSubType = problemSubType;
    }

    public String getServiceFixedCharge() {
        return ServiceFixedCharge;
    }

    public void setServiceFixedCharge(String serviceFixedCharge) {
        ServiceFixedCharge = serviceFixedCharge;
    }

    public String getLocationID() {
        return LocationID;
    }

    public void setLocationID(String locationID) {
        LocationID = locationID;
    }

    public String getLatitude() {
        return Latitude;
    }

    public void setLatitude(String latitude) {
        Latitude = latitude;
    }

    public String getLongitude() {
        return Longitude;
    }

    public void setLongitude(String longitude) {
        Longitude = longitude;
    }
}
