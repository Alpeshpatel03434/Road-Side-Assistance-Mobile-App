package com.brainybeam.roadsideassistance.Foreman.Activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.ProgressDialog;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.location.Address;
import android.location.Geocoder;
import android.os.Bundle;
import android.view.MenuItem;

import com.brainybeam.roadsideassistance.Foreman.CustomArrayList.ForemanUserSelectedServicesList;
import com.brainybeam.roadsideassistance.Foreman.DashBoard.ForemanUserSelectedServicesAdapter;
import com.brainybeam.roadsideassistance.GPS.GPSTracker;
import com.brainybeam.roadsideassistance.R;
import com.brainybeam.roadsideassistance.RetrofitData.GetForemanUserSelectedServicesData;
import com.brainybeam.roadsideassistance.Utils.ApiClient;
import com.brainybeam.roadsideassistance.Utils.ApiInterface;
import com.brainybeam.roadsideassistance.Utils.CommonMethod;
import com.brainybeam.roadsideassistance.Utils.ConnectionDetector;
import com.brainybeam.roadsideassistance.Utils.SharedPreferencesData;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ForemanHomeNewRequestActivity extends AppCompatActivity {

    RecyclerView recyclerView;

    ArrayList<ForemanUserSelectedServicesList> arrayList;

    ApiInterface apiInterface;
    SharedPreferences sp;
    ProgressDialog pd;

    GPSTracker gpsTracker;
    double CurrentLatitude, CurrentLongitude;

    String sForemanAddress, sForemanLatitude, sForemanLongitude;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_foreman_home_new_request);
        getSupportActionBar().setTitle("New Requests");
        ColorDrawable colorDrawable
                = new ColorDrawable(Color.parseColor("#2196F3"));
        getSupportActionBar().setBackgroundDrawable(colorDrawable);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);


        apiInterface = ApiClient.getClient().create(ApiInterface.class);
        sp = getSharedPreferences(SharedPreferencesData.PREF, MODE_PRIVATE);

        recyclerView = findViewById(R.id.foreman_newUser_requestReceive_recyclerview);

        recyclerView.setLayoutManager(new LinearLayoutManager(ForemanHomeNewRequestActivity.this));
        recyclerView.setItemAnimator(new DefaultItemAnimator());

        GPSTracker gpsTracker = new GPSTracker(ForemanHomeNewRequestActivity.this);

        Geocoder geocoder = new Geocoder(ForemanHomeNewRequestActivity.this, Locale.getDefault());
        List<Address> addresses = null;
        try {
            addresses = geocoder.getFromLocation(gpsTracker.getLatitude(), gpsTracker.getLongitude(), 1);
            String add = addresses.get(0).getAddressLine(0);
            String city = addresses.get(0).getLocality();
            String state = addresses.get(0).getAdminArea();
            String zip = addresses.get(0).getPostalCode();
            String country = addresses.get(0).getCountryName();

            CurrentLatitude = gpsTracker.getLatitude();
            CurrentLongitude = gpsTracker.getLongitude();
            sForemanAddress = add;
        } catch (IOException e) {
            e.printStackTrace();
        }

        sp.edit().putString(SharedPreferencesData.Foreman_ForemanCurrLocation, sForemanAddress).commit();

        if(new ConnectionDetector(ForemanHomeNewRequestActivity.this).isConnectingToInternet()){

            pd = new ProgressDialog(ForemanHomeNewRequestActivity.this);
            pd.setMessage("Please Wait...");
            pd.setCancelable(false);
            pd.show();

            recyclerViewDataSetMethod();

        } else {
            new ConnectionDetector(ForemanHomeNewRequestActivity.this).connectiondetect();
        }

    }

    private void recyclerViewDataSetMethod() {

        Call<GetForemanUserSelectedServicesData> call = apiInterface.GetForemanUserSelectedServicesData(
                sp.getString(SharedPreferencesData.UserID, "")
        );

        call.enqueue(new Callback<GetForemanUserSelectedServicesData>() {
            @Override
            public void onResponse(Call<GetForemanUserSelectedServicesData> call, Response<GetForemanUserSelectedServicesData> response) {

                pd.dismiss();
                if(response.code()==200){

                    if(response.body().status==true){

                        new CommonMethod(ForemanHomeNewRequestActivity.this, response.body().message);

                        arrayList = new ArrayList<>();
                        GetForemanUserSelectedServicesData data = response.body();

                        for(int i=0; i<data.response.size(); i++){
                            ForemanUserSelectedServicesList list = new ForemanUserSelectedServicesList();

                            list.setCartID(data.response.get(i).cartID);
                            list.setServiceID(data.response.get(i).serviceID);
                            list.setForemanID(data.response.get(i).foremanID);
                            list.setUserID(data.response.get(i).userID);
                            list.setProblemDescriptionMessage(data.response.get(i).problemDescriptionMessage+"");
                            list.setSPReqMoney(data.response.get(i).sPReqMoney);
                            list.setPaymentStatus(data.response.get(i).paymentStatus);
                            list.setUserFirstName(data.response.get(i).firstName);
                            list.setUserLastName(data.response.get(i).lastName);
                            list.setUserProfileImage(data.response.get(i).profileImage);
                            list.setUserMobileNumber(data.response.get(i).mobileNumber);
                            list.setUserLocation(data.response.get(i).userLocation+"");
                            list.setTypeOfProblem(data.response.get(i).typeOfProblem);
                            list.setProblemSubType(data.response.get(i).problemSubType);
                            list.setServiceFixedCharge(data.response.get(i).serviceFixedCharge);

                            arrayList.add(list);
                        }

                        ForemanUserSelectedServicesAdapter adapter = new ForemanUserSelectedServicesAdapter(ForemanHomeNewRequestActivity.this, arrayList);
                        recyclerView.setAdapter(adapter);
                        // adapter.notifyDataSetChanged();

                    } else {
                        new CommonMethod(ForemanHomeNewRequestActivity.this, response.body().message);
                    }

                } else {
                    new CommonMethod(ForemanHomeNewRequestActivity.this, "Server Error Code : "+response.code());
                }

            }

            @Override
            public void onFailure(Call<GetForemanUserSelectedServicesData> call, Throwable t) {

                pd.dismiss();
                new CommonMethod(ForemanHomeNewRequestActivity.this, t.getMessage());

            }
        });

    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();
        if (id == android.R.id.home) {
            onBackPressed();
        }
        return super.onOptionsItemSelected(item);
    }
    
}