package com.brainybeam.roadsideassistance.User.Activity;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.brainybeam.roadsideassistance.R;
import com.brainybeam.roadsideassistance.RetrofitData.AddForemanServicesData;
import com.brainybeam.roadsideassistance.RetrofitData.CartAddServicesData;
import com.brainybeam.roadsideassistance.RetrofitData.DeleteUserORForemanData;
import com.brainybeam.roadsideassistance.RetrofitData.SendNotificationData;
import com.brainybeam.roadsideassistance.User.CustomArrayList.UserVehicleList;
import com.brainybeam.roadsideassistance.User.DashBoard.UserVehicleDetailAdapter;
import com.brainybeam.roadsideassistance.Utils.ApiClient;
import com.brainybeam.roadsideassistance.Utils.ApiInterface;
import com.brainybeam.roadsideassistance.Utils.CommonMethod;
import com.brainybeam.roadsideassistance.Utils.MakeServiceCall;
import com.brainybeam.roadsideassistance.Utils.SharedPreferencesData;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.http.Field;

public class UserVehicleSelectionAdapter extends RecyclerView.Adapter<UserVehicleSelectionAdapter.MyHolder> {
    
    Context context;
    ArrayList<UserVehicleList> arrayList;
    ApiInterface apiInterface;
    SharedPreferences sp;
    ProgressDialog pd;

    String sVehicleID;

    ProgressDialog progressDialog;
    AlertDialog.Builder builder;
    
    public UserVehicleSelectionAdapter(Context context, ArrayList<UserVehicleList> arrayList, ApiInterface apiInterface, SharedPreferences sp) {
        this.context = context;
        this.arrayList = arrayList;
        this.apiInterface = apiInterface;
        this.sp = sp;
    }

    @NonNull
    @Override
    public MyHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.custom_user_selection_vehicle, parent, false);

        return new MyHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyHolder holder, @SuppressLint("RecyclerView") int position) {


        holder.UserID.setText(arrayList.get(position).getUserID());
        holder.NumberPlateNumber.setText(arrayList.get(position).getNumberPlate_number());
        holder.TypeofVehicle.setText(arrayList.get(position).getTypeOfVehicle());
        holder.ModelName.setText(arrayList.get(position).getVehicleModelName());
        holder.VehicleColor.setText(arrayList.get(position).getVehicle_Colour());

        holder.SelectButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                pd = new ProgressDialog(context);
                pd.setMessage("Please Wait...");
                pd.setCancelable(false);
                pd.show();

                sVehicleID = arrayList.get(position).getVehicleID();
                sp.edit().putString(SharedPreferencesData.User_VehicleID, arrayList.get(position).getVehicleID()).commit();
                sp.edit().putString(SharedPreferencesData.User_NumberPlate_number, arrayList.get(position).getNumberPlate_number()).commit();
                sp.edit().putString(SharedPreferencesData.User_TypeOfVehicle, arrayList.get(position).getTypeOfVehicle()).commit();
                sp.edit().putString(SharedPreferencesData.User_VehicleModelName, arrayList.get(position).getVehicleModelName()).commit();
                sp.edit().putString(SharedPreferencesData.User_Vehicle_Colour, arrayList.get(position).getVehicle_Colour()).commit();

                // new CartStore().execute();
                StoreDataInCart(arrayList.get(position).getUserID());
               // storeDataInOdredtb(arrayList.get(position).getUserID());
                SendNotificationToForeman();
//                SendNotificationToForemanStoringServiceID();
//                SendNotificationToForemanStoringUserID();


                builder = new AlertDialog.Builder(context);
                builder.setCancelable(false);
                builder.setPositiveButton("Check Status", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {

                        progressDialog =  new ProgressDialog(context);
                        progressDialog.setTitle("Request Accepting by Foreman...");
                        progressDialog.setCancelable(false);
                        progressDialog.show();

                        StatusCheck();
                      //  new CommonMethod(context, UserTrackingActivity.class);
                    }
                });

                builder.setNegativeButton("ReSelect", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        dialogInterface.dismiss();
                    }
                });
                builder.show();
            }
        });

    }

    private void StatusCheck() {

        Call<DeleteUserORForemanData> call = apiInterface.GetRequestStatusData(
                sp.getString(SharedPreferencesData.User_CartID, "")
        );

        call.enqueue(new Callback<DeleteUserORForemanData>() {
            @Override
            public void onResponse(Call<DeleteUserORForemanData> call, Response<DeleteUserORForemanData> response) {
                progressDialog.dismiss();
                if(response.code()==200){

                    if(response.body().status==true){

                        new CommonMethod(context, UserTrackingActivity.class);

                    } else {
                        new CommonMethod(context, response.body().message);
                    }

                } else {
                    new CommonMethod(context, "Server Error Code : "+response.code());
                }

            }

            @Override
            public void onFailure(Call<DeleteUserORForemanData> call, Throwable t) {
                progressDialog.dismiss();
                new CommonMethod(context, t.getMessage());
            }
        });

    }

    @Override
    public int getItemCount() {
        return arrayList.size();
    }

    public class MyHolder extends RecyclerView.ViewHolder {

        TextView UserID, NumberPlateNumber, TypeofVehicle, ModelName, VehicleColor;
        Button SelectButton;

        String UserLatitude, UserLongitude;

        public MyHolder(@NonNull View itemView) {
            super(itemView);
            
            UserID = itemView.findViewById(R.id.custom_user_selection_vehicle_UserID);
            NumberPlateNumber = itemView.findViewById(R.id.custom_user_selection_vehicle_NumberPlate);
            TypeofVehicle = itemView.findViewById(R.id.custom_user_selection_vehicle_TypeOfVehicle);
            ModelName = itemView.findViewById(R.id.custom_user_selection_vehicle_ModelName);
            VehicleColor = itemView.findViewById(R.id.custom_user_selection_vehicle_VehicleColor);

            SelectButton = itemView.findViewById(R.id.custom_user_selection_vehicle_SelectButton);

        }
    }


    private void SendNotificationToForeman() {

        String Title = "UserID - "+sp.getString(SharedPreferencesData.UserID, "")+" "+sp.getString(SharedPreferencesData.FirstName, "")+" "+"Request For Services";
        String Message = "Type Of Problem : "+sp.getString(SharedPreferencesData.User_TypeOfProblem, "")+" Sub Problem Type : "+sp.getString(SharedPreferencesData.User_ProblemSubType, ""
        +" "+"Vehicle RTO Number : "+sp.getString(SharedPreferencesData.User_NumberPlate_number, "")+" "+" Type Of Vehicle : "+sp.getString(SharedPreferencesData.User_TypeOfVehicle, ""));

        Call<SendNotificationData> call = apiInterface.SendToForemanNotificationData(
                sp.getString(SharedPreferencesData.User_ForemanID, ""),
                Title,
                Message
        );

        call.enqueue(new Callback<SendNotificationData>() {
            @Override
            public void onResponse(Call<SendNotificationData> call, Response<SendNotificationData> response) {

                pd.dismiss();
                if(response.code()==200){

                    if(response.body().status==true){
                        new CommonMethod(context, response.body().message);
                    } else {
                        new CommonMethod(context, response.body().message);
                    }

                } else {
                    new CommonMethod(context, "Server Error Code : "+response.code());
                }

            }

            @Override
            public void onFailure(Call<SendNotificationData> call, Throwable t) {
                pd.dismiss();
                new CommonMethod(context, t.getMessage());
            }
        });

    }

    private void StoreDataInCart(String UserID){

        Call<CartAddServicesData> call = apiInterface.AddCartData(
                sp.getString(SharedPreferencesData.User_ServiceID, ""),
                sp.getString(SharedPreferencesData.User_ForemanID, ""),
                UserID,
                sVehicleID,
                sp.getString(SharedPreferencesData.User_SPReqMoney, ""),
                sp.getString(SharedPreferencesData.User_UserLocation, ""),
                sp.getString(SharedPreferencesData.User_PaymentStatus, "")
        );

        call.enqueue(new Callback<CartAddServicesData>() {
            @Override
            public void onResponse(Call<CartAddServicesData> call, Response<CartAddServicesData> response) {

                if(response.code()==200){

                    if(response.body().status==true){
                        new CommonMethod(context, "SuccessFully Request Send to Service Provider");
                    } else {
                        new CommonMethod(context, response.body().message);
                    }

                } else {
                    new CommonMethod(context, "Server Error Code : "+response.code());
                }

            }

            @Override
            public void onFailure(Call<CartAddServicesData> call, Throwable t) {
                new CommonMethod(context, t.getMessage());
            }
        });

    }


}
