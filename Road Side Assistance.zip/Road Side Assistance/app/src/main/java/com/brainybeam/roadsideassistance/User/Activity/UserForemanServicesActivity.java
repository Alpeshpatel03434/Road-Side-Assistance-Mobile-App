package com.brainybeam.roadsideassistance.User.Activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.Manifest;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationManager;
import android.os.Bundle;
import android.view.MenuItem;

import com.brainybeam.roadsideassistance.GPS.GPSTracker;
import com.brainybeam.roadsideassistance.R;
import com.brainybeam.roadsideassistance.RetrofitData.GetUserRequestServicesData;
import com.brainybeam.roadsideassistance.User.CustomArrayList.UserForemanServiceList;
import com.brainybeam.roadsideassistance.Utils.ApiClient;
import com.brainybeam.roadsideassistance.Utils.ApiInterface;
import com.brainybeam.roadsideassistance.Utils.CommonMethod;
import com.brainybeam.roadsideassistance.Utils.ConnectionDetector;
import com.brainybeam.roadsideassistance.Utils.SharedPreferencesData;

import java.io.IOException;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class UserForemanServicesActivity extends AppCompatActivity {

    RecyclerView servicesRecyclerview;
    ArrayList<UserForemanServiceList> arrayList;


    ApiInterface apiInterface;
    SharedPreferences sp;
    ProgressDialog pd;
    GPSTracker gpsTracker;
    double CurrentLatitude, CurrentLongitude;
    double DriverLatitude, DriverLongitude;

    String sUserAddress, sUserLatitude, sUserLongitude;

    private static final int REQUEST_LOCATION = 1;
    LocationManager locationManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_foreman_services);
        // getSupportActionBar().hide();
        getSupportActionBar().setTitle("Service Provider");
        ColorDrawable colorDrawable
                = new ColorDrawable(Color.parseColor("#2196F3"));
        getSupportActionBar().setBackgroundDrawable(colorDrawable);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);


        apiInterface = ApiClient.getClient().create(ApiInterface.class);
        sp = getSharedPreferences(SharedPreferencesData.PREF, MODE_PRIVATE);

        servicesRecyclerview = findViewById(R.id.user_foremanServices_recyclerview);
        servicesRecyclerview.setLayoutManager(new LinearLayoutManager(UserForemanServicesActivity.this));
        servicesRecyclerview.setItemAnimator(new DefaultItemAnimator());

        gpsTracker = new GPSTracker(UserForemanServicesActivity.this);

        // Check if GPS enabled
        if(gpsTracker.canGetLocation()) {

            CurrentLatitude = gpsTracker.getLatitude();
            CurrentLongitude = gpsTracker.getLongitude();

         //   getLocation();

        } else {
            // Can't get location.
            // GPS or network is not enabled.
            // Ask user to enable GPS/network in settings.
            gpsTracker.showSettingsAlert();
        }

        if(new ConnectionDetector(UserForemanServicesActivity.this).isConnectingToInternet()){


            pd = new ProgressDialog(UserForemanServicesActivity.this);
            pd.setMessage("Please Wait...");
            pd.setCancelable(false);
            pd.show();
            getServicesData();
        }
        else{
            new ConnectionDetector(UserForemanServicesActivity.this).connectiondetect();
        }

    }

    private void getLocation() {
        if (ActivityCompat.checkSelfPermission(
                UserForemanServicesActivity.this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(
                UserForemanServicesActivity.this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(UserForemanServicesActivity.this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, REQUEST_LOCATION);
        } else {
            Location locationGPS = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
            if (locationGPS != null) {
                double lat = locationGPS.getLatitude();
                double longi = locationGPS.getLongitude();
                CurrentLatitude = lat;
                CurrentLongitude = longi;
            } else {
                new CommonMethod(UserForemanServicesActivity.this, "Not Found");
            }
        }
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();
        if(id==android.R.id.home){
            onBackPressed();
        }

        return super.onOptionsItemSelected(item);
    }

    private void getServicesData() {

        Call<GetUserRequestServicesData> call = apiInterface.GetUserRequestServicesData(
                sp.getString(SharedPreferencesData.User_TypeOfProblem, "")
        );

        call.enqueue(new Callback<GetUserRequestServicesData>() {
            @Override
            public void onResponse(Call<GetUserRequestServicesData> call, Response<GetUserRequestServicesData> response) {

                pd.dismiss();
                if(response.code()==200){

                    if(response.body().status==true){

                        arrayList = new ArrayList<>();
                        GetUserRequestServicesData data = response.body();
                        for(int i=0; i<data.response.size(); i++){

                            UserForemanServiceList list = new UserForemanServiceList();

                            list.setServiceID(data.response.get(i).serviceID);
                            list.setForemanID(data.response.get(i).foremanID);
                            list.setFirstName(data.response.get(i).firstName);
                            list.setLastName(data.response.get(i).lastName);
                            list.setProfileImage(data.response.get(i).profileImage);
                            list.setMobileNumber(data.response.get(i).mobileNumber);
                            list.setFullAddress(data.response.get(i).address);
                            list.setTypeOfProblem(data.response.get(i).typeOfProblem);
                            list.setProblemSubType(data.response.get(i).problemSubType);
                            list.setServiceFixedCharge(data.response.get(i).serviceFixedCharge);
                            list.setLocationID(data.response.get(i).locationID);
                            list.setLatitude(data.response.get(i).latitude);
                            list.setLongitude(data.response.get(i).longitude);

                            Geocoder coder = new Geocoder(UserForemanServicesActivity.this);
                            List<Address> address;
                            try {
                                // May throw an IOException
                                address = coder.getFromLocationName(data.response.get(i).address, 5);
                                if (address == null) {
                                    DriverLatitude = 0.00;
                                    DriverLongitude = 0.00;
                                }
                                Address location = address.get(0);

                                DriverLatitude = location.getLatitude();
                                DriverLongitude = location.getLongitude();
                                //p1 = new LatLng(location.getLatitude(), location.getLongitude() );

                            } catch (IOException ex) {

                                ex.printStackTrace();
                            }


                            // GPSTracker gpsTracker = new GPSTracker(UserForemanServicesActivity.this);

//                            Geocoder geocoder = new Geocoder(UserForemanServicesActivity.this, Locale.getDefault());
//                            List<Address> addresses = null;
//                            try {
//                                addresses = geocoder.getFromLocation(CurrentLatitude, CurrentLongitude, 1);
//                                String add = addresses.toString();
//
//                                // sForemanAddress = add;
//                            } catch (IOException e) {
//                                e.printStackTrace();
//                            }

                            list.setUserLocation(sUserAddress);

                            // TODO User Location
                            Location startPoint = new Location("locationA");
                            list.setUserLatitude(String.valueOf(CurrentLatitude));
                            list.setUserLongitude(String.valueOf(CurrentLongitude));
                            startPoint.setLatitude(CurrentLatitude);
                            startPoint.setLongitude(CurrentLongitude);

                            // TODO Foreman Location
                            Location endPoint = new Location("locationA");
                            endPoint.setLatitude(DriverLatitude);
                            endPoint.setLongitude(DriverLongitude);
                            DecimalFormat precision = new DecimalFormat("0.00");
                            double distance = Double.parseDouble(precision.format(startPoint.distanceTo(endPoint) / 1000));
                            list.setDistance(String.valueOf(distance));

                            arrayList.add(list);
                        }

                    UserForemanServiceAdapter adapter = new UserForemanServiceAdapter(UserForemanServicesActivity.this, arrayList);
                    servicesRecyclerview.setAdapter(adapter);
                    Collections.sort(arrayList, new AscendingComparator());
                    adapter.notifyDataSetChanged();

                } else {
                        new CommonMethod(UserForemanServicesActivity.this, response.body().message);
                    }

                } else {
                    new CommonMethod(UserForemanServicesActivity.this, "Server Error code "+response.code());
                }

            }

            @Override
            public void onFailure(Call<GetUserRequestServicesData> call, Throwable t) {
                pd.dismiss();
                new CommonMethod(UserForemanServicesActivity.this, t.getMessage());
            }
        });

    }

    public class AscendingComparator implements Comparator<UserForemanServiceList> {
        @Override
        public int compare(UserForemanServiceList o1, UserForemanServiceList o2) {
            int pM1 = Math.round(Float.parseFloat(o1.getDistance()));
            int pM2 = Math.round(Float.parseFloat(o2.getDistance()));
            if (pM1 > pM2) {
                return 1;
            } else if ((pM1 < pM2)) {
                return -1;
            } else {
                return 0;
            }
        }
    }


}