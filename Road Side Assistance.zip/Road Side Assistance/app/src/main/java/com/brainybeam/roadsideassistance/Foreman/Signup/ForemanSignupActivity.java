package com.brainybeam.roadsideassistance.Foreman.Signup;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

import com.brainybeam.roadsideassistance.OTPVerification.OTPVerificationActivity;
import com.brainybeam.roadsideassistance.R;
import com.brainybeam.roadsideassistance.User.Signup.UserSignupActivity;
import com.brainybeam.roadsideassistance.Utils.CommonMethod;
import com.brainybeam.roadsideassistance.Utils.ConnectionDetector;
import com.brainybeam.roadsideassistance.Utils.ConstantData;
import com.brainybeam.roadsideassistance.Utils.SharedPreferencesData;
import com.google.firebase.FirebaseApp;
import com.google.firebase.FirebaseException;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.PhoneAuthCredential;
import com.google.firebase.auth.PhoneAuthOptions;
import com.google.firebase.auth.PhoneAuthProvider;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.TimeUnit;

public class ForemanSignupActivity extends AppCompatActivity {

    private EditText FirstName, LastName, MobileNumber, Email, Password, Address, Area, City;
    private TextView State;
    private Spinner Spinner_State;
    private Button GetOTP;

    private ArrayList<String> arrayList;
    private ProgressDialog pd;
    private String EmailPattern = "[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+";

    private FirebaseAuth mAuth;
    private PhoneAuthProvider.OnVerificationStateChangedCallbacks mCallbacks;

    private String sPhone, sMail;
    private SharedPreferences sp;
    FirebaseApp firebaseApp;

    Bundle bundle;

    private String sFirstName, sLastName, sMobileNumber, sEmail, sPassword, sAddress, sArea, sCity, sState;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_foreman_signup);

        firebaseApp = FirebaseApp.initializeApp(getApplicationContext());
        mAuth = FirebaseAuth.getInstance();
        sp = getSharedPreferences(SharedPreferencesData.PREF, MODE_PRIVATE);

        FirstName = findViewById(R.id.foremanSignup_FirstName);
        LastName = findViewById(R.id.foremanSignup_LastName);
        MobileNumber = findViewById(R.id.foremanSignup_MobileNumber);
        Email = findViewById(R.id.foremanSignup_Email);
        Password = findViewById(R.id.foremanSignup_Password);
        Address = findViewById(R.id.foremanSignup_Address);
        Area = findViewById(R.id.foremanSignup_Area);
        City = findViewById(R.id.foremanSignup_City);
        State = findViewById(R.id.foremanSignup_State);
        Spinner_State = findViewById(R.id.foremanSignup_State_Spinner);
        GetOTP = findViewById(R.id.foremanSignup_GetOTPButton);

        arrayList = new ArrayList<>();

        arrayList.add("-");
        String S_array[] = ConstantData.State;

        List<String> list;
        list =Arrays.asList(S_array);
        arrayList.addAll(list);


        ArrayAdapter adapter = new ArrayAdapter(ForemanSignupActivity.this, android.R.layout.simple_list_item_1, arrayList);
        adapter.setDropDownViewResource(android.R.layout.simple_list_item_activated_1);
        Spinner_State.setAdapter(adapter);

        Spinner_State.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                State.setText(arrayList.get(i));
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });


        GetOTP.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (new ConnectionDetector(ForemanSignupActivity.this).isConnectingToInternet()) {

                    sFirstName = FirstName.getText().toString();
                    sLastName = LastName.getText().toString();
                    sMobileNumber = MobileNumber.getText().toString();
                    sEmail = Email.getText().toString();
                    sPassword = Password.getText().toString();
                    sAddress = Address.getText().toString();
                    sArea = Area.getText().toString();
                    sCity = City.getText().toString();
                    sState = State.getText().toString();

                    if(sFirstName.isEmpty() || sFirstName.equalsIgnoreCase(" ")){
                        FirstName.setError("FirstName is Required");
                    } else if(sLastName.isEmpty() || sLastName.equalsIgnoreCase(" ")){
                        LastName.setError("LastName is Required");
                    } else if(sMobileNumber.isEmpty() || sMobileNumber.equalsIgnoreCase(" ")){
                        MobileNumber.setError("Mobile number is Required");
                    } else if(sMobileNumber.length()<10 && sMobileNumber.length()>10){
                        MobileNumber.setError("Valid Mobile Number is Required");
                    } else if(sEmail.isEmpty() || sEmail.equalsIgnoreCase(" ")){
                        Email.setError("Email is Required");
                    } else if(!sEmail.matches(EmailPattern)){
                        Email.setError("Valid Email is Required");
                    } else if(sPassword.isEmpty() || sPassword.equalsIgnoreCase(" ")){
                        Password.setError("Password is Required");
                    } else if(sPassword.length()<8){
                        Password.setError("Password must be 8 char long");
                    } else if(sAddress.isEmpty() || sAddress.equalsIgnoreCase(" ")){
                        Address.setError("Address");
                    } else if(sArea.isEmpty() || sArea.equalsIgnoreCase(" ")){
                        Area.setError("Area");
                    } else if(sCity.isEmpty() || sCity.equalsIgnoreCase(" ")){
                        City.setError("City");
                    } else if(sState.equalsIgnoreCase("Select State") || sState.equalsIgnoreCase(" ") || sState.equalsIgnoreCase("-")){
                        State.setError("Please Select State");
                    } else {


                        pd = new ProgressDialog(ForemanSignupActivity.this);
                        pd.setMessage("Please Wait...");
                        pd.setCancelable(false);
                        pd.show();

                        sp.edit().putString(SharedPreferencesData.UserType, "Foreman").commit();
                        sp.edit().putString(SharedPreferencesData.FirstName, sFirstName).commit();
                        sp.edit().putString(SharedPreferencesData.LastName, sLastName).commit();
                        sp.edit().putString(SharedPreferencesData.MobileNumber, sMobileNumber).commit();
                        sp.edit().putString(SharedPreferencesData.Email, sEmail).commit();
                        sp.edit().putString(SharedPreferencesData.Password, sPassword).commit();
                        sp.edit().putString(SharedPreferencesData.ForemanAddress, sAddress).commit();
                        sp.edit().putString(SharedPreferencesData.ForemanArea, sArea).commit();
                        sp.edit().putString(SharedPreferencesData.ForemanCity, sCity).commit();
                        sp.edit().putString(SharedPreferencesData.ForemanState, sState).commit();

                        bundle = new Bundle();
                        sPhone = sMobileNumber;
                        // TODO OTP Send to MObile Method
                        otpSendToMobile(sPhone);
                        sMail = sEmail;
                        pd.show();

                    }


                } else {
                    new ConnectionDetector(ForemanSignupActivity.this).connectiondetect();
                }

            }
        });

    }


    private void otpSendToMobile(String sPhone) {

        mCallbacks = new PhoneAuthProvider.OnVerificationStateChangedCallbacks() {

            @Override
            public void onVerificationCompleted(PhoneAuthCredential credential) {

            }

            @Override
            public void onVerificationFailed(FirebaseException e) {
                pd.dismiss();
                new CommonMethod(ForemanSignupActivity.this, e.getLocalizedMessage());
            }

            @Override
            public void onCodeSent(@NonNull String VerificationId,
                                   @NonNull PhoneAuthProvider.ForceResendingToken token) {
                pd.dismiss();

                new CommonMethod(ForemanSignupActivity.this, "OTP is successFully Send");

                bundle.putString("PhoneNumber", sPhone.trim());
                bundle.putString("Mobile_VerificationID", VerificationId);
                Intent intent = new Intent(ForemanSignupActivity.this, OTPVerificationActivity.class);
                intent.putExtras(bundle);
                startActivity(intent);
            }
        };

        PhoneAuthOptions options =
                PhoneAuthOptions.newBuilder(mAuth)
                        .setPhoneNumber("+91" + sPhone.trim())
                        .setTimeout(60L, TimeUnit.SECONDS)
                        .setActivity(this)
                        .setCallbacks(mCallbacks)
                        .build();
        PhoneAuthProvider.verifyPhoneNumber(options);

    }

}