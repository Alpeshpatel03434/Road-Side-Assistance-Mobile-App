package com.brainybeam.roadsideassistance.User.DashBoard;

import android.Manifest;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;

import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.brainybeam.roadsideassistance.R;
import com.brainybeam.roadsideassistance.User.Activity.UserEndActivity;
import com.brainybeam.roadsideassistance.User.Activity.UserTrackingActivity;
import com.brainybeam.roadsideassistance.Utils.ApiClient;
import com.brainybeam.roadsideassistance.Utils.ApiInterface;
import com.brainybeam.roadsideassistance.Utils.CommonMethod;
import com.brainybeam.roadsideassistance.Utils.SharedPreferencesData;
import com.squareup.picasso.Picasso;

import de.hdodenhof.circleimageview.CircleImageView;


public class UserRequestFragment extends Fragment {

    CardView cardView1, cardView2;
    CircleImageView ForemanProfileImage;
    ImageView CallingLogo;
    TextView Name, MobileNumber, TypeOfProblem, ProblemSubType, Distance;

    TextView VehicleNumber, TypeOfVehicle, ModelName;

    Button SelectButton, PaymentButton;

    ApiInterface apiInterface;
    SharedPreferences sp;

    public UserRequestFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_user_request, container, false);

        apiInterface = ApiClient.getClient().create(ApiInterface.class);
        sp = getActivity().getSharedPreferences(SharedPreferencesData.PREF, Context.MODE_PRIVATE);

        cardView1 = view.findViewById(R.id.frag_user_request_MainCardView);
        cardView2 = view.findViewById(R.id.frag_user_request_CardViewNoRequest);

        ForemanProfileImage = view.findViewById(R.id.frag_user_request_foremanProfileImage);
        CallingLogo = view.findViewById(R.id.frag_user_request_calling_imageLogo);
        Name = view.findViewById(R.id.frag_user_request_FirstANDLastName);
        MobileNumber = view.findViewById(R.id.frag_user_request_MobileNumber);
        TypeOfProblem = view.findViewById(R.id.frag_user_request_TypeOfProblem);
        ProblemSubType = view.findViewById(R.id.frag_user_request_problemSubType);
        Distance = view.findViewById(R.id.frag_user_request_Distance);
        SelectButton = view.findViewById(R.id.frag_user_request_SelectButton);
        PaymentButton = view.findViewById(R.id.frag_user_request_PaymentButton);

        VehicleNumber = view.findViewById(R.id.frag_user_request_VehicleNumber);
        TypeOfVehicle = view.findViewById(R.id.frag_user_request_TypeOfVehicle);
        ModelName = view.findViewById(R.id.frag_user_request_ModelName);

        cardView1.setVisibility(View.VISIBLE);
        cardView2.setVisibility(View.GONE);

        if(sp.getString(SharedPreferencesData.User_ForemanFirstName, "")==""|| sp.getString(SharedPreferencesData.User_ForemanFirstName, "").isEmpty()
        && sp.getString(SharedPreferencesData.User_TypeOfProblem, "")=="" || sp.getString(SharedPreferencesData.User_TypeOfProblem, "").isEmpty()){
            cardView1.setVisibility(View.GONE);
            cardView2.setVisibility(View.VISIBLE);
        } else {
            cardView1.setVisibility(View.VISIBLE);
            cardView2.setVisibility(View.GONE);
        }

       // Picasso.with(getActivity()).load(sp.getString(SharedPreferencesData.User_ForemanProfileImage, "")).placeholder(R.drawable.ic_profile).into(ForemanProfileImage);

        CallingLogo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
                builder.setTitle("Call to Foreman "+sp.getString(SharedPreferencesData.User_ForemanFirstName, "")+"?");
                builder.setPositiveButton("CALL", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        Intent intent = new Intent(Intent.ACTION_CALL);
                        intent.setData(Uri.parse("tel:+91"+sp.getString(SharedPreferencesData.User_ForemanMobileNumber, "")));
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                            if (getActivity().checkSelfPermission(Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
                                // TODO: Consider calling
                                //    Activity#requestPermissions
                                // here to request the missing permissions, and then overriding
                                //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
                                //                                          int[] grantResults)
                                // to handle the case where the user grants the permission. See the documentation
                                // for Activity#requestPermissions for more details.
                                return;
                            }
                        }
                        startActivity(intent);
                    }
                });
                builder.setNegativeButton("CANCEL", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        dialogInterface.dismiss();
                    }
                });
                builder.show();

            }
        });

        Name.setText(sp.getString(SharedPreferencesData.User_ForemanFirstName, "")+" "+sp.getString(SharedPreferencesData.User_ForemanLastName, ""));
        MobileNumber.setText(sp.getString(SharedPreferencesData.User_ForemanMobileNumber, ""));
        TypeOfProblem.setText(sp.getString(SharedPreferencesData.User_TypeOfProblem, ""));
        ProblemSubType.setText(sp.getString(SharedPreferencesData.User_ProblemSubType, ""));
        Distance.setText(sp.getString(SharedPreferencesData.User_DistanceWithForeman, "")+" m");

        VehicleNumber.setText(sp.getString(SharedPreferencesData.User_NumberPlate_number, ""));
        TypeOfVehicle.setText(sp.getString(SharedPreferencesData.User_TypeOfVehicle, ""));
        ModelName.setText(sp.getString(SharedPreferencesData.User_VehicleModelName, ""));


        SelectButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                new CommonMethod(getActivity(), UserTrackingActivity.class);
            }
        });

        PaymentButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                new CommonMethod(getActivity(), UserEndActivity.class);
                getActivity().finish();
            }
        });


        return view;
    }
}