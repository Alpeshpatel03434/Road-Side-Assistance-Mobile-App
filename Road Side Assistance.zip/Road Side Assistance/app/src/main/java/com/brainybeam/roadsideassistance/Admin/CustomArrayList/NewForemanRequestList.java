package com.brainybeam.roadsideassistance.Admin.CustomArrayList;

public class NewForemanRequestList {

    String ForemanID, UserType, FirstName, LastName, ProfileImage, MobileNumber, Email;
    String Address, Area, City, State, Account_Status, Created_time;

    public String getForemanID() {
        return ForemanID;
    }

    public void setForemanID(String foremanID) {
        ForemanID = foremanID;
    }

    public String getUserType() {
        return UserType;
    }

    public void setUserType(String userType) {
        UserType = userType;
    }

    public String getFirstName() {
        return FirstName;
    }

    public void setFirstName(String firstName) {
        FirstName = firstName;
    }

    public String getLastName() {
        return LastName;
    }

    public void setLastName(String lastName) {
        LastName = lastName;
    }

    public String getProfileImage() {
        return ProfileImage;
    }

    public void setProfileImage(String profileImage) {
        ProfileImage = profileImage;
    }

    public String getMobileNumber() {
        return MobileNumber;
    }

    public void setMobileNumber(String mobileNumber) {
        MobileNumber = mobileNumber;
    }

    public String getEmail() {
        return Email;
    }

    public void setEmail(String email) {
        Email = email;
    }

    public String getAddress() {
        return Address;
    }

    public void setAddress(String address) {
        Address = address;
    }

    public String getArea() {
        return Area;
    }

    public void setArea(String area) {
        Area = area;
    }

    public String getCity() {
        return City;
    }

    public void setCity(String city) {
        City = city;
    }

    public String getState() {
        return State;
    }

    public void setState(String state) {
        State = state;
    }

    public String getAccount_Status() {
        return Account_Status;
    }

    public void setAccount_Status(String account_Status) {
        Account_Status = account_Status;
    }

    public String getCreated_time() {
        return Created_time;
    }

    public void setCreated_time(String created_time) {
        Created_time = created_time;
    }

}
