package com.brainybeam.roadsideassistance.Utils.OTPVerification;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Application;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.google.firebase.FirebaseApp;
import com.google.firebase.FirebaseException;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.PhoneAuthCredential;
import com.google.firebase.auth.PhoneAuthOptions;
import com.google.firebase.auth.PhoneAuthProvider;

import java.util.concurrent.TimeUnit;

public class OtpSendActivity extends AppCompatActivity {

    private EditText Phone;
    private Button Send;
    private ProgressBar progressBar;

    private FirebaseAuth mAuth;
    private PhoneAuthProvider.OnVerificationStateChangedCallbacks mCallbacks;

    private String sPhone;
    private SharedPreferences sp;
    FirebaseApp firebaseApp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
//        setContentView(R.layout.activity_otp_send);
//
//        firebaseApp = FirebaseApp.initializeApp(getApplicationContext());
//        mAuth = FirebaseAuth.getInstance();
//        sp = getSharedPreferences(SharedPreferencesData.PREF, MODE_PRIVATE);
//
//
//        Phone = findViewById(R.id.etPhone);
//        Send = findViewById(R.id.btnSend);
//        progressBar = findViewById(R.id.progressBar);
//        Phone.setText(sp.getString(SharedPreferencesData.UserMOBILE, ""));
//        sPhone = Phone.getText().toString();
//
//
//
//        Send.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//
//                sPhone = Phone.getText().toString();
//
//                if (sPhone.isEmpty() || sPhone.equalsIgnoreCase(" ")) {
//                    Toast.makeText(OtpSendActivity.this, "Invalid Phone Number", Toast.LENGTH_SHORT).show();
//                } else if (sPhone.length() != 10) {
//                    Toast.makeText(OtpSendActivity.this, "Type valid Phone Number", Toast.LENGTH_SHORT).show();
//                } else {
//                    otpSend();
//                }
//            }
//        });


    }

//    private void otpSend() {
//        progressBar.setVisibility(View.VISIBLE);
//        Send.setVisibility(View.INVISIBLE);
//
//        mCallbacks = new PhoneAuthProvider.OnVerificationStateChangedCallbacks() {
//
//            @Override
//            public void onVerificationCompleted(PhoneAuthCredential credential) {
//
//            }
//
//            @Override
//            public void onVerificationFailed(FirebaseException e) {
//                progressBar.setVisibility(View.GONE);
//                Send.setVisibility(View.VISIBLE);
//                new CommonMethod(OtpSendActivity.this, e.getLocalizedMessage());
//            }
//
//            @Override
//            public void onCodeSent(@NonNull String VerificationId,
//                                   @NonNull PhoneAuthProvider.ForceResendingToken token) {
//                progressBar.setVisibility(View.GONE);
//                Send.setVisibility(View.VISIBLE);
//
//                new CommonMethod(OtpSendActivity.this, "OTP is successFully Send");
//                Bundle bundle = new Bundle();
//                Intent intent = new Intent(OtpSendActivity.this, OtpVerifyActivity.class);
//                bundle.putString("phone", sPhone.trim());
//                bundle.putString("VerificationID", VerificationId);
//                intent.putExtras(bundle);
//                startActivity(intent);
//            }
//        };
//
//        PhoneAuthOptions options =
//                PhoneAuthOptions.newBuilder(mAuth)
//                        .setPhoneNumber("+91" + sPhone.trim())
//                        .setTimeout(60L, TimeUnit.SECONDS)
//                        .setActivity(this)
//                        .setCallbacks(mCallbacks)
//                        .build();
//        PhoneAuthProvider.verifyPhoneNumber(options);
//
//    }

}