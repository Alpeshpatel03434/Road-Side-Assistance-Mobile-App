package com.brainybeam.roadsideassistance.Utils.OTPVerification;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.brainybeam.roadsideassistance.R;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.PhoneAuthCredential;
import com.google.firebase.auth.PhoneAuthProvider;

import org.jetbrains.annotations.NotNull;

public class OtpVerifyActivity extends AppCompatActivity {

    TextView MobileNumberView;
    EditText OTP1, OTP2, OTP3, OTP4, OTP5, OTP6;
    TextView ResendTextButton;
    Button Verify;
    ProgressBar progressBarVerify;

    FirebaseAuth mAuth;
    FirebaseApp firebaseApp;
    private String VerificationID;

    private SharedPreferences sp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
   //     setContentView(R.layout.activity_otp_verify);

        firebaseApp = FirebaseApp.initializeApp(getApplicationContext());
        mAuth = FirebaseAuth.getInstance();

//        sp = getSharedPreferences(SharedPreferencesData.PREF, MODE_PRIVATE);
//
//        MobileNumberView = findViewById(R.id.MobileNumberView);
//
//        OTP1 = findViewById(R.id.otp1);
//        OTP2 = findViewById(R.id.otp2);
//        OTP3 = findViewById(R.id.otp3);
//        OTP4 = findViewById(R.id.otp4);
//        OTP5 = findViewById(R.id.otp5);
//        OTP6 = findViewById(R.id.otp6);
//
//        ResendTextButton = findViewById(R.id.ResendTextButton);
//        Verify = findViewById(R.id.VerifyButton);
//
//        progressBarVerify = findViewById(R.id.progressBarVerify);
//
//        // OTP Input by User
//        InputOTPInEditTextField();
//
//        Bundle bundle = getIntent().getExtras();
//        String sMobileNumber = "+91"+bundle.getString("phone");
//        MobileNumberView.setText(sMobileNumber);
//
//        VerificationID = bundle.getString("VerificationID");
//
//        ResendTextButton.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                new CommonMethod(OtpVerifyActivity.this, "OTP Send SuccessFully");
//            }
//        });
//
//        Verify.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//
//                progressBarVerify.setVisibility(View.VISIBLE);
//                Verify.setVisibility(View.INVISIBLE);
//
//                if (OTP1.getText().toString().trim().isEmpty() ||
//                        OTP2.getText().toString().trim().isEmpty() ||
//                        OTP3.getText().toString().trim().isEmpty() ||
//                        OTP4.getText().toString().trim().isEmpty() ||
//                        OTP5.getText().toString().trim().isEmpty() ||
//                        OTP6.getText().toString().trim().isEmpty()) {
//
//                    progressBarVerify.setVisibility(View.GONE);
//                    Verify.setVisibility(View.VISIBLE);
//                    new CommonMethod(OtpVerifyActivity.this, "OTP is not Valid!");
//
//                } else {
//                    progressBarVerify.setVisibility(View.GONE);
//                    Verify.setVisibility(View.VISIBLE);
//
//                    if (VerificationID != null) {
//                        String code = OTP1.getText().toString().trim() +
//                                OTP2.getText().toString().trim() +
//                                OTP3.getText().toString().trim() +
//                                OTP4.getText().toString().trim() +
//                                OTP5.getText().toString().trim() +
//                                OTP6.getText().toString().trim();
//
//                        PhoneAuthCredential credential = PhoneAuthProvider.getCredential(VerificationID, code);
//                        FirebaseAuth
//                                .getInstance()
//                                .signInWithCredential(credential)
//                                .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
//                                    @Override
//                                    public void onComplete(@NonNull @NotNull Task<AuthResult> task) {
//                                        if (task.isSuccessful()) {
//                                            new CommonMethod(OtpVerifyActivity.this, "Congratulation SuccessFully Partially Verify");
//
//                                             sp.edit().putString(SharedPreferencesData.UserACCOUNT_Status, "Partially Verify").commit();
//
//                                            new CommonMethod(OtpVerifyActivity.this, UserSignupActivity3.class);
//
//                                        } else {
//                                            new CommonMethod(OtpVerifyActivity.this, "OTP is not Valid!");
//                                        }
//                                    }
//                                });
//                    }
//                }
//            }
//        });

    }

    private void InputOTPInEditTextField() {

        OTP1.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                OTP2.requestFocus();
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
        OTP2.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                OTP3.requestFocus();
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
        OTP3.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                OTP4.requestFocus();
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
        OTP4.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                OTP5.requestFocus();
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
        OTP5.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                OTP6.requestFocus();
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

    }
}