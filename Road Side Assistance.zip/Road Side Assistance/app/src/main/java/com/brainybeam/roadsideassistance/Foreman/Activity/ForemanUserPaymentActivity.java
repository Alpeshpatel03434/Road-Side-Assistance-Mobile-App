package com.brainybeam.roadsideassistance.Foreman.Activity;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.brainybeam.roadsideassistance.Foreman.DashBoard.ForemanDashboardActivity;
import com.brainybeam.roadsideassistance.R;
import com.brainybeam.roadsideassistance.RetrofitData.AddForemanServicesData;
import com.brainybeam.roadsideassistance.RetrofitData.CartAddServicesData;
import com.brainybeam.roadsideassistance.RetrofitData.SendNotificationData;
import com.brainybeam.roadsideassistance.Utils.ApiClient;
import com.brainybeam.roadsideassistance.Utils.ApiInterface;
import com.brainybeam.roadsideassistance.Utils.CommonMethod;
import com.brainybeam.roadsideassistance.Utils.SharedPreferencesData;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ForemanUserPaymentActivity extends AppCompatActivity {

    EditText money;
    Button RequestButton, VerifyButton;

    LinearLayout main_layout, payment_layout;

    String paying;

    ApiInterface apiInterface;
    SharedPreferences sp;
    ProgressDialog pd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_foreman_user_payment);
        getSupportActionBar().setTitle("Set Payment->Bill");
        ColorDrawable colorDrawable
                = new ColorDrawable(Color.parseColor("#2196F3"));
        getSupportActionBar().setBackgroundDrawable(colorDrawable);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        apiInterface = ApiClient.getClient().create(ApiInterface.class);
        sp =getSharedPreferences(SharedPreferencesData.PREF, MODE_PRIVATE);

        money = findViewById(R.id.foreman_user_payment_MoneyTextView);
        RequestButton = findViewById(R.id.foreman_user_payment_PayButton);
        VerifyButton = findViewById(R.id.foreman_user_payment_VerifyButton);

        main_layout = findViewById(R.id.foreman_user_payment_MainLinearLayout);
        payment_layout = findViewById(R.id.foreman_user_payment_paymentLinearLayout);

        main_layout.setVisibility(View.VISIBLE);
        payment_layout.setVisibility(View.GONE);

        RequestButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                paying = money.getText().toString();

                pd = new ProgressDialog(ForemanUserPaymentActivity.this);
                pd.setMessage("Payment Request Sending...");
                pd.setCancelable(false);
                pd.show();

                storeSPMoneyData();
                main_layout.setVisibility(View.GONE);
                payment_layout.setVisibility(View.VISIBLE);

            }
        });

        VerifyButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                AlertDialog.Builder alertDialog = new AlertDialog.Builder(ForemanUserPaymentActivity.this);
                alertDialog.setTitle("Payment Request = > Waiting...");
                alertDialog.setCancelable(false);

                alertDialog.setPositiveButton("Received", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        ToCheckPaymentStatus();
                    }
                });

                alertDialog.setNeutralButton("Resend Request", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        new CommonMethod(ForemanUserPaymentActivity.this, "Please Try Again...");
                        new CommonMethod(ForemanUserPaymentActivity.this, ForemanUserPaymentActivity.class);
                    }
                });

                alertDialog.show();

            }
        });

    }

    private void ToCheckPaymentStatus() {

        Call<CartAddServicesData> call = apiInterface.GetPaymentStatusData(
                sp.getString(SharedPreferencesData.Foreman_CartID, "")
        );

        call.enqueue(new Callback<CartAddServicesData>() {
            @Override
            public void onResponse(Call<CartAddServicesData> call, Response<CartAddServicesData> response) {

                if(response.code()==200){

                    if(response.body().status==true){
                        new CommonMethod(ForemanUserPaymentActivity.this, "Payment Received SuccessFully");
                        SendNotificationToUserPaymentSuccess();
                        new CommonMethod(ForemanUserPaymentActivity.this, ForemanDashboardActivity.class);
                    } else {
                        main_layout.setVisibility(View.VISIBLE);
                        payment_layout.setVisibility(View.GONE);
                        new CommonMethod(ForemanUserPaymentActivity.this, "Payment Received UnSuccessFully");
                    }

                } else {
                    new CommonMethod(ForemanUserPaymentActivity.this, "Server Error Code : "+response.code());
                }

            }

            @Override
            public void onFailure(Call<CartAddServicesData> call, Throwable t) {
                new CommonMethod(ForemanUserPaymentActivity.this, t.getMessage());
            }
        });

    }

    private void SendNotificationToUserPaymentSuccess() {

        String Title = "UserID - "+sp.getString(SharedPreferencesData.UserID, "")+" "+sp.getString(SharedPreferencesData.Foreman_UserFirstName, "")+" "+" Payment Received SuccessFully";
        String Message = "Your Payment Received SuccessFully Thank you for payment \n" +
                "Please Rate Our Services \n"+
                "Thank you!";

        Call<SendNotificationData> call = apiInterface.SendToUserNotificationData(
                sp.getString(SharedPreferencesData.Foreman_UserID, ""),
                Title,
                Message
        );

        call.enqueue(new Callback<SendNotificationData>() {
            @Override
            public void onResponse(Call<SendNotificationData> call, Response<SendNotificationData> response) {

                // pd.dismiss();
                if(response.code()==200){

                    if(response.body().status==true){
                      //  new CommonMethod(ForemanUserPaymentActivity.this, response.body().message);
                    } else {
                        new CommonMethod(ForemanUserPaymentActivity.this, response.body().message);
                    }

                } else {
                    new CommonMethod(ForemanUserPaymentActivity.this, "Server Error Code : "+response.code());
                }

            }

            @Override
            public void onFailure(Call<SendNotificationData> call, Throwable t) {
                // pd.dismiss();
                new CommonMethod(ForemanUserPaymentActivity.this, t.getMessage());
            }
        });

    }

    private void storeSPMoneyData() {

        Call<CartAddServicesData> call = apiInterface.UpdateSPReqMoneyData(
                sp.getString(SharedPreferencesData.Foreman_ServiceID, ""),
                sp.getString(SharedPreferencesData.UserID, ""),
                sp.getString(SharedPreferencesData.Foreman_UserID, ""),
                paying
        );

        call.enqueue(new Callback<CartAddServicesData>() {
            @Override
            public void onResponse(Call<CartAddServicesData> call, Response<CartAddServicesData> response) {

                pd.dismiss();
                if(response.code()==200){

                    if(response.body().status==true){
                      //  new CommonMethod(ForemanUserPaymentActivity.this, response.body().message);
                    } else {
                        new CommonMethod(ForemanUserPaymentActivity.this, response.body().message);
                    }

                } else {
                    new CommonMethod(ForemanUserPaymentActivity.this, "Server Error Code : "+response.code());
                }

            }

            @Override
            public void onFailure(Call<CartAddServicesData> call, Throwable t) {
                pd.dismiss();
                new CommonMethod(ForemanUserPaymentActivity.this, t.getMessage());
            }
        });

    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();
        if (id == android.R.id.home) {
            onBackPressed();
        }
        return super.onOptionsItemSelected(item);
    }

}